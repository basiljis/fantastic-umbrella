Репозиторий СПТ 2.0

## Мониторинг
https://grafana-ds.gppc.ru  
Логин: admin@gppc.ru  
Пароль: GrafanaGPPC123!


## DEV
### Хост
https://spttest.gppc.ru/  
Логин: spt  
Пароль: spttest123! (авторизация на Nginx отключена – доступно всем в Интернете)  

### Логи
DB: https://grafana-ds.gppc.ru/d/c1c33136-04cc-4bb1-bede-6976d963a5a9/logs?orgId=1&refresh=30s&var-instance=All&var-container=spttest-db  
Web: https://grafana-ds.gppc.ru/d/c1c33136-04cc-4bb1-bede-6976d963a5a9/logs?orgId=1&refresh=30s&var-instance=All&var-container=spttest-web  

## PROD
### Хост
https://spt.gppc.ru/  
Доступно по белому списку IP-адресов

### Логи
DB: https://grafana-ds.gppc.ru/d/c1c33136-04cc-4bb1-bede-6976d963a5a9/logs?orgId=1&refresh=30s&var-instance=All&var-container=spt-db  
Web: https://grafana-ds.gppc.ru/d/c1c33136-04cc-4bb1-bede-6976d963a5a9/logs?orgId=1&refresh=30s&var-instance=All&var-container=spt-web
# spttimeline
