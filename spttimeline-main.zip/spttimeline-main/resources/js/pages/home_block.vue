<script setup>
import VueInlineCalendar from "vue-inline-calendar";
import "vue-inline-calendar/dist/style.css";
import LeftSide from "@/layouts/components/LeftSide.vue";


import {
  alphaDashValidator,
  emailValidator,
  requiredValidator,
  russianValidator,
  integerValidator,
} from "@validators";
import { VRow } from "vuetify/lib/components/index.mjs";


const code = ref("");
const messageShow = ref(false);
const infoMessage = ref("");
const router = useRouter();
const isValidForm = ref(true);

const itemsPerPage = ref(6);
const page = ref(1);
const sortBy = ref();
const orderBy = ref();
const hideCompleted = ref(false);
const label = ref("All Courses");

const totalCourse = ref(10);

const selectedDate = ref(null);
const dateCalend = ref('')

const menu = ref('')

const menuChange = (value) => {
  menu.value = value
}

const background = '/images/data/item.jpg'

</script>


<template>
  <div class="container  main-page mt-0 ">

    <VRow>
      <LeftSide @menu-change="menuChange"></LeftSide>



      <VCol cols="8" lg="10" >

        <VRow>

          <VCol cols="12" lg="4" class="px-0">

            <div class="back-yellow d-flex flex-column mt-auto h-100 ">
              <p class="my-auto fs-18 px-5 text-420">Тут будет информация об афише мероприятий “Контекст-клуба”</p>

              <div class="d-flex">
                <VSpacer />
                <div class="back-white d-flex mt-auto h-100 cursor-pointer arrow-area px-9">
                  <VImg src="/images/icons/arrow-left.svg" class=" " />
                </div>
                <div class="back-red d-flex mt-auto h-100 cursor-pointer arrow-area px-9">
                  <VImg src="/images/icons/arrow-right.svg" class=" " />
                </div>
              </div>

            </div>





          </VCol>


          <VCol cols="12" lg="8" class="px-lg-3 px-0">
            <div class="back-fiolet py-10 d-flex mt-auto h-100 ">
              <p class="mt-auto ms-7 fs-100 fw-700 px-5 text-420">{{ menu }}</p>
            </div>

          </VCol>
        </VRow>

        <VRow>

          <VCol cols="12"   lg="4" xl="3" md="6" class="pa-0 ">
            <div class="event-item ">
              <div :style="{ backgroundImage: 'url(' + background + ')' }" 
                class=" w-100 h-100  pa-6 event-img">
                <div class=" d-flex gap-5 align-center " >
                  <p class="fs-15 mb-0 fw-700">пн 12 июня 19.00</p>
                  <VImg max-width="18" max-height="18" src="/images/icons/users.svg" class=" " />
                  <VImg max-width="18" max-height="18" src="/images/icons/movie.svg" class=" " />
                  <VImg max-width="18" max-height="18" src="/images/icons/age12.svg" class=" " />

                  <VChip color="error" radius="20" variant="elevated" class="fw-600">
                    cпектакль
                  </VChip>
                </div>

              </div>

            </div>
            
          </VCol>

          <VCol cols="3">

          </VCol>


          <VCol cols="3">

          </VCol>

        </VRow>
      </VCol>
    </VRow>



  </div>
</template>

<route lang="yaml">
meta:
  action: read
  subject: Testing
  redirectToDashboard: true
  breadcrumb: 
    - title: 'Яркие люди'
    - title: 'Афиша' 
            
</route>


<style lang="scss"></style>
