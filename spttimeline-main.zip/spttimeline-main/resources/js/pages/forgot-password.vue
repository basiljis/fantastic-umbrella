<script setup>
import { useGenerateImageVariant } from '@core/composable/useGenerateImageVariant'
import { VNodeRenderer } from '@layouts/components/VNodeRenderer'
import { themeConfig } from '@themeConfig'
import authV2ForgotPasswordIllustrationDark from '@images/pages/auth-v2-forgot-password-illustration-dark.png'
import authV2ForgotPasswordIllustrationLight from '@images/pages/auth-v2-forgot-password-illustration-light.png'
import authV2MaskDark from '@images/pages/misc-mask-dark.png'
import authV2MaskLight from '@images/pages/misc-mask-light.png'
import axios from '@axios'


import {
  emailValidator,
  requiredValidator,
} from '@validators'

const email = ref('')
const authThemeImg = useGenerateImageVariant(authV2ForgotPasswordIllustrationLight, authV2ForgotPasswordIllustrationDark)
const authThemeMask = useGenerateImageVariant(authV2MaskLight, authV2MaskDark)
const refVForm = ref()

const errors = ref({
  email: undefined,
})

const info = ref({
  email: undefined,
})



const forgot = () => {
  errors.value.email = undefined

  axios.post('/api/auth/forgotpassword', {
    email: email.value.toLowerCase(),

  }).then(r => {

    const { info: formInfo } = r.data
    info.value = formInfo

  }).catch(e => {
    const { errors: formErrors } = e.response.data
    errors.value = formErrors
    console.error(e.response.data)
  })
}



const onSubmit = () => {
  refVForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid)
      forgot()
  })
}

</script>

<template>
  <VRow class="auth-wrapper back" no-gutters>
    <VCol lg="7" class="d-none d-lg-flex">
      <div class="position-relative  rounded-lg rounded-lg w-100 ma-8 me-0">
        <div class="d-flex align-center justify-center w-100 h-100">
          <VImg max-width="371" src="/images/logolight.svg" class="auth-illustration  mb-2" />
        </div>

        <VImg class="auth-footer-mask" :src="authThemeMask" />
      </div>
    </VCol>

    <VCol cols="12" lg="5" class="d-flex align-center justify-center">
      <VCard flat :max-width="500" class="mt-12 mt-sm-0 pa-4">
        <VCardText>
          <div class="d-flex align-center  r w-100 h-100">
            <RouterLink class="text-primary ms-2 mb-1" :to="{ name: 'home' }">

              <VImg v-if="themeConfig.app.light" max-width="182" min-width="182" min-height="182"
                src="/images/logolight.svg" class="auth-illustration  mb-2" />
              <VImg v-else max-width="182" min-width="182" min-height="182" src="/images/logo-m.svg"
                class="auth-illustration  mb-2" />

            </RouterLink>
          </div>
          <h5 class="text-h5 font-weight-semibold mb-1">
            Забыли пароль
          </h5>
          <p class="mb-0">
            Введите вашу почту и мы отправим вам инструкции по сбросу пароля
          </p>
        </VCardText>

        <VCardText>
          <VForm @submit.prevent="onSubmit" ref="refVForm">
            <VRow>
              <!-- email -->
              <VCol cols="12">
                <VTextField v-model="email" label="Email" type="email" placeholder="fio@mail.ru"
                  :error-messages="errors.email" :messages="info.email" :rules="[requiredValidator, emailValidator]" />
              </VCol>

              <!-- Reset link -->
              <VCol cols="12">
                <VBtn block type="submit">
                  Отправить ссылку
                </VBtn>
              </VCol>

              <!-- back to login -->
              <VCol cols="12">
                <RouterLink class="d-flex align-center justify-center" :to="{ name: 'login' }">
                  <VIcon icon="tabler-chevron-left" class="flip-in-rtl" />
                  <span>Я вспомнил!</span>
                </RouterLink>
              </VCol>
            </VRow>
          </VForm>
        </VCardText>
      </VCard>
    </VCol>
    <v-footer class="d-flex align-end">
      &copy; &nbsp; Яркие люди /
      {{ new Date().getFullYear() }}

    </v-footer>

  </VRow>
</template>

<style lang="scss">
@use "@core-scss/template/pages/page-auth.scss";
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
