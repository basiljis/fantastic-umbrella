<script setup>
import { VForm } from 'vuetify/components'
import { useAppAbility } from '@/plugins/casl/useAppAbility'
import AuthProvider from '@/views/pages/authentication/AuthProvider.vue'
import axios from '@axios'
import { useGenerateImageVariant } from '@core/composable/useGenerateImageVariant'
import { VNodeRenderer } from '@layouts/components/VNodeRenderer'
import { themeConfig } from '@themeConfig'
import {
  emailValidator,
  requiredValidator,
} from '@validators'
import authV2LoginIllustrationBorderedDark from '@images/pages/auth-v2-login-illustration-bordered-dark.png'
import authV2LoginIllustrationBorderedLight from '@images/pages/auth-v2-login-illustration-bordered-light.png'
import authV2LoginIllustrationDark from '@images/pages/auth-v2-login-illustration-dark.png'
import authV2LoginIllustrationLight from '@images/pages/auth-v2-login-illustration-light.png'
import authV2MaskDark from '@images/pages/misc-mask-dark.png'
import authV2MaskLight from '@images/pages/misc-mask-light.png'
import Footer from '@/layouts/components/Footer.vue'
import { login } from "@/views/apps/helpers";

const authThemeImg = useGenerateImageVariant(authV2LoginIllustrationLight, authV2LoginIllustrationDark, authV2LoginIllustrationBorderedLight, authV2LoginIllustrationBorderedDark, true)
const authThemeMask = useGenerateImageVariant(authV2MaskLight, authV2MaskDark)
const isPasswordVisible = ref(false)
const route = useRoute()
const router = useRouter()


const errors = ref({
  email: undefined,
  password: undefined,
})


route.query.to ? router.replace(route.query.to) : null

const background = '/images/login-back.png'

const refVForm = ref()
const email = ref('')
const password = ref('')
const rememberMe = ref(false)
const ability = useAppAbility()




const onSubmit = () => {
  refVForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid) {
      login(email.value, password.value).then(res => {
        errors.value = res.errors
        if (res.success) {
          ability.update(res.abilities)
          router.replace(route.query.to ? String(route.query.to) : '/home')
        }
      })
    }
  })
}
</script>

<template>
  <VRow no-gutters class="auth-wrapper ">
    <VCol lg="6" class="d-none d-lg-flex align-center">
      <div class="  h-100  w-100  cover " :style="{ backgroundImage: 'url(' + background + ')' }">
        <div class="d-flex align-center h-100 justify-center  flex-column">
          <RouterLink class="text-primary " :to="{ name: 'home' }">
            <VImg max-width="182" min-width="182" min-height="182" src="/images/logowhite.svg"
              class="auth-illustration  mb-2" />
          </RouterLink>
          <p class="fs-40 fw-700 color-white"> Добро пожаловать</p>
          <p class="fw-18 fs-18 color-white text-center">Проект “Контекст-клуб” поле новых смыслов, масштабная творческая
            лаборатория и сообщество
            созидателей</p>
          <p class="fs-16 fw-700 mt-5 color-white"> Оставайтесь на связи </p>

          <VBtn class=" mt-10" base-color="white" color="#ffffff" variant="outlined" :to="{ name: 'register' }">
            Регистрация
          </VBtn>
        </div>
      </div>
    </VCol>

    <VCol cols="12" lg="6" class="d-flex align-center justify-center" style="background-color: #F8F8FA;">
      <VCard flat :max-width="500" class="mt-lg-12 mt-sm-0 pa-4 " style="background-color: #F8F8FA;">

        <VCardText class="d-flex flex-column">

          <RouterLink class="text-primary mx-auto d-block d-lg-none text-center" :to="{ name: 'home' }">
            <VImg max-width="182" min-width="182" min-height="" src="/images/logolight.svg"
              class="auth-illustration  mb-2" />
          </RouterLink>
        </VCardText>
        <VCardText>
          <p class="text-center fs-36 fw-700 colored mb-1">
            Авторизация
          </p>
          <p class="text-center fs-20 fw-700 colored mb-1">
            Добро пожаловать, пожалуйста авторизуйтесь
          </p>
        </VCardText>

        <VCardText>
          <VForm ref="refVForm" @submit.prevent="onSubmit" class="register-form">
            <VRow>
              <!-- email -->
              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">Логин (адрес электронной почты) </p>
                <VTextField v-model="email" label="Логин (адрес электронной почты)" type="email" class="no-border"
                  placeholder="fio@mail.u" :rules="[requiredValidator, emailValidator]" :error-messages="errors.email" />
              </VCol>

              <!-- password -->
              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">Пароль </p>
                <VTextField v-model="password" label="Пароль" :rules="[requiredValidator]"
                  :type="isPasswordVisible ? 'text' : 'password'" :error-messages="errors.password"
                  :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'" class="no-border"
                  @click:append-inner="isPasswordVisible = !isPasswordVisible" />

                <div class="d-flex align-center flex-wrap justify-space-between mt-2 mb-4">
                  <VCheckbox v-model="rememberMe" label="Запомнить меня" />
                  <RouterLink class="text-primary ms-2 mb-1" :to="{ name: 'forgot-password' }">
                    Забыли пароль?
                  </RouterLink>
                </div>

                <VBtn block type="submit" color="#602699" rounded="0">
                  Войти
                </VBtn>
              </VCol>

              <!-- create account -->
              <VCol cols="12" class="text-center">
                <span>Впервые? </span>
                <RouterLink class="text-primary ms-2" :to="{ name: 'register' }">
                  Получить доступ
                </RouterLink>
              </VCol>

            </VRow>
          </VForm>
        </VCardText>
      </VCard>
    </VCol>



    <!--v-footer class="d-flex align-end">
      &copy; &nbsp; Яркие люди /
      {{ new Date().getFullYear() }}

    </v-footer-->


  </VRow>
</template>

<style lang="scss">
@use "@core-scss/template/pages/page-auth.scss";
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
