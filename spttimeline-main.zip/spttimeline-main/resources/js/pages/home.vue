<script setup>
import VueInlineCalendar from "vue-inline-calendar";
import "vue-inline-calendar/dist/style.css";
import EventCard from "@/layouts/components/EventCard.vue";
import ModalLogin from "@/layouts/components/ModalLogin.vue";
import DialogForm from "@/layouts/components/DialogForm.vue";
import 'vue3-carousel/dist/carousel.css'
import { isUserLoggedIn } from '@/router/utils'
import { useServiceStore } from "@/views/apps/service/serviceStore";
import { Carousel, Slide, Pagination, Navigation } from 'vue3-carousel'
import moment from 'moment'



import {
  alphaDashValidator,
  emailValidator,
  requiredValidator,
  russianValidator,
  integerValidator,
  confirmedValidator,
} from "@validators";
import { VBtn, VRow } from "vuetify/lib/components/index.mjs";

const serviceStore = useServiceStore();
const router = useRouter()


const dialogActive = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')

const selectedDate = ref(new Date())
const guidesList = ref({})

const month = ref(("0" + (new Date().getMonth() + 1)).slice(-2))
const filter = ref('1')
const rowsdata = ref({})
const carouselsdata = ref({})

const setSelectedDate = ref(new Date())
const componentKey = ref(0)

const eventtype = ref('')
const eventformat = ref('')

const currentPage = ref(1)
const currentManualPage = ref(1)


const totalPage = ref(1)
const totalClasses = ref(0)

const eventsCount = ref()


const background2 = '/images/data/carousel.jpg'


const loginShow = ref(false);

const selected_event = ref()
const redirect_event = ref('')


const search = ref('')




const loadmore = () => {
  currentManualPage.value++
  fetchRowsManual()

}


const fetchRows = () => {

  if (selectedDate.value)
    serviceStore
      .fetchRowshome({
        datebegin: moment(new Date(selectedDate.value)).format('YYYY-MM-DD'),
        eventtype: eventtype.value,
        eventformat: eventformat.value,
        perPage: '8',
        currentPage: currentPage.value,

      })
      .then((response) => {
        rowsdata.value = response.data.data
        totalPage.value = response.data.last_page

      })
      .catch((error) => {
        console.error(error)
      })
}


const fetchRowsManual = () => {
  if (selectedDate.value && currentManualPage.value > 1)
    serviceStore
      .fetchRowshome({
        datebegin: selectedDate.value.toLocaleDateString("en-US"),
        eventtype: eventtype.value,
        eventformat: eventformat.value,

        perPage: '8',
        currentPage: currentManualPage.value,

      })
      .then((response) => {
        rowsdata.value = [...new Set([...rowsdata.value, ...response.data.data])];

      })
      .catch((error) => {
        console.error(error)
      })
}



watchEffect(fetchRows)


const fetchCarousel = () => {


  serviceStore
    .getCarousel({

    })
    .then((response) => {
      carouselsdata.value = response.data
    })
    .catch((error) => {
      console.error(error)
    })
}


fetchCarousel()


watch(search, (newValue, oldValue) => {
  if (newValue != oldValue) {
    currentPage.value = 1
    currentManualPage.value = 1
  }
});

watch(selectedDate, (newValue, oldValue) => {
  if (newValue != oldValue) {
    currentPage.value = 1
    currentManualPage.value = 1
  }
});

watch(eventformat, (newValue, oldValue) => {
  if (newValue != oldValue) {
    currentPage.value = 1
    currentManualPage.value = 1
  }
});

watch(eventtype, (newValue, oldValue) => {
  if (newValue != oldValue) {
    currentPage.value = 1
    currentManualPage.value = 1
  }
});


watchEffect(() => {
  if (month.value != ("0" + (new Date().getMonth() + 1)).slice(-2)) setSelectedDate.value = new Date(new Date().getFullYear() + '-' + month.value + '-01')
  else setSelectedDate.value = new Date()
  selectedDate.value = setSelectedDate.value

  nextTick().then(() => {
    componentKey.value += 1;
  })
})


const globalSearch = () => {
  //router.push({ name: "personrezult", params: { personid: searchID.value } })
}


const filtertype = (index) => {
  eventtype.value = index

}



const fetchGuides = () => {
  serviceStore.getFormatsList({}).then(response => {
    guidesList.value['formats'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getTypesList({}).then(response => {
    guidesList.value['types'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getAgesList({}).then(response => {
    guidesList.value['ages'] = response.data
  }).catch(error => {
    console.error(error)
  })
}




const fetchCounts = () => {

  serviceStore.getcountperDay({}).then(response => {

    eventsCount.value = response.data
  }).catch(error => {
    console.error(error)
  })
}


fetchGuides()
fetchCounts()



const openlogin = (id, redirect) => {
  selected_event.value = id
  redirect_event.value = redirect

  loginShow.value = true
}

const openconfirm = () => {
  dialogTitle.value = "Пользователь не подтвержден"
  dialogText.value = "Для регистрации на мероприятие подтвердите почтовый адрес, пройдя по ссылке из письма"
  dialogActive.value = true;
}




const register = (refresh = false) => {
  if (!isUserLoggedIn()) {
    loginShow.value = true
  }
  else {
    serviceStore.userConfirmd({}).then(response => {
      if (response.data.confirmed) {

        if (redirect_event.value) {
          serviceStore.registerEvent({ event_id: selected_event.value }).then(response => {
            dialogTitle.value = ''
            dialogActive.value = true;
            dialogText.value = "Вы успешно зарегестрировались"
            window.open(redirect_event.value, '_blank').focus()
            router.push({ name: 'event', params: { event: selected_event.value } })
          }).catch(error => {
            console.error(error)
          })

        }
        else {
          serviceStore.registerEvent({ event_id: selected_event.value }).then(response => {
            router.push({ name: 'registerevent', params: { event: selected_event.value } })
          }).catch(error => {
            console.error(error)
          })

        }
      }
      else {
        dialogTitle.value = "Пользователь не подтвержден"
        dialogText.value = "Для регистрации на мероприятие подтвердите почтовый адрес, пройдя по ссылке из письма"
        dialogActive.value = true;

      }
    }).catch(error => {
      console.error(error)
    })


  }
}



const closemodal = (val, success) => {
  loginShow.value = val
  if (success) register(true)

}




</script>


<template>
  <ModalLogin :selected_event="selected_event" :show="loginShow" @closemodal="closemodal" />
  <DialogForm :formActive="dialogActive" @closeform="dialogActive = false" :title="dialogTitle" :text="dialogText" />

  <div class="px-3">
    <div class="courusel-zone mt-6  ">
      <Carousel :items-to-show="1" :wrapAround="true" min-height="490px">
        <slide v-for="slide in carouselsdata" :key="slide" class="">


          <a   @click="router.push({ name: 'event', params: { event: slide.events_id } })"
            :style="{ backgroundImage: ' linear-gradient(rgba(0, 0, 0, 0.3),rgba(0, 0, 0, 0.3)), url(' + 
            (JSON.parse(slide.events_files)?.cropped ? ('/storage/'+JSON.parse(slide.events_files)?.cropped) :'') + ')' }"
            class=" w-100 h-100 py-12 courusel-img cursor-pointer grayscale d-none d-sm-block">

            <p class="fs-64 fw-700 text-left">{{ slide.events_name }}</p>
            <div class="mt-12 d-flex gap-5">
              <VImg max-width="22" max-height="22" :src="'/images/icons/' + slide.spr_action_formats_icon" class="  ">
                  <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent" class="tooltip-menu">
                    {{ slide.spr_action_formats_name }}
                  </VTooltip>
                </VImg>
                <VImg max-width="22" max-height="22" :src="'/images/icons/' + slide.spr_ages_icon" class=" invert ">
                <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent" class="tooltip-menu">
                  рекомендованный возраст
                </VTooltip>
              </VImg>

              <VChip :color="slide.spr_action_types_color" radius="20" variant="elevated" class="fw-600">
                  {{ slide.spr_action_types_name }}
                </VChip>
            </div>

            <div class="mt-5 d-flex gap-5">
              <VImg max-width="22" src="/images/icons/ticket.svg" class=" " />
              <template v-if="slide.events_price">
                  <p class="fw-300 fs-30 mb-0 text-left">
                    от {{ slide.events_price }} ₽
                  </p>
                </template>
                <template v-else>
                  <p class="fw-300 fs-30 mb-0 text-left">
                    бесплатно
                  </p>
                </template>
            </div>

            <p class="fw-300 mt-5 mb-0 fs-30 text-left">{{ slide.events_desc }}</p>
            <p class="fs-17 mt-5 fw-400 text-left" style="max-width:660px" v-html="slide.events_anons_short"></p>
          </a>
        
        </slide>

        <template #addons>
          <navigation />
          <pagination />
        </template>
      </Carousel>
    </div>




    <p class="colored fs-18 mt-5"> АФИША МЕРОПРИЯТИЙ </p>

    <vue-inline-calendar :key="componentKey" id="calendar-line" :eventsCount="eventsCount"
      @update:selected-date="selectedDate = $event" :enableMousewheelScroll="true" :show-year="false" locale="ru-RU"
      :selectedDate="setSelectedDate" />


    <div class="container  main-page mt-0 ">
      <VRow class="d-none d-sm-block">

        <VCol cols="12" class="d-flex gap-3 justify-space-between">
          <div id="month">
            <VSelect v-model="month" label="Месяц" class="w-100" :items="[{ 'value': '01', 'title': 'Январь' },
            { 'value': '02', 'title': 'Февраль' },
            { 'value': '03', 'title': 'Март' },
            { 'value': '04', 'title': 'Апрель' },
            { 'value': '05', 'title': 'Май' },
            { 'value': '06', 'title': 'Июнь' },
            { 'value': '07', 'title': 'Июль' },
            { 'value': '08', 'title': 'Август' },
            { 'value': '09', 'title': 'Сентябрь' },
            { 'value': '10', 'title': 'Октябрь' },
            { 'value': '11', 'title': 'Ноябрь' },
            { 'value': '12', 'title': 'Декабрь' }
            ]" />
          </div>

          <template v-for="(event, index) in  guidesList['types']" :key="index">
            <div class="d-xl-flex fs-18 fw-600 align-center gap-3 cursor-pointer" @click="filtertype(event.id)">
              <div :class="eventtype == event.id ? 'active' : ''" @click="filtertype(event.id)"
                class="mx-auto round-type text-center d-flex align-center justify-center color-white fs-13 fw-600"
                :style="{ backgroundColor: event.color }">
                {{ event.name.charAt(0).toUpperCase() }}
                <VTooltip class="tooltip-menu d-lg-none" open-on-click :open-on-hover="true" location="bottom"
                  activator="parent">
                  {{ event.name }}
                </VTooltip>

              </div>
              <div class="bage d-none d-lg-block" @click="filtertype(event.id)"> {{ event.name }}</div>
            </div>


          </template>

          <div class="d-flex fs-18 fw-600 align-center gap-3" id="search">
            <VTextField append-inner-icon="tabler-search" base-color="#602699" v-model="search" color='#602699'
              placeholder="поиск" rounded="0" v-on:keyup.enter="globalSearch" />
          </div>


        </VCol>
      </VRow>

      <VRow class="d-sm-none">

        <VCol cols="6" class="">
          <div id="month">
            <VSelect v-model="month" label="Месяц" class="w-100" :items="[{ 'value': '01', 'title': 'Январь' },
            { 'value': '02', 'title': 'Февраль' },
            { 'value': '03', 'title': 'Март' },
            { 'value': '04', 'title': 'Апрель' },
            { 'value': '05', 'title': 'Май' },
            { 'value': '06', 'title': 'Июнь' },
            { 'value': '07', 'title': 'Июль' },
            { 'value': '08', 'title': 'Август' },
            { 'value': '09', 'title': 'Сентябрь' },
            { 'value': '10', 'title': 'Октябрь' },
            { 'value': '11', 'title': 'Ноябрь' },
            { 'value': '12', 'title': 'Декабрь' }
            ]" />
          </div>
        </VCol>
        <VCol cols="6">
          <div id="filter">
            <VSelect v-model="eventtype" label="Тип мероприятия" class="w-100" :items="guidesList['types']"
              item-value="id" item-title="name" />
          </div>
        </VCol>
      </VRow>

      <VRow class="mt-0 px-2 d-sm-none">
        <VCol cols="6" class="toppin"></VCol>
        <VCol cols="6" class="modalpin toppin"></VCol>
      </VRow>



      <VRow v-if="rowsdata.length > 0">
        <VCol v-for="event in rowsdata" cols="12" lg="4" xl="3" md="6" class=" ">
          <EventCard :event="event" @openlogin="openlogin" @openconfirm="openconfirm"
            @refresh="fetchRows(); fetchCounts()" />
        </VCol>


      </VRow>


      <VRow v-else>
        <VCol cols="12">
          <p class="fs-64 text-center mb-5"> Мероприятий не найдено </p>
        </VCol>
      </VRow>

    </div>
    <div class="d-flex justify-center mb-5 mt-8 gap-4">

      <div @click="loadmore()" max-width="180px"
        class="back-red d-flex loadmore color-white  justify-center align-center gap-2 py-2 px-2 cursor-pointer">
        <div class="fs-18 fw-600 ">загрузить еще</div>
        <VImg max-width="50px" min-width="50px" src="/images/icons/arrow-right.svg" class=" " />


      </div>

      <VPagination v-model="currentPage" size="small" :total-visible="5" :length="totalPage"
        @input="handlePageChange()" />
    </div>


  </div>
</template>

<route lang="yaml">
meta:
  action: read
  subject: Testing
  variant: 'outer'
  redirectToDashboard: false
  breadcrumb: 
    - title: 'Яркие люди'
    - title: 'Афиша' 
            
</route>


<style lang="scss"></style>
