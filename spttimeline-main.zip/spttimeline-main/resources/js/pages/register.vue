<script setup>
import { VForm } from 'vuetify/components'
import authV2RegisterIllustrationBorderedDark from '@images/pages/auth-v2-register-illustration-bordered-dark.png'
import authV2RegisterIllustrationBorderedLight from '@images/pages/auth-v2-register-illustration-bordered-light.png'
import authV2RegisterIllustrationDark from '@images/pages/auth-v2-register-illustration-dark.png'
import authV2RegisterIllustrationLight from '@images/pages/auth-v2-register-illustration-light.png'
import DialogForm from "@/layouts/components/DialogForm.vue";
import authV2MaskDark from '@images/pages/misc-mask-dark.png'
import authV2MaskLight from '@images/pages/misc-mask-light.png'
import { useConstStore } from "@/views/apps/useConstStore"
import { useAppAbility } from '@/plugins/casl/useAppAbility'
import AuthProvider from '@/views/pages/authentication/AuthProvider.vue'
import axios from '@axios'
import { useGenerateImageVariant } from '@core/composable/useGenerateImageVariant'
import { VNodeRenderer } from '@layouts/components/VNodeRenderer'
import { themeConfig } from '@themeConfig'
import CryptoJS from 'crypto-js';
import {
  alphaDashValidator,
  emailValidator,
  confirmedValidator,
  requiredValidator,
  russianValidator,
  integerValidator
} from '@validators'

const refVForm = ref()
const username = ref('')
const constStore = useConstStore()
const email = ref('')
const password = ref('')
const password_ = ref('')
const phone = ref('')
const privacyPolicies = ref(false)
const mailSending = ref(false)
const rules = ref(false)

const dialogActive = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')

const loading = ref(false)
const search = ref()
const messageShow = ref(false);
const infoMessage = ref("");

// Router
const route = useRoute()
const router = useRouter()

// Ability
const ability = useAppAbility()

const background = '/images/login-back.png'


// Form Errors
const errors = ref({
  email: undefined,
  password: undefined,
})

import { register } from "@/views/apps/helpers";



const imageVariant = useGenerateImageVariant(authV2RegisterIllustrationLight, authV2RegisterIllustrationDark, authV2RegisterIllustrationBorderedLight, authV2RegisterIllustrationBorderedDark, true)
const authThemeMask = useGenerateImageVariant(authV2MaskLight, authV2MaskDark)
const isPasswordVisible = ref(false)

const onSubmit = () => {
  refVForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid)


      register(phone.value, email.value, username.value, password.value, password_.value,
        privacyPolicies.value, mailSending.value, rules.value).then(res => {
          errors.value = res.errors

          if (res.success) {

            infoMessage.value = res.message
            phone.value = ''
            email.value = ''
            username.value = ''
            privacyPolicies.value = false
            mailSending.value = false
            rules.value = false
            messageShow.value = true

            refVForm.value.reset()

            ability.update(res.abilities)

          }



        })
  })
}
</script>

<template>
  <v-dialog v-model="messageShow" width="auto">
    <DialogCloseBtn @click="messageShow = !messageShow" />
    <v-card class="px-4">
      <v-card-title>

      </v-card-title>
      <v-card-text v-html="infoMessage"> </v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="messageShow = false">Закрыть</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>

  <DialogForm :formActive="dialogActive" @closeform="dialogActive = false" :title="dialogTitle" :text="dialogText" />

  <VRow no-gutters class="auth-wrapper ">
    <VCol lg="6" class="d-none d-lg-flex">
      <div class="  h-100 cover w-100  " :style="{ backgroundImage: 'url(' + background + ')' }">
        <div class="d-flex align-center mt-15 pt-15 justify-center  flex-column">
          <RouterLink class="text-primary mt-15" :to="{ name: 'home' }">
            <VImg max-width="182" min-width="182" min-height="182" src="/images/logowhite.svg"
              class="auth-illustration  mb-2" />
          </RouterLink>
          <p class="fs-40 fw-700 color-white"> Добро пожаловать</p>
          <p class="fw-18 fs-18 color-white text-center">Проект “Контекст-клуб” поле новых смыслов, масштабная творческая
            лаборатория и сообщество
            созидателей</p>
          <p class="fs-16 fw-700 mt-5 color-white"> Оставайтесь на связи </p>

          <VBtn class=" mt-10" base-color="white" color="#ffffff" variant="outlined" :to="{ name: 'login' }">
            Войти
          </VBtn>
        </div>
      </div>
    </VCol>




    <VCol cols="12" lg="6" class="d-flex align-center justify-center" style="background-color: #F8F8FA;">
      <VCard flat :max-width="700" class="mt-lg-12 mt-sm-0 pa-4" style="background-color: #F8F8FA;">
        <VCardText class="d-flex flex-column">

          <RouterLink class="text-primary mx-auto d-block d-lg-none text-center" :to="{ name: 'home' }">
            <VImg max-width="182" min-width="182" min-height="182" src="/images/logolight.svg"
              class="auth-illustration  mb-2" />
          </RouterLink>

          <p class="text-center fs-36 fw-700 colored mb-1">
            Зарегистрироваться
          </p>

        </VCardText>

        <VCardText>
          <VForm ref="refVForm" @submit.prevent="onSubmit" class="register-form">
            <VRow>
              <!-- Username -->
              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">Ваше имя </p>
                <VTextField v-model="username" :rules="[requiredValidator, russianValidator]" label="Ваше имя"
                  class="no-border" />
              </VCol>

              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">МОБИЛЬНЫЙ ТЕЛЕФОН </p>
                <VTextField pattern="[1-4]{5}" v-model="phone" :rules="[requiredValidator]" label="МОБИЛЬНЫЙ ТЕЛЕФОН"
                  class="no-border" />
              </VCol>

              <!-- email -->
              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">ЭЛЕКТРОННАЯ ПОЧТА </p>
                <VTextField v-model="email" :rules="[requiredValidator, emailValidator]" label="ЭЛЕКТРОННАЯ ПОЧТА"
                  class="no-border" type="email" :error-messages="errors.email"/>
              </VCol>

              <!-- password -->
              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">ПАРОЛЬ </p>
                <VTextField v-model="password" :rules="[requiredValidator]" label="Пароль" class="no-border"
                  :type="isPasswordVisible ? 'text' : 'password'"
                  :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'"
                  @click:append-inner="isPasswordVisible = !isPasswordVisible" />
              </VCol>

              <VCol cols="12">
                <p class="color-black fs-16 fw-700 text-uppercase">Повторить пароль </p>
                <VTextField v-model="password_" :rules="[requiredValidator, confirmedValidator(password_, password)]"
                  class="no-border" label="Повторить пароль" :type="isPasswordVisible ? 'text' : 'password'"
                  :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'"
                  @click:append-inner="isPasswordVisible = !isPasswordVisible" />
              </VCol>


              <VCol cols="12">
                <VCheckbox label="Даю согласие на обработку моих персональных данных" id="privacy-policy"
                  v-model="privacyPolicies" :rules="[requiredValidator]" />
                <VCheckbox label="Подписаться на рассылки" id="mailSending" v-model="mailSending" />
                <VCheckbox id="rules" v-model="rules">
                  <template v-slot:label>
                    <div class="d-flex">
                      Правила &nbsp;
                      <div class=" cursor-pointer "
                        @click=" dialogTitle = 'Правила посещения'; dialogText = constStore.rules; dialogActive = true">
                        посещения</div>
                    </div>
                  </template>
                </VCheckbox>

                <div class="w-100 d-flex">
                  <VBtn type="submit" class="mt-5 fw-16 fs-700 mx-auto px-15" color="#602699" rounded="0">
                    Отправить
                  </VBtn>
                </div>
              </VCol>

              <!-- create account -->
              <VCol cols="12" class="text-center text-base  d-block d-lg-none">
                <span>У вас есть аккаунт? </span>
                <RouterLink class="text-primary ms-2" :to="{ name: 'login' }">
                  Войти
                </RouterLink>
              </VCol>

            </VRow>
          </VForm>
        </VCardText>
      </VCard>
    </VCol>
    <!--v-footer class="d-flex align-end">
      &copy; &nbsp; Яркие люди /
      {{ new Date().getFullYear() }}

    </v-footer-->

  </VRow>
</template>

<style lang="scss">
@use "@core-scss/template/pages/page-auth.scss";

$button-border-color : white;
</style>


<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
  redirectIfLoggedIn: true
</route>
