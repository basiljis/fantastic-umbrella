<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";

const serviceStore = useServiceStore();
const searchQuery = ref("");

const router = useRouter();

const messageShow = ref(false);
const infoMessage = ref("");
const titleMessage = ref("");
const totalRows = ref(0);
const rowPerPage = ref(30);
const currentPage = ref(1);
const totalPage = ref(1);
const rows = ref([]);

watchEffect(() => {
  if (currentPage.value > totalPage.value) currentPage.value = totalPage.value;
});

// 👉 Computing pagination data
const paginationData = computed(() => {
  const firstIndex = rows.value.length
    ? (currentPage.value - 1) * rowPerPage.value + 1
    : 0;
  const lastIndex = rows.value.length + (currentPage.value - 1) * rowPerPage.value;

  return `Показано с ${firstIndex} по ${lastIndex} строки из ${totalRows.value}`;
});
</script>

<template>
  <section class="page container">
    <v-dialog v-model="messageShow" width="auto">
      <DialogCloseBtn @click="messageShow = !messageShow" />
      <v-card class="px-4">
        <v-card-title>
          {{ titleMessage }}
        </v-card-title>
        <v-card-text v-html="infoMessage"> </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="messageShow = false"
            >Закрыть</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>

    <VRow class="d-flex">
      <VCol cols="8">
        <a href="#" class="fw-700 fs-17"> Skills-сессии с ГППЦ </a>
      </VCol>

      <VCol cols="4" class="d-flex justify-end">
        <a href="#" class="fw-500 fs-17">
          <VIcon size="24" icon="tabler-square-rounded-arrow-left" /> назад
        </a>
        /
        <a href="#" class="fw-500 fs-17">
          далее <VIcon size="24" icon="tabler-square-rounded-arrow-right" />
        </a>
      </VCol>
    </VRow>

    <VRow>
      <VCol cols="8" class="text-h4 lh-34">
        <div>
          Вариативные маршруты обучения детей с расстройствами аутистического спектра:
          различия и преимущества
        </div>
        <div class="d-flex mt-5">
          <div class="gray-color fw-700 fs-17 me-4">
            <VIcon size="24" icon="fa-solid:calendar-alt" color="#7367F0" />
            02-05 апреля 2021 год
          </div>

          <div class="gray-color fw-700 fs-17 me-4">
            <VIcon size="24" icon="tabler-alarm-filled" color="#7367F0" />
            10.00 (МСК)
          </div>

          <div class="gray-color fw-700 fs-17 me-4">
            <VIcon size="24" icon="tabler-map-pin-filled" color="#7367F0" />
            онлайн
          </div>
        </div>
      </VCol>

      <VCol cols="4">
        <div class="d-flex justify-end">
          <ul class="main-nav d-flex gap-5">
            <li>
              <a href="#">
                <VIcon size="24" icon="tabler-share" />
                <VTooltip
                  id="tooltip-share"
                  open-on-click
                  :open-on-hover="false"
                  location="bottom"
                  activator="parent"
                >
                  Поделиться

                  <ul>
                    <li class="my-3">
                      <a href="ya.ru">
                        <VIcon
                          size="24"
                          icon="ic:round-facebook"
                          class="me-2"
                        />FaceBook</a
                      >
                    </li>

                    <li class="my-3">
                      <a href="#">
                        <VIcon
                          size="24"
                          icon="entypo-social:vk-with-circle"
                          class="me-2"
                        />ВКонтакте</a
                      >
                    </li>
                    <li class="my-3">
                      <a href="#">
                        <VIcon size="24" icon="quill:link" class="me-2" />Копировать
                        ссылку</a
                      >
                    </li>
                  </ul>
                </VTooltip>
              </a>
            </li>
            <li>
              <a href="#">
                <VIcon size="24" icon="tabler-bookmark" />
              </a>
            </li>
          </ul>
        </div>
      </VCol>
    </VRow>

    <VRow>
      <VCol cols="8" class="mt-5">
        <div class="d-flex gap-5">
          <v-btn class="v-btn-700" color="success" variant="flat" type=""
            >Зарегистрироваться</v-btn
          >
          <v-btn class="v-btn-700" color="error" variant="flat" type=""
            >Опубликовать</v-btn
          >
          <v-btn class="v-btn-700" color="error" variant="flat" type=""
            >Отправить на доработку</v-btn
          >
          <v-btn class="v-btn-700" color="error" variant="flat" type="">
            <VIcon icon="clarity:pencil-solid"
          /></v-btn>
        </div>
        <div class="mt-10">
          <VImg
            min-width="102"
            min-height="102"
            src="/images/demo.png"
            class="auth-illustration mb-2"
          />
        </div>

        <div class="mt-10 d-flex justify-space-around">
          <div>
            <VImg
              max-height="80"
              src="/images/room-avatar-1.png"
              class="auth-illustration mb-2 mx-auto"
            />
            <p class="text-center">Комната №1</p>
            <v-btn color="primary" class="v-btn-500" variant="flat" type=""
              >ссылка на подключение</v-btn
            >
          </div>

          <div>
            <VImg
              max-height="80"
              src="/images/room-avatar-2.png"
              class="auth-illustration mb-2 mx-auto"
            />
            <p class="text-center">Комната №2</p>
            <v-btn color="primary" class="v-btn-500" variant="flat" type=""
              >ссылка на подключение</v-btn
            >
          </div>

          <div>
            <VImg
              max-height="80"
              src="/images/room-avatar-3.png"
              class="auth-illustration mb-2 mx-auto"
            />
            <p class="text-center">Комната №3</p>
            <v-btn color="primary" class="v-btn-500" variant="flat" type=""
              >ссылка на подключение</v-btn
            >
          </div>
        </div>

        <div class="mt-10">
          <p>Уважаемые коллеги!</p>
          <p>
            В рамках проекта «Взаимообучение городов» Городской психолого-педагогический
            центр и Московский центр развития кадрового потенциала образования приглашают
            принять участие в очередной Skills-сессии «Вариативные маршруты обучения детей
            с расстройствами аутистического спектра: различия и преимущества».
          </p>
          <p>
            В ходе сессии вы: познакомитесь с тремя наиболее распространенными
            образовательными моделями при организации обучения детей с аутизмом; совместно
            с экспертами выделите наиболее значимые критерии для определения специальных
            образовательных условий, актуальных для обучающегося с РАС; узнаете об
            основных факторах, влияющих на решение о выборе наиболее эффективной
            образовательной модели на основе обобщенной характеристики обучающихся по
            разных вариантам АООП НОО для детей с РАС; составите алгоритм организации
            образовательного процесса для обучающегося с РАС.
          </p>
          <p>
            Свой опыт представят эксперты из школ-участниц проекта «Ресурсная школа»: ГБОУ
            Школа №1540, ГБОУ Школа №2009 и ГБОУ Школа №285.
          </p>
          <p>
            Регистрация и участие в Skills-сессии: Для тех, кто зарегистрируется на
            встречу на сайте МЦРКПО (в разделе «Взаимообучение городов»)
            https://mcrkpo.ru/депозитарий/#check_in), предусмотрена выдача сертификата
            участника.
          </p>
        </div>

        <VImg src="/images/logos.png" class="auth-illustration mt-10" />
      </VCol>
      <VCol cols="4" class="">
        <VCardTitle class="fw-700 fs-17 color-blue"> Спикеры </VCardTitle>

        <VCard class="shadow">
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava1.png" min-width="60" />
            </div>

            <div>
              <b>Иванов Иван Иванович</b><br />
              <span class="fs-12"
                >старший методист, ГБУ ГППЦ ДОНМ <br />Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava2.png" min-width="60" />
            </div>

            <div>
              <b> Иванова Ивана Ивановна</b><br />
              <span class="fs-12"
                >сначальник отдела, ГБУ ГППЦ ДОНМ<br />
                Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava3.png" min-width="60" />
            </div>

            <div>
              <b>Иванов Иван Иванович</b><br />
              <span class="fs-12"
                >старший методист, ГБУ ГППЦ ДОНМ<br />
                Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
        </VCard>

        <VCardTitle class="fw-700 fs-17 color-blue"> Контактные лица </VCardTitle>

        <VCard class="shadow">
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava1.png" min-width="60" />
            </div>

            <div>
              <b>Иванов Иван Иванович</b><br />
              <span class="fs-12"
                >старший методист, ГБУ ГППЦ ДОНМ <br />Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava2.png" min-width="60" />
            </div>

            <div>
              <b> Иванова Ивана Ивановна</b><br />
              <span class="fs-12"
                >сначальник отдела, ГБУ ГППЦ ДОНМ<br />
                Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
          <VCardText class="d-flex gap-5">
            <div>
              <VImg src="/images/ava3.png" min-width="60" />
            </div>

            <div>
              <b>Иванов Иван Иванович</b><br />
              <span class="fs-12"
                >старший методист, ГБУ ГППЦ ДОНМ<br />
                Email: ZagladinVS@edu.mos.ru<br />
                Тел.: +7(903)595-81-66
              </span>
            </div>
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </section>
</template>

<style lang="scss">
.page {
  .app-user-search-filter {
    inline-size: 31.6rem;
  }

  .text-capitalize {
    text-transform: capitalize;
  }

  .user-list-name:not(:hover) {
    color: rgba(var(--v-theme-on-background), var(--v-high-emphasis-opacity));
  }

  .gray-color {
    font-family: Montserrat;
    font-size: 20px;
    font-weight: 700;
    line-height: 21px;
    letter-spacing: 0.16px;
    text-align: left;
    color: #999999;
  }

  .shadow {
    box-shadow: 20px 20px 0 #f1f1f1, 20px -20px 0 0 #f1f1f1, 0px 4px 20px 0px #0000000d;
    margin-top: 20px;
    margin-bottom: 40px;
  }
}
#tooltip-share {
  .v-overlay__content {
    pointer-events: initial;
    opacity: 0.8;
    a {
      color: white;
    }
  }
}
</style>
