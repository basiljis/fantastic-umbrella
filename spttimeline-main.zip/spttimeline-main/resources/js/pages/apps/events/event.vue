<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";
import EventCard from "@/layouts/components/EventCard.vue";
import DialogForm from "@/layouts/components/DialogForm.vue";
import ability from "@/plugins/casl/ability";
import { useConstStore } from "@/views/apps/useConstStore"
import ModalLogin from "@/layouts/components/ModalLogin.vue";
import clip from "text-clipper";
import { isUserLoggedIn } from '@/router/utils'
//import YouTubePlayer from 'youtube-player';
import Rutube from 'rutube-player';
import JSShare from "js-share";

import { AbilityBuilder } from '@casl/ability'

const serviceStore = useServiceStore();
const searchQuery = ref("");


const router = useRouter();
const constStore = useConstStore()

const dialogActive = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')

const breadCrumbs = ref([])
const files = ref({})
const data = ref()
const clipped = ref(false)
const clippedHtml = ref('')
const route = useRoute()

const rowsdata = ref({})
const participants = ref({})

const background1 = ref('')
const background2 = ref('')
const background3 = ref('')
const background4 = ref('')
const background5 = ref('')

const selected_event = ref()
const redirect_event = ref()

const loginShow = ref(false);


const shareItems = ref()



/*
const getBreadcrumbs = () => {
  breadCrumbs.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      breadCrumbs.value.push(item)
    })
  }
}
*/


const messageShow = ref(false);
const infoMessage = ref("");
const imgcropped = ref("");

const nullShow = ref(false);
const draftShow = ref(false);
const publicShow = ref(false);

const player_load = ref(false);
//watchEffect(getBreadcrumbs)


const fullImg = (url) => {
  infoMessage.value = url
  messageShow.value = true
}

let player;
const rt = new Rutube();


const getData = () => {

  serviceStore
    .getEvent({
      event_id: route.params.event
    })
    .then((response) => {

      data.value = response.data[0]
      if (!ability.can('manage', 'all') && data.value.events_status !== 2)
        router.push({ name: 'home', })

      clippedHtml.value = clip(data.value.events_anons_long, 700, { html: true });
      if (clippedHtml.value == data.value.events_anons_long) clipped.value = true
      breadCrumbs.value.push({ title: data.value.spr_action_types_name, name: "home", to: "/home" })

      breadCrumbs.value.push({ title: data.value.events_name })

      files.value = JSON.parse(data.value.events_files)

      if (files.value?.cropped)
        imgcropped.value = '/storage/' + files.value.cropped

      var filesCount = 1
      if (files.value?.files)
        for (var key in files.value?.files) {
          if (Object.prototype.hasOwnProperty.call(files.value.files, key)) {

            switch (filesCount) {
              case 1:
                background1.value = '/storage/' + files.value.files[key]
                break;
              case 2:
                background2.value = '/storage/' + files.value.files[key]
                break;
              case 3:
                background3.value = '/storage/' + files.value.files[key]
                break;
              case 4:
                background4.value = '/storage/' + files.value.files[key]
                break;
              case 5:
                background5.value = '/storage/' + files.value.files[key]
                break;

            }
            filesCount++


          }
        }


    })
    .catch((error) => {
      console.error(error)
    })

}

getData()



const eventspartList = () => {
  serviceStore
    .eventspartList({ event_id: route.params.event })
    .then((response) => {
      participants.value = response.data
    })
    .catch((error) => {
      console.error(error)
    })
}
eventspartList()





const fetchRows = () => {
  serviceStore
    .likeEvents({})
    .then((response) => {

      rowsdata.value = response.data
    })
    .catch((error) => {
      console.error(error)
    })
}

fetchRows()


onUpdated(() => {
  shareItems.value = document.querySelectorAll('.social_share');
  for (var i = 0; i < shareItems.length; i += 1) {
    shareItems[i].addEventListener('click', function share(e) {
      return JSShare.go(this);
    });
  }
  if (data.value.events_video_www && !player_load.value) {
    player_load.value = true
    rt.Player('player', {
      width: 600,
      // height: 315,
      videoId: data.value.events_video_www,
    });

    //player = YouTubePlayer('video-player', { width: 600 });
    //player.loadVideoById(data.value.events_video_www);
  }
})


const openlogin = (id, redirect) => {
  selected_event.value = id
  redirect_event.value = redirect
  loginShow.value = true
}




const buy_ticket = () => {
  if (data.value.events_tickets_www)
    window.open(data.value.events_tickets_www,'_self').focus()
  else router.push({ name: 'registerevent', params: { event: data.value.events_id } })

}



const register = (refresh = false) => {

  if (redirect_event.value) {
    window.open(redirect_event.value,'_self').focus()
  }

  if (!isUserLoggedIn()) {
    loginShow.value = true
  }
  else {
    serviceStore.userConfirmd({}).then(response => {
      if (response.data.confirmed) {

        if (redirect_event.value) {

          serviceStore.registerEvent({ event_id: selected_event.value }).then(response => {
            dialogTitle.value = ''
            dialogActive.value = true;
            dialogText.value = "Вы успешно зарегестрировались"
            window.open(redirect_event.value).focus()
            if (refresh) router.go(router.currentRoute)
          }).catch(error => {
            console.error(error)
          })

        }
        else {
          serviceStore.registerEvent({ event_id: selected_event.value }).then(response => {
            router.push({ name: 'registerevent', params: { event: selected_event.value } })
          }).catch(error => {
            console.error(error)
          })

        }
      }
      else {
        dialogTitle.value = "Пользователь не подтвержден"
        dialogText.value = "Для регистрации на мероприятие подтвердите почтовый адрес, пройдя по ссылке из письма"
        dialogActive.value = true;

      }
    }).catch(error => {
      console.error(error)
    })


  }
}

const closemodal = (val, success) => {
  loginShow.value = val
  if (success) register(true)
}

const registermain = () => {
  redirect_event.value = data.value.events_tickets_www
  selected_event.value = route.params.event
  register()
}

const nullevent = () => {

  serviceStore
    .nullEvent({
      event_id: route.params.event
    })
    .then((response) => {
      getData()
    }).catch((error) => {

    })
  nullShow.value = false;
}


const draftevent = () => {

  serviceStore
    .unpublishEvent({
      event_id: route.params.event
    })
    .then((response) => {
      getData()
    }).catch((error) => {

    })
  draftShow.value = false;
}


const publicevent = () => {

  serviceStore
    .publishEvent({
      event_id: route.params.event
    })
    .then((response) => {
      getData()
    }).catch((error) => {

    })
  publicShow.value = false;
}


const openconfirm = () => {
  dialogTitle.value = "Пользователь не подтвержден"
  dialogText.value = "Для регистрации на мероприятие подтвердите почтовый адрес, пройдя по ссылке из письма"
  dialogActive.value = true;
}


</script>

<template>
  <ModalLogin :selected_event="selected_event" :show="loginShow" @closemodal="closemodal" />

  <div class="px-3" v-if="data">

    <v-dialog v-model="nullShow" width="auto">
      <DialogCloseBtn @click="nullShow = !nullShow" />
      <v-card class="px-4">
        <v-card-text> Аннулировать мероприятие?</v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="nullShow = false;">Закрыть</v-btn>
          <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="nullevent">Аннулировать</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="draftShow" width="auto">
      <DialogCloseBtn @click="draftShow = !draftShow" />
      <v-card class="px-4">
        <v-card-text> Снять с публикации?</v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="draftShow = false;">Закрыть</v-btn>
          <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="draftevent">Да</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>


    <v-dialog v-model="publicShow" width="auto">
      <DialogCloseBtn @click="publicShow = !publicShow" />
      <v-card class="px-4">
        <v-card-text> Опубликовать?</v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="publicShow = false;">Закрыть</v-btn>
          <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="publicevent">Да</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="messageShow" class="h-100">
      <!--DialogCloseBtn @click="messageShow = !messageShow" /-->
      <v-img @click="messageShow = !messageShow" class="big-image" content-class="full-image" style="object-fit: none;"
        :src="infoMessage"></v-img>
      <!--div :style="{ backgroundImage: 'url(' + infoMessage + ')' }" class="w-100 h-100 big-image mx-auto " > </div-->
    </v-dialog>




    <section class="page event-page container">
      <DialogForm :formActive="dialogActive" @closeform="dialogActive = false" max-width="600" :title="dialogTitle"
        :text="dialogText" />

      <div class="courusel-zone">
        <div
          :style="{ backgroundImage: ' linear-gradient(rgba(0, 0, 0, 0.3),rgba(0, 0, 0, 0.3)), url(' + imgcropped + ')' }"
          class=" w-100 h-100 pe-10 py-12 courusel-img grayscale d-none d-sm-block">
          <VRow>
            <VCol cols="12" lg="6" xl="7" md="12" class=" ">

              <p class="fs-64 fw-700 text-left">{{ data.events_name }}</p>
              <div class="mt-12 d-flex gap-5">
                <VImg max-width="22" max-height="22" :src="'/images/icons/' + data.spr_action_formats_icon" class="  ">
                  <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent"
                    class="tooltip-menu">
                    {{ data.spr_action_formats_name }}
                  </VTooltip>
                </VImg>
                <VImg max-width="22" max-height="22" :src="'/images/icons/' + data.spr_ages_icon" class=" invert ">
                  <VTooltip class="tooltip-menu" open-on-click :open-on-hover="true" location="bottom"
                    activator="parent">
                    рекомендованный возраст
                  </VTooltip>
                </VImg>

                <VChip :color="data.spr_action_types_color" radius="20" variant="elevated" class="fw-600">
                  {{ data.spr_action_types_name }}
                </VChip>
              </div>

              <div class="mt-5 d-flex gap-5">
                <VImg max-width="22" src="/images/icons/ticket.svg" class=" " />

                <template v-if="data.events_price">
                  <p class="fw-300 fs-30 mb-0 text-left">
                    от {{ data.events_price }} ₽
                  </p>
                </template>
                <template v-else>
                  <p class="fw-300 fs-30 mb-0 text-left">
                    бесплатно
                  </p>
                </template>

              </div>

              <p class="fw-300 mt-5 mb-0 fs-30 text-left text-uppercase">{{ data.events_desc }}</p>
              <p class="fs-17 mt-5 fw-400 text-left" style="max-width:660px" v-html="data.events_anons_short"></p>
            </VCol>

            <VCol cols="6" lg="4" xl="3" md="6" class=" ">

              <div class="register pa-5 mt-10">
                <p class="fs-24 gray-color ">
                  Дата и время
                </p>
                <p class="fs-18 gray-color ">
                  {{ new Date(data.events_dt_start).toLocaleString("ru-Ru", {
                    weekday: "short", day: "2-digit", month:
                      "long", year: "numeric"
                  }) }} в {{ data.events_start_time }}
                </p>
                <!--div class=" d-flex gap-4 align-center">
                <p class="fs-18 colored mb-0"> Добавить в календарь</p>
                <VImg max-width="24" src="/images/icons/circle-plus.svg" class=" " />
              </div-->


                <v-btn v-if="data.registered" color="#602699" @click="buy_ticket" block variant="flat"
                  class=" mx-0 mt-5 w-50 fw-600 fs-17 ">
                  Купить билет
                </v-btn>
                <v-btn v-else color="#602699" @click="registermain" block variant="flat"
                  class=" mx-0 mt-5 w-50 fw-600 fs-17 ">
                  Зарегистрироваться
                </v-btn>

                <template v-if="$can('manage', 'all')">
                  <v-btn color="error" density="compact"
                    @click="router.push({ name: 'editevent', params: { event: route.params.event } })" block
                    variant="flat" class=" mx-0 mt-5 w-50 fw-600 fs-17 ">
                    Редактировать
                  </v-btn>

                  <v-btn color="error" v-if="data.events_status != 2" density="compact" @click="publicShow = true" block
                    variant="flat" class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
                    Опубликовать
                  </v-btn>

                  <v-btn color="error" v-if="data.events_status != 1" density="compact" @click="draftShow = true" block
                    variant="flat" class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
                    Снять с публикации
                  </v-btn>

                  <v-btn color="error" v-if="data.events_status != 3" density="compact" @click="nullShow = true" block
                    variant="flat" class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
                    Аннулировать
                  </v-btn>

                </template>
                <div class=" mt-5 d-flex ">
                  <p class="gray-color2 fs-16 cursor-pointer fw-300 mx-auto"
                    @click=" dialogTitle = 'Правила посещения'; dialogText = constStore.rules; dialogActive = true">
                    правила посещения</p>

                </div>
              </div>




            </VCol>

            <VCol cols="6" lg="2" xl="2" md="6" class="d-flex ">

              <div class="ms-auto cursor-pointer" style="max-height: 24px;">
                <VIcon size="24" icon="tabler-share" class="invert" />
                <VTooltip id="tooltip-share" :close-on-content-click="true" open-on-click :open-on-hover="false"
                  location="bottom" activator="parent">
                  Поделиться

                  <ul>
                    <li class="my-3">
                      <button @click="JSShare.go($event.target)" class="btn btn-default social_share"
                        :data-title="data.events_name" data-type="fb">
                        <VIcon size="24" icon="ic:round-facebook" class="me-2" />FaceBook
                      </button>
                    </li>
                    <li class="my-3">
                      <button @click="JSShare.go($event.target)" :data-text="data.events_anons_short"
                        class="btn btn-default social_share" :data-title="data.events_name" data-type="vk">
                        <VIcon size="24" icon="entypo-social:vk-with-circle" class="me-2" />ВКонтакте
                      </button>
                    </li>
                    <li class="my-3">
                      <a href="#" @click="navigator.clipboard.writeText(window.location)">
                        <VIcon size="24" icon="quill:link" class="me-2" />Копировать
                        ссылку
                      </a>
                    </li>
                  </ul>
                </VTooltip>
              </div>
            </VCol>
          </VRow>
        </div>


        <div :style="{ backgroundImage: 'url(' + imgcropped + ')' }"
          class=" w-100 h-100 pe-10 py-12 courusel-img grayscale ps-3 d-sm-none">

          <p class="fw-600 mt-5 mb-0 fs-20 text-left text-uppercase">{{ data.events_desc }}</p>
          <p class="fs-25 fw-900 panton-bold text-left">{{ data.events_name }}</p>



          <div class="mt-4 d-flex gap-5">
            <VImg max-width="22" src="/images/icons/ticket.svg" class=" " />
            <template v-if="data.events_price">
              <p class="fw-300 fs-20 mb-0 text-left">
                от {{ data.events_price }} ₽
              </p>
            </template>
            <template v-else>
              <p class="fw-300 fs-20 mb-0 text-left">
                бесплатно
              </p>
            </template>
          </div>

          <div class=" d-flex gap-5">
            <VImg max-width="22" max-height="22" :src="'/images/icons/' + data.spr_action_formats_icon" class="  ">
              <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent" class="tooltip-menu">
                {{ data.spr_action_formats_name }}
              </VTooltip>
            </VImg>
            <VImg max-width="22" max-height="22" :src="'/images/icons/' + data.spr_ages_icon" class="invert ">
              <VTooltip class="tooltip-menu" open-on-click :open-on-hover="true" location="bottom" activator="parent">
                рекомендованный возраст
              </VTooltip>
            </VImg>
            <VChip :color="data.spr_action_types_color" radius="20" variant="elevated" class="fw-600">
              {{ data.spr_action_types_name }}
            </VChip>
          </div>

        </div>

        <div class="register pa-5 w-100 mt-3 d-sm-none">
          <p class="fs-24 gray-color fw-900 panton-bold">
            Дата и время
          </p>
          <p class="fs-20 fw-700 gray-color ">
            {{ new Date(data.events_dt_start).toLocaleString("ru-Ru", {
              weekday: "short", day: "2-digit", month:
                "long", year: "numeric"
            }) }} в {{ data.events_start_time }}
          </p>
          <!--div class=" d-flex gap-4 align-center">
          <p class="fs-16 fw-700 colored mb-0"> Добавить в календарь</p>
          <VImg max-width="24" src="/images/icons/circle-plus.svg" class=" " />
        </div-->

          <v-btn color="#602699" @click="registermain" block variant="flat"
            class=" mx-0 mt-5 w-50 fw-900 fs-18 panton-bold py-8 ">
            Зарегистрироваться
          </v-btn>
          <template v-if="$can('manage', 'all')">
            <v-btn color="error" density="compact"
              @click="router.push({ name: 'editevent', params: { event: route.params.event } })" block variant="flat"
              class=" mx-0 mt-5 w-50 fw-600 fs-17 ">
              Редактировать
            </v-btn>

            <v-btn color="error" density="compact" @click="publicShow = true" block variant="flat"
              class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
              Опубликовать
            </v-btn>

            <v-btn color="error" density="compact" @click="draftShow = true" block variant="flat"
              class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
              Снять с публикации
            </v-btn>

            <v-btn color="error" density="compact" @click="nullShow = true" block variant="flat"
              class=" mx-0 mt-3 w-50 fw-600 fs-17 ">
              Аннулировать
            </v-btn>

          </template>
          <div class=" mt-5 d-flex ">
            <p class="gray-color2 fs-16 fw-300 mx-auto cursor-pointer"
              @click=" dialogTitle = 'Правила посещения'; dialogText = constStore.rules; dialogActive = true">
              правила посещения</p>
          </div>
        </div>



      </div>



      <v-breadcrumbs :items="breadCrumbs" class="fs-15 fw-600 colored  my-2">
        <template v-slot:prepend>
          <RouterLink to="/">
            <VImg max-width="22" min-width="22" src="/images/icons/home.svg" class=" " to="/" />
          </RouterLink>
          <v-icon icon="tabler:chevron-right" class="colored"></v-icon>
        </template>


        <template v-slot:divider>
          <v-icon icon="tabler:chevron-right" class="colored"></v-icon>
        </template>
      </v-breadcrumbs>



      <div class=" ">
        <VRow>
          <VCol cols="12" md="3">
            <div class="d-flex">
              <div class="colored align-self-center me-3" min-width="72px">
                <hr class="colored line-72">
              </div>
              <div class="colored letter">АНОНС</div>
            </div>

          </VCol>
          <VCol cols="12" md="9" class="photo-col ">
            <div>

              <VRow class="images-zone d-none d-sm-flex">
                <VCol cols="6" class="">
                  <div class="square_inner" v-if="background1">
                    <div :style="{ backgroundImage: 'url(' + background1 + ')  ' }"
                      class="square ms-auto courusel-img grayscale " @click="fullImg(background1)"></div>
                  </div>
                </VCol>
                <VCol cols="6" class="d-flex">
                  <div class="square_inner">
                    <div v-if="background2" :style="{ backgroundImage: 'url(' + background2 + ')  ' }"
                      @click="fullImg(background2)" class="square square__small square__top courusel-img grayscale">
                    </div>

                    <div v-if="background3" :style="{ backgroundImage: 'url(' + background3 + ')  ' }"
                      @click="fullImg(background3)" class="square square__small  courusel-img grayscale"></div>


                  </div>

                  <div class="square_inner">
                    <div v-if="background4" :style="{ backgroundImage: 'url(' + background4 + ')  ' }"
                      @click="fullImg(background4)" class="square square__small square__top courusel-img grayscale">
                    </div>

                    <div v-if="background5" :style="{ backgroundImage: 'url(' + background5 + ')  ' }"
                      @click="fullImg(background5)" class="square square__small courusel-img grayscale"></div>


                  </div>
                </VCol>
              </VRow>

              <p v-if="clipped" v-html="data.events_anons_long" class="mt-0 mt-sm-4"></p>
              <p v-else v-html="clippedHtml" class="mt-0 mt-sm-4"></p>

              <div class="d-flex">
                <div @click="clipped = true" v-if="!clipped"
                  class="cursor-pointer fs-18 fw-700 mt-5  align-center red-color ">
                  читать дальше
                  <VImg max-width="22" min-width="22" src="/images/icons/arrow_red.svg" class=" ms-6 " />
                </div>

                <v-btn color="#602699" variant="flat" class=" mx-0 mt-4 w-50 fw-500 fs-15  d-sm-none">
                  ВИДЕО-АНОНС
                </v-btn>

              </div>

            </div>

          </VCol>
        </VRow>

        <VRow class="mt-8 " v-if="participants.count > 0">
          <VCol cols="12" md="3">
            <div class="d-flex">
              <div class="colored align-self-center me-3" min-width="72px">
                <hr class="colored line-72">
              </div>
              <div class="colored letter">с участием</div>
            </div>

          </VCol>

          <VCol cols="12" md="9" class="photo-col">
            <div v-for="participant in participants.list" class="d-flex mt-4">

              <VAvatar size="68" color="primary" variant="tonal"
                :image="participant?.photo ? '/storage/' + participant?.photo : ''" icon="tabler-user">

              </VAvatar>


              <div class="ps-5">
                <p class="fs-14 fw-700 mb-0">{{ participantname }}

                </p>
                <ul>
                  <li v-if="participant.desc_1">{{ participant.desc_1 }}</li>
                  <li v-if="participant.desc_2">{{ participant.desc_2 }}</li>
                  <li v-if="participant.desc_3">{{ participant.desc_3 }}</li>
                </ul>
              </div>
            </div>



          </VCol>
        </VRow>



        <VRow class="mt-8 " v-if="data.events_video_www">
          <VCol cols="12" md="3">
            <div class="d-flex">
              <div class="colored align-self-center me-3" min-width="72px">
                <hr class="colored line-72">
              </div>
              <div class="colored letter">трансляция</div>
            </div>

          </VCol>
          <VCol cols="12" md="9" class="photo-col">
            <div class="d-flex">
              <!--div id="video-player"></div-->
              <div id="player"></div>
            </div>
          </VCol>
        </VRow>


        <VRow class="mt-8 " v-if="data.events_maps">
          <VCol cols="12" md="3">
            <div class="d-flex">
              <div class="colored align-self-center me-3" min-width="72px">
                <hr class="colored line-72">
              </div>
              <div class="colored letter">место проведения</div>
            </div>

          </VCol>
          <VCol cols="12" md="9" class="photo-col">
            <div class="d-flex">
              <iframe :src="data.events_maps" width="600" height="450" frameborder="0"></iframe>


            </div>
            <p class="mt-3 fw-400">{{ data.events_local_name }}</p>
            <p class=" fw-400">{{ data.events_adress }}</p>

          </VCol>
        </VRow>





      </div>

    </section>
    <div v-if="rowsdata.length > 0" class="back-blue fs-100 white-color related text-center "> Вам может понравиться
    </div>
    <VRow v-if="rowsdata.length > 0">
      <VCol v-for="event in rowsdata" cols="12" lg="4" xl="3" md="6" class=" ">
        <EventCard :event="event" @openlogin="openlogin" @openconfirm="openconfirm" @refresh="fetchRows();" />
      </VCol>


    </VRow>
  </div>
</template>

<style lang="scss"></style>
