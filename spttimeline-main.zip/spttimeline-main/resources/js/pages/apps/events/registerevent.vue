<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";

const serviceStore = useServiceStore();
const router = useRouter();

const getBreadcrumbs = () => {
  breadCrumbs.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      breadCrumbs.value.push(item)
    })
  }
}


</script>

<template>
   <div class="px-3" >

      <h1 class="mt-15 text-center">Регистрация на мероприятие. Внутренняя страница</h1>


  <section class="page container">
  

  </section>

   </div>
</template>

<style lang="scss">
</style>
