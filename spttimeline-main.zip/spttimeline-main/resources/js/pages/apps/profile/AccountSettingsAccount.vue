<script setup>
import avatar1 from '@images/avatars/avatar-14.png'
import { useServiceStore } from "@/views/apps/service/serviceStore";
import axios from '@axios'
import { watchEffect } from 'vue'



const serviceStore = useServiceStore();
const data = ref({})



const refInputEl = ref()

const formData = new FormData()
const infoMessage = ref("");
const messageShow = ref(false);




const getData = () => {

serviceStore
  .getProfile({
  })
  .then((response) => {
      data.value = response.data

  
  })
  .catch((error) => {
    console.error(error)
  })

}


watchEffect(getData)

const resetForm = () => {
  getData()
}

const changeAvatar = file => {
  const fileReader = new FileReader()
  const { files } = file.target
  if (files && files.length) {
    fileReader.readAsDataURL(files[0])
    fileReader.onload = () => {
      if (typeof fileReader.result === 'string')
      {
        data.value.avatar = fileReader.result
        
        if (formData.has('avatar'))
           formData.set('avatar', files[0]);
        else
        formData.append("avatar", files[0]);
      }
    }
  }
}



const send = () => {

  for (var key in data.value) {
    if (data.value[key]) formData.append(key, data.value[key])
  }


  serviceStore
  .updateProfile(formData
  )
  .then((response) => {
    infoMessage.value = response.data.status
        messageShow.value = true
  })
  .catch((error) => {
    console.error(error)
  })

}


 
</script>

<template>


<v-dialog v-model="messageShow" width="auto">
      <DialogCloseBtn @click="messageShow = !messageShow" />
      <v-card class="px-4">
        <v-card-title>
   
        </v-card-title>
        <v-card-text v-html="infoMessage"> </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="messageShow = false;">Закрыть</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>


  <VRow>
    <VCol cols="12">
      <VCard >
        <VCardText class="d-flex">
          <!-- 👉 Avatar -->
          <VAvatar
            rounded
            size="100"
            class="me-6"
            :image="  data.avatar ?  data.avatar :  '/storage/'+data.spt_users_photo"
          />

          <!-- 👉 Upload Photo -->
          <form
            ref="refForm"
            class="d-flex flex-column justify-center gap-4"
          >
            <div class="d-flex flex-wrap gap-2">
              <VBtn
                color="#602699" rounded="0"
                @click="refInputEl?.click()"
              >
                <VIcon
                  icon="tabler-cloud-upload"
                  class="d-sm-none"
                />
                <span class="d-none d-sm-block">Загрузить фотографию</span>
              </VBtn>

              <input
                ref="refInputEl"
                type="file"
                name="file"
                accept=".jpeg,.png,.jpg,GIF"
                hidden
                @input="changeAvatar"
              >


            </div>

          </form>
        </VCardText>

        <VDivider />

        <VCardText class="pt-2">
          <!-- 👉 Form -->
          <VForm class="mt-6">
            <VRow>
              <!-- 👉 First Name -->
              <VCol
                md="6"
                cols="12"
              >
                <VTextField
                  v-model="data.name"
                  label="Имя"
                />
              </VCol>


              <!-- 👉 Email -->
              <VCol
                cols="12"
                md="6"
              >
                <VTextField
                  v-model="data.email"
                  label="E-mail"
                  type="email"
                  readonly
                />
              </VCol>



              <!-- 👉 Phone -->
              <VCol
                cols="12"
                md="6"
              >
                <VTextField
                  v-model="data.spt_user_mobile"
                  label="Телефон"
                />
              </VCol>



              <!-- 👉 Form Actions -->
              <VCol
                cols="12"
                class="d-flex flex-wrap gap-4"
              >
                <VBtn @click="send"    color="#602699" rounded="0"  >Сохранить</VBtn>

                <VBtn
                
                  variant="tonal"
                  color="#602699" rounded="0"
                  type="reset"
                  @click.prevent="resetForm"
                >
                  Отменить
                </VBtn>
              </VCol>
            </VRow>
          </VForm>
        </VCardText>
      </VCard>
    </VCol>

  </VRow>
</template>
