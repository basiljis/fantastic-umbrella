<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";
//import rate from 'vue-rate'
//import 'vue-rate/dist/vue-rate.css'

const serviceStore = useServiceStore();


const searchQuery = ref("")
const router = useRouter()
const messageShow = ref(false);
const rowPerPage = ref(30)
const currentPage = ref(1)
const totalPage = ref(1)
const totalClasses = ref(0)

const rowsdata = ref({})
const loading = ref(true)

const deleteId = ref()
const rowMenu = ref([])



const fetchRows = () => {
  rowsdata.value = []
  loading.value = true
  serviceStore
    .listuser({
      q: searchQuery.value,
      perPage: rowPerPage.value,
      currentPage: currentPage.value,
    })
    .then((response) => {
      totalPage.value = response.data.last_page
      totalClasses.value = response.data.total
      rowsdata.value = response.data.data
      loading.value = false
    })
    .catch((error) => {
      console.error(error)
      loading.value = false
    })
}


watchEffect(fetchRows)

// 👉 watching current page
watchEffect(() => {
  if (currentPage.value > totalPage.value) currentPage.value = totalPage.value
})




const unregister = () => {

  serviceStore
    .unregisterEvent({
      event_id: deleteId.value
    })
    .then((response) => {
      fetchRows()
    }).catch((error) => {

    })
    messageShow.value = false;
}



const onAftereRate = (index) => {


  serviceStore
    .markEvent({
      mark: rowsdata.value[index].events_users_mark,
      event_id: rowsdata.value[index].events_id,
    })
    .then((response) => {
    })
    .catch((error) => {
      console.error(error)
    })
    
}




// 👉 Computing pagination data
const paginationData = computed(() => {
  const firstIndex = rowsdata.value.length
    ? (currentPage.value - 1) * rowPerPage.value + 1
    : 0
  const lastIndex =
    rowsdata.value.length + (currentPage.value - 1) * rowPerPage.value

  return `Показано с ${firstIndex} по ${lastIndex} строки из ${totalClasses.value}`
})





</script>

<template>
  <v-dialog v-model="messageShow" width="auto">
    <DialogCloseBtn @click="messageShow = !messageShow" />
    <v-card class="px-4">
      <v-card-title>

      </v-card-title>
      <v-card-text> Отменить регистрацию?</v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="messageShow = false;">Закрыть</v-btn>
        <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="unregister">Отменить</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>



  <section>

    <VRow>
      <VCol cols="12">
        <VCard title="Мои мероприятия">

          <VCardText class="d-flex flex-wrap py-4 gap-4">
            <VSelect v-model="rowPerPage" density="compact" variant="outlined" :items="[10, 20, 30, 50]" />
            <VSpacer />
            <VTextField v-model="searchQuery" placeholder="Поиск" density="compact" />
          </VCardText>
          <VDivider />

          <VTable class="text-no-wrap ">
            <!-- 👉 table head -->
            <thead>
              <tr>
                <th scope="col">ДАТА</th>
                <th scope="col">НАЗВАНИЕ</th>
                <th scope="col">ТИП</th>
                <th scope="col">ФОРМАТ</th>
                <th scope="col">ОЦЕНИТЕ МЕРОПРИЯТИЕ
                  <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent" class="tooltip-menu">
                    Оценить можно только прошедшее мероприятие
                  </VTooltip>
                </th>
                <th scope="col" class="text-uppercase" >Отменить регистрацию</th>
              </tr>
            </thead>
            <!-- 👉 table body -->
            <tbody>
              <tr v-for="(row, index) in rowsdata" style="height: 3.75rem" :key="index">

                <td>
                  {{ new Date(row['events_dt_start']).toLocaleDateString('ru-Ru') }}
                </td>

                <td>
                  {{ row['events_name'] }}
                </td>
                
                <td>
                  <VChip color="primary" variant="elevated" rounded="20">
                    {{ row['spr_action_types_name'] }}
                  </VChip>
                </td>

                <td class="">
                  <VImg max-width="24" v-if="row['events_format'] == 1" src="/images/icons/users.svg" class="invert60 ">
                    <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent"
                      class="tooltip-menu">
                      очное
                    </VTooltip>
                  </VImg>
                  <VImg max-width="24" v-if="row['events_format'] == 2" src="/images/icons/movie.svg" class="invert60 ">
                    <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent"
                      class="tooltip-menu">
                      онлайн
                    </VTooltip>
                  </VImg>
                </td>

                <td>
                  <rate
                    v-if="row['events_dt_end'] ? new Date() > new Date(row['events_dt_end']) : new Date() > new Date(row['events_dt_start'])"
                    :length="5" v-model="row['events_users_mark']" @after-rate="onAftereRate(index)" />
                </td>
                <td class="my-auto">
                  <VBtn @click="deleteId = row['events_id']; messageShow = true" variant="flat" color="#602699" rounded="0"
                    class="d-flex mx-auto">
                    Отменить</VBtn>
                </td>


              </tr>
            </tbody>

            <!-- 👉 table footer  -->
            <tfoot v-show="!rowsdata.length && loading">
              <tr>
                <td colspan="6" class="text-center">Загрузка
                  <VProgressCircular indeterminate color="info" />
                </td>
              </tr>
            </tfoot>
          </VTable>

          <VDivider />

          <VCardText class="d-flex align-center flex-wrap justify-space-between gap-4 py-3 px-5">
            <span class="text-sm text-disabled">
              {{ paginationData }}
            </span>

            <VPagination v-model="currentPage" size="small" :total-visible="5" :length="totalPage"
              @input="handlePageChange()" />
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </section>
</template>

<style lang="scss"></style>


