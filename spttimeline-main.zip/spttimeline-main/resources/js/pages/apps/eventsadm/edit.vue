<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";
import { useDropzone } from "vue3-dropzone";
import { Cropper } from 'vue-advanced-cropper'
import 'vue-advanced-cropper/dist/style.css';
import axios from '@axios'
import moment from 'moment'


const serviceStore = useServiceStore();
const router = useRouter();
const refVForm = ref()
const messageShow = ref(false);
const infoMessage = ref("");
const titleMessage = ref("");
const form = ref({})
const guidesList = ref({})
const cropp = ref(null);

const img = ref('')
const imgcropped = ref('')
const imgtype = ref('')
const route = useRoute()
const { getRootProps, getInputProps, ...rest } = useDropzone({ onDrop, accept: 'image/jpeg, image/png', });
const { getRootProps: getRootPropslogo, getInputProps: getInputPropslogo, ...restlogo } = useDropzone({ onDrop: onDroplogo, accept: 'image/jpeg, image/png', multiple: 0 });



import {
  alphaDashValidator,
  emailValidator,
  requiredValidator,
  dateRangeValidator,
  russianValidator,
  integerValidator
} from '@validators'
import { VRow } from "vuetify/lib/components/index.mjs";

const onSubmit = () => {
  refVForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid) {

      if (route.meta.newevent)
        save()
      else
        update()
    }

  })
}

const formData = new FormData()
const files = ref([])
const serverfiles = ref({})
const deletefiles = ref([])


const getData = () => {

  serviceStore
    .getEvent({
      event_id: route.params.event
    })
    .then((response) => {

      form.value.format = response.data[0].events_format
      form.value.type = response.data[0].events_type
      form.value.age = response.data[0].events_age
      form.value.price = response.data[0].events_price

      form.value.datebegin = response.data[0].events_start_date // moment(new Date(response.data[0].events_dt_start)).format('YYYY-MM-DD')

      // form.value.datebegin = '2024-12-12'

      form.value.timebegin = response.data[0].events_start_time
      form.value.dateend =response.data[0].events_end_date// moment(new Date(response.data[0].events_dt_end)).format('YYYY-MM-DD')

      form.value.timeend = response.data[0].events_end_time

      form.value.address = response.data[0].events_adress
      form.value.map = response.data[0].events_maps
      form.value.events_status = response.data[0].events_status

      form.value.place = response.data[0].events_local_name
      form.value.site = response.data[0].events_local_www

      form.value.tickets = response.data[0].events_tickets_www
      form.value.video = response.data[0].events_video_www

      form.value.participants = JSON.parse(response.data[0].events_participants) ? JSON.parse(response.data[0].events_participants)?.split(',').map(Number) : ''
      form.value.partners = JSON.parse(response.data[0].events_partners) ? JSON.parse(response.data[0].events_partners)?.split(',').map(Number) : ''

      if (response.data[0].events_carusel == 'true') form.value.carousel = true
      form.value.userscout = response.data[0].events_users


      form.value.name = response.data[0].events_name
      form.value.subline = response.data[0].events_desc
      form.value.shortdesc = response.data[0].events_anons_short
      form.value.fulldesk = response.data[0].events_anons_long

      if (!form.value.participants) form.value.participants = []
      if (!form.value.partners) form.value.partners = []

      serverfiles.value = JSON.parse(response.data[0].events_files)

      if (serverfiles.value.wallpaper)
        img.value = '/storage/' + serverfiles.value.wallpaper
      if (serverfiles.value.cropped)
        imgcropped.value = '/storage/' + serverfiles.value.cropped



    })
    .catch((error) => {
      console.error(error)
    })

}


if (!route.meta.newevent) {
  getData()
}

function getMimeType(file, fallback = null) {
  const byteArray = (new Uint8Array(file)).subarray(0, 4);
  let header = '';
  for (let i = 0; i < byteArray.length; i++) {
    header += byteArray[i].toString(16);
  }
  switch (header) {
    case "89504e47":
      return "image/png";
    case "47494638":
      return "image/gif";
    case "ffd8ffe0":
    case "ffd8ffe1":
    case "ffd8ffe2":
    case "ffd8ffe3":
    case "ffd8ffe8":
      return "image/jpeg";
    default:
      return fallback;
  }
}




function onDrop(acceptFiles, rejectReasons) {
  for (var x = 0; x < acceptFiles.length; x++) {

    formData.append("files[]", acceptFiles[x]);
    files.value.push({ name: acceptFiles[x].name, blob: URL.createObjectURL(acceptFiles[x]), data: acceptFiles[x] })

  }

}


function onDroplogo(acceptFiles, rejectReasons) {
  for (var x = 0; x < acceptFiles.length; x++) {

    if (formData.has('wallpaper'))
      formData.set('wallpaper', acceptFiles[x]);
    else
      formData.append("wallpaper", acceptFiles[x]);
    const blob = URL.createObjectURL(acceptFiles[x]);
    const reader = new FileReader();
    reader.onload = (e) => {
      img.value = blob
      imgtype.value = getMimeType(e.target.result, acceptFiles[0].type)


    };
    reader.readAsArrayBuffer(acceptFiles[x]);

  }

}



const dropfile = (index) => {
  formData.delete('files[]')
  files.value.splice(index, 1);

  files.value.forEach(function (value) {
    formData.append("files[]", value.data, value.name);
  });


}

const dropserverfile = (path) => {
  deletefiles.value.push(path)
  var key = Object.keys(serverfiles.value.files).find(key => serverfiles.value.files[key] === path);
  delete serverfiles.value.files[key]

}



const fetchGuides = () => {
  serviceStore.getFormatsList({}).then(response => {
    guidesList.value['formats'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getTypesList({}).then(response => {
    guidesList.value['types'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getAgesList({}).then(response => {
    guidesList.value['ages'] = response.data
  }).catch(error => {
    console.error(error)
  })

  serviceStore.getPartnersList({}).then(response => {
    guidesList.value['partners'] = response.data
  }).catch(error => {
    console.error(error)
  })

  serviceStore.getPartiList({}).then(response => {
    guidesList.value['participants'] = response.data

  }).catch(error => {
    console.error(error)
  })

  serviceStore.getStatusesList({}).then(response => {
    guidesList.value['statuses'] = response.data
  }).catch(error => {
    console.error(error)
  })




}
fetchGuides()



const crop = () => {
  const { coordinates, canvas, } = cropp.value.getResult();
  img.value = canvas.toDataURL();
  imgcropped.value = canvas.toDataURL();
  canvas.toBlob(function (blob) {

    if (formData.has('cropped'))
      formData.set('cropped', blob);
    else
      formData.append("cropped", blob);

  }, imgtype.value);

}



const save = () => {

  for (var key in form.value) {
    if (form.value[key]) formData.append(key, form.value[key])
  }

  if (form.value['datebegin'] && form.value['timebegin']) formData.append('events_dt_start', form.value['datebegin'] + ' ' + form.value['timebegin'])
  if (form.value['dateend'] && form.value['timeend']) formData.append('events_dt_end', form.value['dateend'] + ' ' + form.value['timeend'])
  else if (form.value['dateend'] && !form.value['timeend']) formData.append('events_dt_end', form.value['dateend'] + ' 23:59' )
  else if (!form.value['dateend'] && form.value['timeend']) formData.append('events_dt_end', form.value['datebegin'] + ' ' + form.value['timeend'])
  else if (!form.value['dateend'] && !form.value['timeend']) formData.append('events_dt_end', form.value['datebegin'] + ' 23:59' )

  axios.post('/apps/event/store',
    formData, { headers: { 'Content-Type': 'multipart/form-data' } },
  ).then(r => {


    router.push({ name: 'editevent', params: { event: r.data.new_id } })

    infoMessage.value = r.data.status
    messageShow.value = true

  }).catch(e => {
    console.error(e)
  })

}


const update = () => {

  deletefiles.value.forEach(function (value) {

    serviceStore
      .delFile({
        fileadr: value,
        event_id: route.params.event,
        filetype: 'files'
      })
      .then((response) => {

      })
      .catch((error) => {
        console.error(error)
      })

  });

  //formData = new FormData()

  form.value['event_id'] = route.params.event
  for (var key in form.value) {
    if (form.value[key]) {
      if (formData.has(key))
        formData.set(key, form.value[key]);
      else
        formData.append(key, form.value[key]);
    }
    else formData.delete(key)
  }

  if (form.value['datebegin'] && form.value['timebegin']) {
    if (formData.has('events_dt_start'))
      formData.set('events_dt_start', form.value['datebegin'] + ' ' + form.value['timebegin']);
    else
      formData.append('events_dt_start', form.value['datebegin'] + ' ' + form.value['timebegin']);
  }

  if (form.value['dateend'] && form.value['timeend']) {
    if (formData.has('events_dt_end'))
      formData.set('events_dt_end', form.value['dateend'] + ' ' + form.value['timeend']);
    else
      formData.append('events_dt_end', form.value['dateend'] + ' ' + form.value['timeend']);
  }
  else  if (form.value['dateend'] && !form.value['timeend']) {
    if (formData.has('events_dt_end'))
      formData.set('events_dt_end', form.value['dateend'] + ' 23:59');
    else
      formData.append('events_dt_end', form.value['dateend'] + ' 23:59' );
  }
  else  if (!form.value['dateend'] && form.value['timeend']) {
    if (formData.has('events_dt_end'))
      formData.set('events_dt_end', form.value['datebegin'] + ' ' + form.value['timeend']);
    else
      formData.append('events_dt_end', form.value['datebegin'] + ' ' + form.value['timeend']);
  }
  else  if (!form.value['dateend'] && !form.value['timeend']) {
    if (formData.has('events_dt_end'))
      formData.set('events_dt_end', form.value['datebegin'] + ' 23:59');
    else
      formData.append('events_dt_end', form.value['datebegin'] + ' 23:59');
  }


  axios.post('/apps/event/update',
    formData, { headers: { 'Content-Type': 'multipart/form-data' } },
  ).then(r => {
    infoMessage.value = r.data.status
    messageShow.value = true

    getData()

  }).catch(e => {
    console.error(e)
  })



}




</script>

<template>
  <section class="page container px-3">
    <v-dialog v-model="messageShow" width="auto">
      <DialogCloseBtn @click="messageShow = !messageShow" />
      <v-card class="px-4">
        <v-card-title>
          {{ titleMessage }}
        </v-card-title>
        <v-card-text v-html="infoMessage"> </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="messageShow = false;">Закрыть</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <VForm ref="refVForm" @submit.prevent="onSubmit">

      <VRow class="mt-3">
        <VCol cols="12" lg="7" class="">

          <VRow class="">

            <VCol cols="12">
              <VSelect class="" :rules="[requiredValidator]" :items="guidesList['statuses']" item-value="id"
                item-title="name" v-model="form.events_status">
                <template #label>
                  Статус <span class="red-color"><strong> * </strong></span>
                </template>
              </VSelect>
            </VCol>
          </VRow>



          <VRow class="">
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VSelect :rules="[requiredValidator]" class="" :items="guidesList['formats']" item-value="id"
                item-title="name" v-model="form.format">

                <template #label>
                  Формат <span class="red-color"><strong> * </strong></span>
                </template>
              </VSelect>

              <VSelect class="" :rules="[requiredValidator]" :items="guidesList['types']" item-value="id"
                item-title="name" v-model="form.type">
                <template #label>
                  Тип <span class="red-color"><strong> * </strong></span>
                </template>
              </VSelect>

            </VCol>
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VSelect label="Возраст" class="" :items="guidesList['ages']" item-value="id" item-title="name"
                v-model="form.age" />
              <VTextField clearable class="" placeholder="от..." label="Стоимость" variant="outlined"
                v-model="form.price" />
            </VCol>
          </VRow>


          <VRow class="">
            <VCol cols="12" md="6" class="d-flex gap-4">
              <VTextField clearable class="" type="date" :rules="[requiredValidator]" variant="outlined"
                v-model="form.datebegin">
                <template #label>
                  Дата начала <span class="red-color"><strong> * </strong></span>
                </template>
              </VTextField>

              <VTextField clearable class="" type="time" :rules="[requiredValidator]" variant="outlined"
                v-model="form.timebegin">
                <template #label>
                  Время начала <span class="red-color"><strong> * </strong></span>
                </template>
              </VTextField>

            </VCol>
            <VCol cols="12" md="6" class="d-flex gap-4">
              <VTextField clearable class="" type="date" label="Дата завершения" :rules="[dateRangeValidator( form.dateend,form.datebegin)]" variant="outlined"
                v-model="form.dateend" />
              <VTextField clearable class="" type="time" label="Время завершения" variant="outlined"
                v-model="form.timeend" />

            </VCol>
          </VRow>

          <VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VTextField clearable label="Адрес проведения мероприятия" class="" v-model="form.address" />
            </VCol>
          </VRow>

          <VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VTextField clearable label="Ссылка на яндекс-карту" class="" v-model="form.map" />
            </VCol>
          </VRow>

          <VRow class="">
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VTextField clearable class="" placeholder="Дом Булгакова" label="Название места проведения"
                variant="outlined" v-model="form.place" />
            </VCol>
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VTextField clearable class="" placeholder="https://..." label="Ссылка на сайт" variant="outlined"
                v-model="form.site" />
            </VCol>
          </VRow>



          <VRow class="">
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VTextField clearable class="" placeholder="https://..." label="Ссылка на билетного оператора"
                variant="outlined" v-model="form.tickets" />
            </VCol>
            <VCol cols="12" sm="6" class="d-flex gap-4">
              <VTextField clearable class="" placeholder="код видео на youtube, например aQfqR99C-wY"
                label="Ссылка на видео" variant="outlined" v-model="form.video" />
            </VCol>
          </VRow>
          <VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VSelect label="С участием (множественный выбор)" multiple class="" :items="guidesList['participants']"
                item-value="id" item-title="name" v-model="form.participants" />
            </VCol>
          </VRow>


          <!--VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VSelect multiple label="Партнеры" class="" :items="guidesList['partners']" item-value="id"
                item-title="name" v-model="form.partners" />
            </VCol>
          </VRow-->

          <VRow class="">
            <VCol cols="6" class="">
              <VCheckbox label="Карусель" inline v-model="form.carousel" />
            </VCol>

            <VCol cols="6" class="d-flex gap-4">
              <VTextField label="Количество участников" type="number" class="" v-model="form.userscout" />
            </VCol>
          </VRow>


          <VRow>
            <VCol cols="12">
              <div v-bind="getRootProps()" class="drag-files pa-5">
                <input v-bind="getInputProps()" />

                <p v-if="rest.isDragActive.value" class="text-center">Бросьте сюда ...</p>
                <p v-else class="text-center">Перетащите сюда файлы или выберите их на устройстве</p>
                <VBtn variant="flat" color="#602699" rounded="0" class="d-flex mx-auto">Открыть</VBtn>
                <div v-for="file in files"> {{ file.name }}</div>
              </div>

            </VCol>

          </VRow>

          <VRow>
            <VCol cols="12" md="4" v-for="file, index  in files" :key="index">
              <VBtn @click="dropfile(index)" variant="flat" color="#602699" rounded="0" class="mb-2 d-flex mx-auto">
                Удалить</VBtn>
              <VImg :src="file.blob" />

            </VCol>

          </VRow>





          <VRow>
            <VCol cols="12">
              <div v-bind="getRootPropslogo()" class="drag-files pa-5">
                <input v-bind="getInputPropslogo()" />

                <p v-if="restlogo.isDragActive.value" class="text-center">Бросьте сюда ...</p>
                <p v-else class="text-center">Перетащите сюда ОДИН файл для заставки или выберите его на устройстве</p>
                <VBtn variant="flat" color="#602699" rounded="0" class="d-flex mx-auto">Открыть
                </VBtn>

              </div>

            </VCol>

          </VRow>


          <VRow v-if="img">
            <VCol cols="12" class="d-flex flex-column">
              <div>
                <cropper ref="cropp" class="h-100" :src="img" :stencil-props="{
                  aspectRatio: 500 / 147
                }"></cropper>
              </div>

              <VBtn variant="flat" color="#602699" rounded="0" class="mx-auto mt-5 " @click="crop">
                Обрезать
              </VBtn>
            </VCol>

          </VRow>


          <VRow v-if="imgcropped">
            <VCol cols="12" class="">
              <VImg :src="imgcropped" class="mx-auto" max-height="100" />
            </VCol>
          </VRow>


        </VCol>



        <VCol cols="12" lg="5">

          <VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VTextField clearable class="" :rules="[requiredValidator]" v-model="form.name">
                <template #label>
                  Название мероприятия <span class="red-color"><strong> * </strong></span>
                </template>
              </VTextField>
            </VCol>
          </VRow>


          <VRow class="">
            <VCol cols="12" class="d-flex gap-4">
              <VTextarea clearable class="" v-model="form.subline" label="Подстрочник" />
            </VCol>
          </VRow>


          <VRow class="">
            <VCol cols="12" class=" h-100">
              <VLabel> Анонс короткий<span class="red-color"><strong> * </strong></span></VLabel>
              <QuillEditor :rules="[requiredValidator]" content-type="html" toolbar="full"
                v-model:content="form.shortdesc" />
              <VTextField class="hide-field" :rules="[requiredValidator]" v-model="form.shortdesc" />
            </VCol>
          </VRow>


          <VRow class="">
            <VCol cols="12" class=" h-100">
              <VLabel> Анонс длинный<span class="red-color"><strong> * </strong></span></VLabel>
              <QuillEditor :rules="[requiredValidator]" content-type="html" toolbar="full"
                v-model:content="form.fulldesk" />
              <VTextField class="hide-field" :rules="[requiredValidator]" v-model="form.fulldesk" />
            </VCol>
          </VRow>

          <VRow class="">
            <VCol cols="12" md="4" v-for="file, index  in serverfiles?.files" :key="index">

              <template v-if="file">
                <VBtn @click="dropserverfile(file)" variant="flat" color="#602699" rounded="0"
                  class="mb-2 d-flex mx-auto">
                  Удалить</VBtn>
                <VImg :src="'/storage/' + file" />
              </template>
            </VCol>
          </VRow>

          <!--VRow class="">
            <VCol cols="12" class="">
              <VCheckbox label="Рассылка приглашений" inline />
            </VCol>
          </VRow-->





        </VCol>

      </VRow>


      <VRow class="mb-5 ">
        <VCol cols="12" md="6" class="d-flex">
          <span class="red-color"><strong> * Поля обязательные для заполнения </strong></span>

        </VCol>
        <VCol cols="12" md="6" class="d-flex">

          <VRow>
            <VCol cols="12" sm="4">
              <VBtn variant="outlined" block class="mx-auto" @click="router.push({ name: 'eventslistadm' })">
                К списку мероприятий
              </VBtn>
            </VCol>
            <VCol cols="12" sm="4" v-if="!route.meta.newevent">
              <VBtn type="submit" block color="success" class="mx-auto"
                @click="router.push({ name: 'event', params: { event: route.params.event } })">
                Предпросмотр
              </VBtn>
            </VCol>
            <VCol cols="12" sm="4">
              <VBtn type="submit" block color="success" class="mx-auto">
                Сохранить
              </VBtn>
            </VCol>
          </VRow>
        </VCol>

      </VRow>




    </VForm>
  </section>
</template>

<style lang="scss">
.page {
  .app-user-search-filter {
    inline-size: 31.6rem;
  }

  .text-capitalize {
    text-transform: capitalize;
  }

  .htmledit {
    min-height: 310px;

  }

  .user-list-name:not(:hover) {
    color: rgba(var(--v-theme-on-background), var(--v-high-emphasis-opacity));
  }

  .gray-color {
    font-family: Montserrat;
    font-size: 20px;
    font-weight: 700;
    line-height: 21px;
    letter-spacing: 0.16px;
    text-align: left;
    color: #999999;
  }

  .shadow {
    box-shadow: 20px 20px 0 #f1f1f1, 20px -20px 0 0 #f1f1f1, 0px 4px 20px 0px #0000000d;
    margin-top: 20px;
    margin-bottom: 40px;
  }
}

#tooltip-share {
  .v-overlay__content {
    pointer-events: initial;
    opacity: 0.8;

    a {
      color: white;
    }
  }
}
</style>
