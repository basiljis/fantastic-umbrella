<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";
import { VDataTable } from 'vuetify/labs/VDataTable'

const serviceStore = useServiceStore();

const messageShow = ref(false);
const searchQuery = ref("")
const router = useRouter()

const rowPerPage = ref(30)
const currentPage = ref(1)
const totalPage = ref(1)
const totalClasses = ref(0)

const rowsdata = ref({})
const deleteId = ref()
const loading = ref(true)

const datebegin = ref('')
const eventtype = ref('')
const eventstatus = ref('')

const eventformat = ref('')
const guidesList = ref({})
const rowMenu = ref([])

const fetchGuides = () => {
  serviceStore.getFormatsList({}).then(response => {
    guidesList.value['formats'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getTypesList({}).then(response => {
    guidesList.value['types'] = response.data
  }).catch(error => {
    console.error(error)
  })
  serviceStore.getAgesList({}).then(response => {
    guidesList.value['ages'] = response.data
  }).catch(error => {
    console.error(error)
  })

  serviceStore.getStatusesList({}).then(response => {
    guidesList.value['statuses'] = response.data
  }).catch(error => {
    console.error(error)
  })


}
fetchGuides()

const fetchRows = () => {
  loading.value = true
  rowsdata.value = []
  serviceStore
    .fetchRows({
      q: searchQuery.value,
      perPage: rowPerPage.value,
      currentPage: currentPage.value,
      datebegin: datebegin.value,
      eventtype: eventtype.value,
      eventstatus: eventstatus.value,
      eventformat: eventformat.value
    })
    .then((response) => {
      totalPage.value = response.data.last_page
      totalClasses.value = response.data.total
      rowsdata.value = response.data.data
      loading.value = false
    })
    .catch((error) => {
      console.error(error)
      loading.value = false
    })
}


watchEffect(fetchRows)

// 👉 watching current page
watchEffect(() => {
  if (currentPage.value > totalPage.value) currentPage.value = totalPage.value
})


// 👉 Computing pagination data
const paginationData = computed(() => {
  const firstIndex = rowsdata.value.length
    ? (currentPage.value - 1) * rowPerPage.value + 1
    : 0
  const lastIndex =
    rowsdata.value.length + (currentPage.value - 1) * rowPerPage.value

  return `Показано с ${firstIndex} по ${lastIndex} строки из ${totalClasses.value}`
})



const headers = [
  {
    title: 'Дата',
    key: 'date',
  },
  {
    title: 'Название',
    key: 'name',
  },
  {
    title: 'Тип',
    key: 'type',
  },
  {
    title: 'Формат',
    key: 'format',
  },
  {
    title: 'Статус',
    key: 'status',
  },
  {
    title: 'Действие',
    key: 'action',
  },
]

const edit = (id) => {
  router.push({ name: 'editevent', params: { event: id } })

}


const nullevent = () => {

  serviceStore
    .nullEvent({
      event_id: deleteId.value
    })
    .then((response) => {
      fetchRows()
    }).catch((error) => {

    })
  messageShow.value = false;
}


</script>

<template>
  <v-dialog v-model="messageShow" width="auto">
    <DialogCloseBtn @click="messageShow = !messageShow" />
    <v-card class="px-4">
      <v-card-title>

      </v-card-title>
      <v-card-text> Аннулировать мероприятие?</v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="messageShow = false;">Закрыть</v-btn>
        <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="nullevent">Аннулировать</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>



  <section>

    <VRow>
      <VCol cols="12">
        <VCard title="Мои мероприятия">
          <!-- 👉 Filters -->
          <VCardText class="d-flex align-center">


            <VSpacer />
            <VBtn :to="{ name: 'newevent' }" class="me-5">
              Запланировать
            </VBtn>
            <VTextField v-model="searchQuery" placeholder="Поиск" density="compact" />


          </VCardText>

          <VDivider />

          <VCardText class="d-flex flex-wrap py-4 gap-4">

            <VRow>

              <VCol cols="12" sm="4" lg="1">
                <VSelect v-model="rowPerPage" density="compact" variant="outlined" :items="[10, 20, 30, 50]" />
              </VCol>


              <VCol cols="12" sm="4" lg="3">
                <VTextField clearable class="" type="date" label="Дата начала" variant="outlined" v-model="datebegin" />
              </VCol>


              <VCol cols="12" sm="4" lg="3">
                <VSelect class="w-100" v-model="eventformat" clearable label="Формат" :items="guidesList['formats']" item-value="id"
                  item-title="name" />
              </VCol>


              <VCol cols="12" sm="4" lg="3">
                <VSelect v-model="eventtype" label="Тип мероприятия" clearable class="w-100" :items="guidesList['types']"
                  item-value="id" item-title="name" />

              </VCol>

              <VCol cols="12" sm="4" lg="2" class="">
                <VSelect v-model="eventstatus" label="Статус мероприятия" clearable class="w-100" :items="guidesList['statuses']"
                  item-value="id" item-title="name" />
              </VCol>
            </VRow>

          </VCardText>

          <VDivider />


          <!--VDataTable    :headers="headers"   :items-per-page="5"   show-select ></VDataTable-->



          <VTable class="text-no-wrap ">
            <!-- 👉 table head -->
            <thead>
              <tr>

                <th scope="col">ДАТА</th>
                <th scope="col">НАЗВАНИЕ</th>
                <th scope="col">ТИП</th>
                <th scope="col">ФОРМАТ</th>
                <th scope="col">СТАТУС</th>
                <th scope="col">ДЕЙСТВИЕ</th>
              </tr>
            </thead>
            <!-- 👉 table body -->
            <tbody>
              <tr v-for="(row, index) in rowsdata" style="height: 3.75rem" :key="index">

                <td>
                  {{ new Date(row['events_dt_start']).toLocaleDateString('ru-Ru') }}
                </td>

                <td>
                  {{ row['events_name'] }}
                </td>

                <td>
                  <VChip color="primary" variant="elevated" rounded="20">
                    {{ row['spr_action_types_name'] }}

                  </VChip>
                </td>

                <td class="">
                  <VImg max-width="24" max-height="18" :src="'/images/icons/' + row['spr_action_formats_icon']"
                    class=" invert60 ">
                    <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent"
                      class="tooltip-menu">
                      {{ row['spr_action_formats_name'] }}
                    </VTooltip>
                  </VImg>
                </td>

                <td>
                  <VImg max-width="24" :src="'/images/icons/' + row['spr_event_status_icon']" class="invert60 ">
                    <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent"
                      class="tooltip-menu">
                      {{ row['spr_event_status_name'] }}
                    </VTooltip>
                  </VImg>
                </td>

                <td class=" ">
                  <div class="d-flex">
                    <VImg max-width="24" src="/images/icons/heart.svg" class="invert60  me-5">
                      <VTooltip open-on-click location="bottom" activator="parent" class="tooltip-menu admin-table">
                        <div class="d-flex align-center">
                          <VImg min-width="15" src="/images/icons/heart.svg" class="svg-white me-1" />
                          <span class="me-5"> {{row['heartcount'] ? Math.round((row['heartsum']/row['heartcount']) * 10) / 10  :"-"  }}</span>
                          <VIcon icon="tabler-user-plus" size="15" class="me-1" />
                          <span>{{ row['reg_count'] }}</span>
                        </div>


                      </VTooltip>
                    </VImg>

                                    

                    <VMenu v-model="rowMenu[row.events_id]" transition="slide-y-transition">
                      <template #activator="{ props }">
                        <VImg v-bind="props" max-width="6" src="/images/icons/points.svg" class="cursor-pointer " />
                      </template>
                      <v-list>
                        <v-list-item>
                          <div class="d-flex cursor-pointer "
                            @click="router.push({ name: 'event', params: { event: row.events_id } })">
                            <VImg max-width="24px" min-width="24px" src="/images/icons/eye.svg" class="me-2 " />
                            Предпросмотр
                          </div>
                        </v-list-item>
                        <!--v-list-item>

                          <div class="d-flex cursor-pointer ">
                            <VImg max-width="24px" min-width="24px" src="/images/icons/send.svg" class="me-2 " />
                            Сделать рассылку
                          </div>
                        </v-list-item-->
                        <v-list-item>
                          <div class="d-flex cursor-pointer " @click="edit(row.events_id)">
                            <VImg max-width="24px" min-width="24px" src="/images/icons/list.svg" class="me-2 " />
                            Редактировать
                          </div>
                        </v-list-item>
                        <v-list-item>
                          <div class="d-flex cursor-pointer " @click="messageShow = true; deleteId = row.events_id">
                            <VImg max-width="24px" min-width="24px" src="/images/icons/delete.svg" class="me-2 " />
                            Аннулировать
                          </div>
                        </v-list-item>
                      </v-list>
                    </VMenu>
                  </div>

                </td>

              </tr>
            </tbody>

            <!-- 👉 table footer  -->
            <tfoot v-show="!rowsdata.length && loading">
              <tr>
                <td colspan="6" class="text-center">Загрузка
                  <VProgressCircular indeterminate color="info" />
                </td>
              </tr>
            </tfoot>
          </VTable>

          <VDivider />

          <VCardText class="d-flex align-center flex-wrap justify-space-between gap-4 py-3 px-5">
            <span class="text-sm text-disabled">
              {{ paginationData }}
            </span>

            <VPagination v-model="currentPage" size="small" :total-visible="5" :length="totalPage"
              @input="handlePageChange()" />
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </section>
</template>

<style lang="scss"></style>


