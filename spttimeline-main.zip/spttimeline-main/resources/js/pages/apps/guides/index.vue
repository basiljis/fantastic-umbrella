<script setup>
import { avatarText } from '@core/utils/formatters'
import { useGuideStore } from "@/views/apps/useGuideStore"
import { defineProps, reactive } from "vue"

import guideForm from '@/pages/apps/guides/guideForm.vue'


const guideStore = useGuideStore()

const searchQuery = ref('')
const selectedRole = ref()
const selectedPlan = ref()
const selectedStatus = ref()
const rowPerPage = ref(10)
const currentPage = ref(1)
const totalPage = ref(1)
const totalGuides = ref(0)
const guides = ref([])
const buttons = ref([])
const definition = ref([])
const formMethod = ref('')
const formAction = ref('')
const formParametrs = ref('')
const showButtonForm = ref(false)
const rowData = ref([])
const colsData = ref([])
const route = useRoute()
const sortByOrder = (d1, d2) => (Number(d1.order) > Number(d2.order)) ? 1 : -1
const messageShow = ref(false)
const infoMessage = ref('')

// 👉 Fetching Guides
const fetchGuides = (query) => {
  guideStore.fetchGuideList({
    q: query ,
    status: selectedStatus.value,
    plan: selectedPlan.value,
    role: selectedRole.value,
    perPage: rowPerPage.value,
    currentPage: currentPage.value,
  }, route.meta.url).then(response => {
    guides.value = response.data.data
    totalPage.value = response.data.last_page
    totalGuides.value = response.data.total
  }).catch(error => {
    console.error(error)
  })
}


const filter = () => {
  fetchGuides(searchQuery.value)
}



const getButtonsData = () => {
  guideStore.getButtonsData({
    page_name: route.meta.guideName,

  }).then(response => {
    buttons.value = response.data
    currentPage.value = 1
    rowPerPage.value = 10
  }).catch(error => {
    console.error(error)
  })
}


const getColsData = () => {
  guideStore.getColsData({
    page_name: route.meta.guideName,

  }).then(response => {
    colsData.value = response.data
  }).catch(error => {
    console.error(error)
  })
}


watchEffect(() => {
  // works for reactivity tracking
  fetchGuides('')
})

//watchEffect(fetchGuides)
watchEffect(getColsData)
watchEffect(getButtonsData)

// 👉 watching current page
watchEffect(() => {
  if (currentPage.value > totalPage.value)
    currentPage.value = totalPage.value
})


// 👉 watching current page
watchEffect(() => {
  if (currentPage.value > totalPage.value)
    currentPage.value = totalPage.value
})

// 👉 Computing pagination data
const paginationData = computed(() => {
  const firstIndex = guides?.value?.length ? (currentPage.value - 1) * rowPerPage.value + 1 : 0
  const lastIndex = guides?.value?.length + (currentPage.value - 1) * rowPerPage.value
  return `Показано с ${firstIndex} по ${lastIndex} строки из ${totalGuides.value}`
})




const buttonClick = Button => {

  if (buttons.value[Button.currentTarget.getAttribute('data-button-index')].form_definition) {

    if (buttons.value[Button.currentTarget.getAttribute('data-button-index')].position === "row") {
      rowData.value = guides.value.find(o => o[route.meta.ind] === Number(Button.currentTarget.getAttribute('data-model-id')))
    }
    else
      rowData.value = []
    definition.value = eval(buttons.value[Button.currentTarget.getAttribute('data-button-index')].form_definition)
    formMethod.value = buttons.value[Button.currentTarget.getAttribute('data-button-index')].method
    formAction.value = buttons.value[Button.currentTarget.getAttribute('data-button-index')].url
    formParametrs.value = buttons.value[Button.currentTarget.getAttribute('data-button-index')].parametrs

    showButtonForm.value = true
  }
  else {
    var params = {}

    if (buttons.value[Button.currentTarget.getAttribute('data-button-index')].parametrs)
      params[buttons.value[Button.currentTarget.getAttribute('data-button-index')].parametrs] = guides.value.find(o => o[route.meta.ind] === Number(Button.currentTarget.getAttribute('data-model-id')))[buttons.value[Button.currentTarget.getAttribute('data-button-index')].parametrs]
    guideStore.sendFormData(params, buttons.value[Button.currentTarget.getAttribute('data-button-index')].method, buttons.value[Button.currentTarget.getAttribute('data-button-index')].url).then(response => {

      if (response.data.status) {
        infoMessage.value = response.data.status
        messageShow.value = true
      }
    }).catch(error => {
      console.error(error)
    })
    fetchGuides(searchQuery.value)
  }

}


watch(showButtonForm, (newShowButtonForm) => {
  if (showButtonForm.value === false) fetchGuides(searchQuery.value)
}, { deep: true })


function setModalVisibility(data) {
  infoMessage.value = data
  messageShow.value = true
  fetchGuides(searchQuery.value)
}
</script>

<template>
  <section>



    <v-dialog v-model="messageShow" width="auto">

      <v-card width="400px" class="px-4">
        <v-card-title></v-card-title>
        <v-card-text>
          {{ infoMessage }}
        </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto " @click="messageShow = false">Закрыть</v-btn>
        </v-card-actions>
      </v-card>


    </v-dialog>



    <guideForm @showmodal="setModalVisibility" v-model="showButtonForm" :formDefinition="definition"
      :formMethod="formMethod" :formAction="formAction" :formData="rowData" :formResult="infoMessage"
      :formParametrs="formParametrs" />

    <VRow>
      <VCol cols="12">
        <VCard title="">
          <VCardText class="d-flex flex-wrap py-4 gap-4">
            <div class="me-3" style="width: 80px">
              <VSelect v-model="rowPerPage" density="compact" variant="outlined" :items="[10, 20, 30, 50]" />
            </div>

            <VSpacer />
            <div v-for="(button, index) in buttons">
              <VBtn v-if="button['position'] === 'top'" :variant="button['variant']" :color="button['color']"
                :data-button-index="index" @click="buttonClick" :prepend-icon="button['icon']">
                {{ button['name'] }}
              </VBtn>
              <VSpacer v-if="button['position'] === 'top'" />
            </div>


            <div class="app-guide-search-filter d-flex align-center flex-wrap gap-4">
              <!-- 👉 Search  -->
              <div style="width: 10rem">
                <VTextField v-model="searchQuery" placeholder="Поиск" density="compact" />
              </div>
              <VBtn variant="flat" color="success" @click="filter">
                Искать
              </VBtn>

              <!-- 👉 Export button -->
              <VBtn variant="tonal" color="secondary" prepend-icon="tabler-screen-share">
                Export
              </VBtn>
            </div>
          </VCardText>

          <VDivider />


          <VTable class="">
            <!-- 👉 table head -->
            <thead>
              <tr>

                <th scope="col" v-for="(col, index) in colsData.sort(sortByOrder)">
                  {{ col.name }}
                </th>
                <th scope="col">
                  Действия
                </th>
              </tr>
            </thead>
            <!-- 👉 table body -->
            <tbody>
              <tr v-for="guide in guides" :key="guide[route.meta.ind]" style="height: 3.75rem">

                <td scope="col" v-for="(col, index) in colsData.sort(sortByOrder)">
                  <span :class="col.textclass">{{ guide[col.field] }}</span>
                </td>

                <!-- 👉 Actions -->
                <td style="width: 5rem">

                  <div class=" d-flex ">
                    <div v-for="(button, index ) in buttons">
                      <VBtn class="mx-2" :data-button-index="index" :data-model-id="guide[route.meta.ind]"
                        v-if="button['position'] === 'row'" :variant="button['variant']" :color="button['color']"
                        @click="buttonClick" :icon="button['icon']">

                      </VBtn>
                    </div>
                  </div>

                </td>
              </tr>
            </tbody>

            <!-- 👉 table footer  -->
            <tfoot v-show="guides && !guides.length">
              <tr>
                <td colspan="7" class="text-center">
                  Нет данных
                </td>
              </tr>
            </tfoot>
          </VTable>

          <VDivider />

          <VCardText class="d-flex align-center flex-wrap justify-space-between gap-4 py-3 px-5">
            <span class="text-sm text-disabled">
              {{ paginationData }}
            </span>

            <VPagination v-model="currentPage" size="small" :total-visible="5" :length="totalPage"
               />
          </VCardText>
        </VCard>
      </VCol>
    </VRow>


  </section>
</template>

<style lang="scss">
.app-guide-search-filter {
  inline-size: 31.6rem
}

.text-capitalize {
  text-transform: capitalize
}

.guide-list-name:not(:hover) {
  color: rgba(var(--v-theme-on-background), var(--v-high-emphasis-opacity))
}
</style>
