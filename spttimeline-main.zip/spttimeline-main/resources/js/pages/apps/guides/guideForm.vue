<script setup>


import { defineProps, reactive } from "vue"
import { computed } from 'vue'
import { useGuideStore } from "@/views/apps/useGuideStore"

const guideStore = useGuideStore()
const guideData = ref({})
const search = ref()
const loading = ref(false)

const sortByOrder = (d1, d2) => (d1.order > d2.order) ? 1 : -1;

const props = defineProps({
  modelValue: Boolean,
  formData: Array,
  formDefinition: Array,
  formMethod: String,
  formAction: String,
  formParametrs: String,
});

const formData = new FormData()

const emit = defineEmits(['update:modelValue', 'showmodal'])


const show = computed({
  get() {

    return props.modelValue
  },
  set(value) {
    return emit('update:modelValue', value)
  }
})


const setname = (field) => {
  if (search.value) {
    loading.value = true
    setTimeout(() => {

      if (search.value.length > 2) {
        guideData.value[field + "_"] = []
        var sub = guideData.value[field].filter(v => v.name.toLowerCase().indexOf(search.value.toLowerCase()) >= 0)
        if (sub.length < 30)
          guideData.value[field + "_"] = sub
      }
      else guideData.value[field + "_"] = []

      loading.value = false
    }, 500)
  }
};



const getGuideData = () => {
  props.formDefinition.forEach(function (def, i) {
    if (def.type === 'select' || def.type === 'select2') {
      guideStore.getGuideData({
        url: def.url,
      }).then(response => {
        guideData.value[def.field] = response.data;
        guideData.value[def.field + "_"] = [];
      }).catch(error => {
        console.error(error)
      })
    }
  })
}

const updatefile = (file, field) => {
  if (formData.has(field))
    formData.set(field, file[0],file[0].name);
  else
    formData.append(field, file[0],file[0].name);
}


const Updateform = () => {
  props.formDefinition.forEach(function (def, i) {
    if (def.type === 'select2' && guideData.value && guideData.value[def.field]) {
      guideData.value[def.field + "_"] = []
      guideData.value[def.field + "_"] = guideData.value[def.field].filter(v => v.id === props.formData[def.field])
    }
  })
}



watchEffect(getGuideData)

watchEffect(Updateform)



const sendForm = Form => {
  props.formDefinition.forEach(function (def, i) {
    
    if (def.type=='file') return
    if (props.formData[def.field]) {
      if (formData.has(def.field))
        formData.set(def.field, props.formData[def.field]);
      else
        formData.append(def.field, props.formData[def.field]);
    }
    else formData.delete(def.field)

  })

  if (props.formParametrs) {
    if (formData.has(props.formParametrs))
      formData.set(props.formParametrs, props.formData[props.formParametrs]);
    else
      formData.append(props.formParametrs, props.formData[props.formParametrs]);
  }
  


  guideStore.sendFormData(formData, props.formMethod, props.formAction).then(response => {

    if (response.data.status) {
      emit('showmodal', response.data.status)
    }
  }).catch(error => {
    console.error(error)
  })
  emit('update:modelValue', false)
}



</script>

<template>
  <v-dialog v-model="show" width="auto" scrollable>
    <v-form @submit.prevent="sendForm" :method="formMethod" :action="formAction">
      <v-card width="400px" class="px-4">
        <v-card-title> </v-card-title>

        <div v-for="(def, index) in props.formDefinition.sort(sortByOrder)">
          <VTextField v-if="def.type === 'text'" class="my-4" :maxlength="def.limit" :name="def.field" clearable
            :label="def.title" variant="outlined" v-model="props.formData[def.field]" />

          <template v-if="def.type === 'date'">
            <p>{{ def.title }} : {{ props.formData[def.field] }} </p>
            <p> Новое значение</p>
            <VTextField class="my-4" :maxlength="def.limit" :name="def.field" clearable :label="def.title"
              variant="outlined" v-model="props.formData[def.field]" type="date" />
          </template>

          <v-autocomplete v-if="def.type === 'select2'" class="my-4" item-title="name" item-value="id" :label="def.title"
            :name="def.field" :items="guideData[def.field + '_']" hide-no-data clearable
            placeholder="Начните вводить название" :loading="loading" hide-details variant="outlined"
            v-model="props.formData[def.field]" v-model:search="search" @update:search="setname(def.field)">
          </v-autocomplete>

          <VSelect v-if="def.type === 'select'" class="my-4" item-title="name" item-value="id" :label="def.title"
            :name="def.field" :items="guideData[def.field]" v-model="props.formData[def.field]" variant="outlined">
          </VSelect>

          <VFileInput accept="image/png, image/jpeg" v-if="def.type === 'file'" v-model="props.formData[def.field]"
            clearable label="Выбрать файл" class="my-2" :show-size=1000 flat
            @update:modelValue="updatefile($event, def.field)" />

          <VImg v-if="def.type === 'img' && props.formData[def.field]" class="my-4"
            :src="'/storage/' + props.formData[def.field]" />

        </div>

        <v-card-actions>
          <v-btn color="primary" class="me-auto " @click="show = false">Закрыть</v-btn>
          <v-btn color="success" variant="flat" type="submit" class="mt-2">Сохранить</v-btn>
        </v-card-actions>
      </v-card>

    </v-form>

  </v-dialog>
</template>

<style lang="scss"></style>
