<script setup>
import { themeConfig } from '@themeConfig'

import axios from '@axios'





</script>

<template>
  <VRow class="auth-wrapper back" no-gutters>
    <VCol lg="7" class="d-none d-lg-flex">
      <div class="position-relative  rounded-lg rounded-lg w-100 ma-8 me-0">
        <div class="d-flex align-center justify-center w-100 h-100">
          <VImg max-width="371" src="/images/logolight.svg" class="auth-illustration  mb-2" />
        </div>

        <VImg class="auth-footer-mask" :src="authThemeMask" />
      </div>
    </VCol>

    <VCol cols="12" lg="5" class="d-flex align-center justify-center">
      <VCard flat :max-width="500" class="mt-12 mt-sm-0 pa-4">
        <VCardText>
          <div class="d-flex align-center  r w-100 h-100">
            <RouterLink class="text-primary ms-2 mb-1" :to="{ name: 'home' }">

              <VImg v-if="themeConfig.app.light" max-width="182" min-width="182" min-height="182"
                src="/images/logolight.svg" class="auth-illustration  mb-2" />
              <VImg v-else max-width="182" min-width="182" min-height="182" src="/images/logo-m.svg"
                class="auth-illustration  mb-2" />

            </RouterLink>
          </div>
          <h5 class="text-h5 font-weight-semibold mb-1">
         Ваша почта подтверждена.
          </h5>
          <p class="mb-0">
           
          </p>
        </VCardText>

      </VCard>
    </VCol>

  </VRow>
</template>

<style lang="scss">
@use "@core-scss/template/pages/page-auth.scss";
</style>


