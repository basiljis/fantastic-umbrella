<script setup>
import VueInlineCalendar from "vue-inline-calendar";
import "vue-inline-calendar/dist/style.css";
import EventCard from "@/layouts/components/EventCard.vue";


import {
  alphaDashValidator,
  emailValidator,
  requiredValidator,
  russianValidator,
  integerValidator,
} from "@validators";

const code = ref("");
const messageShow = ref(false);
const infoMessage = ref("");
const router = useRouter();
const isValidForm = ref(true);

const itemsPerPage = ref(6);
const page = ref(1);
const sortBy = ref();
const orderBy = ref();
const hideCompleted = ref(false);
const label = ref("All Courses");

const totalCourse = ref(10);

const selectedDate = ref(null);
const dateCalend = ref('')


const eventsCount = [
  {
    date: "18.05.2024",
    count: "44",
  },

  {
    date: "22.05.2024",
    count: "7",

  },
];





const courses = [
  {
    tags: "Web",
    rating: "4.4",
    ratingCount: "5",
    completedTasks: "4",
    tutorImg: "https://lipsum.app/640x480",
    totalTasks: "6",
    courseTitle: '"Эклеромания1111"',
    desc: "это новый курс, благодаря которому вы приручите капризное заварное тесто, научитесь готовить 9 разных видов эклеров. В каждом уроке - новые техники, глазури, кремы, начинки. Настоящая феерия вкусов!",
  },

  {
    tags: "Art",
    rating: "5.4",
    ratingCount: "5",
    completedTasks: "4",
    tutorImg: "https://lipsum.app/640x480",
    totalTasks: "6",
    courseTitle: '"Следопыт"',
    desc: "Испытание представляет собой умение ориентироваться на местности для преодоления определенного маршрута с препятствиями.",
  },
];

const resolveChipColor = (tags) => {
  if (tags === "Web") return "primary";
  if (tags === "Art") return "success";
  if (tags === "UI/UX") return "error";
  if (tags === "Psychology") return "warning";
  if (tags === "Design") return "info";
};
</script>


<template>
  <div class="container mx-4 main-page mt-0">


    <VRow>
      <VCol cols="12" class="">
        <vue-inline-calendar id="calendar-line" :eventsCount="eventsCount" @update:selected-date="selectedDate = $event"
          :enableMousewheelScroll="true" :show-year="false" locale="ru-RU" />

      </VCol>
    </VRow>
    <VRow>
      <VCol cols="12" lg="4">
        <div class="d-flex  gap-3">
          <AppDateTimePicker v-model="dateCalend" class="w-100" placeholder="Дата"  />
          <VSelect label="Направление" class="w-50" :items="['Туда', 'Сюда']" />
        </div>
      </VCol>
      <VCol cols="12" lg="4" class="px-lg-0">
        <div class="d-flex gap-3">

          <VSelect label="Формат" class="w-50" :items="['Тот', 'Этот']" />
          <VSelect label="Вид" class="w-50" :items="['Профиль', 'Фас']" />
        </div>
      </VCol>

      <VCol cols="12" lg="4">
        <div class="d-flex gap-3">
          <VSelect label="Сертификат" class="w-50" :items="['Росстест', 'ВСТЭК']" />
          <VTextField label="Поиск" class="w-50" prepend-inner-icon="tabler-search" />
        </div>
      </VCol>
    </VRow>
    <VRow >
      <VCol cols="12"  sm="6" md="4" lg="3" class="px-2">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          who="педагогическим работникам" bt_type="ok" />
      </VCol>

      <VCol cols="12"   sm="6" md="4" lg="3" class="px-2">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          color="warning" who="педагогическим работникам" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="px-2">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          color="success" who="педагогическим работникам" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          who="педагогическим работникам" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          color="success" who="педагогическим работникам" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          who="педагогическим работникам" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          color="success" who="педагогическим работникам" bt_type="plus" />
      </VCol>

      <VCol cols="12"  sm="6" md="4" lg="3" class="">
        <EventCard title="Дистанционно / Региональный / День открытых дверей" time="10:00 - 18:00" usercount="999"
          :date="new Date()"
          about="Особенности реализации адаптированных основных общеобразовательных программ на уровне основного общего образования"
          color="success" who="педагогическим работникам" bt_type="cancel" />
      </VCol>
    </VRow>

    <VPagination v-model="page" class="mt-5" :length="Math.ceil(totalCourse / itemsPerPage)">
      <template #prev="slotProps">
        <VBtn variant="tonal" color="default" v-bind="slotProps" :icon="false">
          Назад
        </VBtn>
      </template>
      <template #next="slotProps">
        <VBtn variant="tonal" color="default" v-bind="slotProps" :icon="false">
          Вперед
        </VBtn>
      </template>
    </VPagination>


    <!--VCol cols="3" class="">
      Для кого
      <sup
        >?
        <VTooltip activator="parent" location="top"> Для кого </VTooltip>
      </sup>

      <v-checkbox label="Все"></v-checkbox>

      <v-checkbox label="Администрация и педагогические работники"></v-checkbox>

      <v-checkbox label="Родители и дети"></v-checkbox>

      <VDivider class="mt-10" />
      <v-btn block variant="flat" type="submit" class=""> Мой календарь</v-btn>
      <VDivider />
      <v-btn block variant="flat" color="success" type="submit" class="">
        Назад</v-btn
      >
    </VCol-->


    <!--VCard class="mb-6 mt-15">
    <VCardText class="mx-10">

      <div
        class="d-flex justify-space-between align-center flex-wrap gap-4 mb-6"
      >
        <div>
          <h5 class="text-h5">My Courses</h5>
          <div class="text-body-1">Total 6 course you have purchased</div>
        </div>

        <div class="d-flex flex-wrap align-center gap-4">
          <VSelect
            v-model="label"
            :items="[
              { title: 'Web', value: 'web' },
              { title: 'Art', value: 'art' },
              { title: 'UI/UX', value: 'ui/ux' },
              { title: 'Psychology', value: 'psychology' },
              { title: 'Design', value: 'design' },
              { title: 'All Courses', value: 'All Courses' },
            ]"
            density="compact"
            style="min-inline-size: 250px"
          />
          <VSwitch v-model="hideCompleted" label="Hide Completed" />
        </div>
      </div>


      <div class="mb-6 mx-0">
        <VRow>
          <template v-for="course in courses" :key="course.id">
            <VCol cols="12" md="4" sm="6">
              <VCard flat border>
                <div class="pa-2">
                  <VImg
                    :src="course.tutorImg"
                    class="cursor-pointer"
                    @click="() => $router.push({ name: 'course' })"
                  />
                </div>
                <VCardText>
                  <div class="d-flex justify-space-between align-center mb-4">
                    <VChip
                      variant="tonal"
                      :color="resolveChipColor(course.tags)"
                      label
                    >
                      {{ course.tags }}
                    </VChip>
                    <div class="d-flex">
                      <span class="text-body-1 font-weight-medium align-center">
                        {{ course.rating }}
                      </span>
                      <VIcon
                        icon="tabler-star-filled"
                        color="warning"
                        class="me-2"
                        size="20"
                      />
                      <span class="text-body-1 text-disabled font-weight-medium"
                        >({{ course.ratingCount }})</span
                      >
                    </div>
                  </div>
                  <h5 class="text-h5 mb-1">
                    <RouterLink :to="{ name: 'course' }" class="course-title">
                      {{ course.courseTitle }}
                    </RouterLink>
                  </h5>
                  <p>
                    {{ course.desc }}
                  </p>
                  <div
                    v-if="course.completedTasks !== course.totalTasks"
                    class="d-flex align-center mb-4"
                  >
                    <VIcon icon="tabler-clock" size="20" class="me-1" />
                    <span class="text-body-1 my-auto"> {{ course.time }}</span>
                  </div>
                  <div v-else class="mb-2">
                    <VIcon icon="tabler-checks" color="success" class="me-1" />
                    <span class="text-success text-body-1">Completed</span>
                  </div>
                  <VProgressLinear
                    :model-value="
                      (course.completedTasks / course.totalTasks) * 100
                    "
                    rounded
                    color="primary"
                    height="8"
                    class="mb-6"
                  />
                  <div class="d-flex flex-wrap gap-4">
                    <VBtn
                      variant="tonal"
                      color="secondary"
                      class="flex-grow-1"
                      :to="{ name: 'course' }"
                    >
                      <template #prepend>
                        <VIcon
                          icon="tabler-rotate-clockwise-2"
                          class="flip-in-rtl"
                        />
                      </template>
                      Start Over
                    </VBtn>
                    <VBtn
                      v-if="course.completedTasks !== course.totalTasks"
                      variant="tonal"
                      class="flex-grow-1"
                      :to="{ name: 'course' }"
                    >
                      <template #append>
                        <VIcon icon="tabler-arrow-right" class="flip-in-rtl" />
                      </template>
                      Continue
                    </VBtn>
                  </div>
                </VCardText>
              </VCard>
            </VCol>
          </template>
        </VRow>
      </div>
      <VPagination
        v-model="page"
        :length="Math.ceil(totalCourse / itemsPerPage)"
      >
        <template #prev="slotProps">
          <VBtn
            variant="tonal"
            color="default"
            v-bind="slotProps"
            :icon="false"
          >
            Previous
          </VBtn>
        </template>
        <template #next="slotProps">
          <VBtn
            variant="tonal"
            color="default"
            v-bind="slotProps"
            :icon="false"
          >
            Next
          </VBtn>
        </template>
      </VPagination>
    </VCardText>
  </VCard-->

  </div>
</template>

<route lang="yaml">
meta:
  action: read
  subject: Testing
  redirectToDashboard: true
  breadcrumb: 
    - title: 'Календарь мероприятий'
    - title: 'Направление' 
            
</route>


<style lang="scss">
.main-page {
  .app-picker-field {

    width: 50%;
  }
}

.flat-picker-custom-style {
  padding-block: 10px;

  &.active {
    background: none;
  }

}

#calendar-line {


  .inline-calendar__dates {
    padding-top: 20px;


  }


  .inline-calendar__date {
    border: none !important;
    height: 80px !important;
    width: 70px !important;
    padding: 5px;
    position: relative;

    .date-item__day {
      font-size: 17px;
      font-weight: 700;
      line-height: 21.84px;
      letter-spacing: 0.1599999964237213px;
      text-align: center;
    }


    &.active {
      background-color: #28C76F !important;
      color: white !important;

      .date-item__day {
        color: white !important;
      }
    }

    .date-item__count {
      border-radius: 20px;
      height: 25px;
      width: 25px;
      position: absolute;
      background: #EA5455;
      color: white;
      font-size: 15px;
      font-weight: 700;
      letter-spacing: 0.08555514365434647px;
      text-align: center;
      padding: 3px;
      left: 60px;
      top: -10px;


    }

    &.today {
      background: #F6EAEA;
      color: black;

    }
  }
}
</style>
