<script setup>
import misc404 from '@images/pages/404.png'
import miscMaskDark from '@images/pages/misc-mask-dark.png'
import miscMaskLight from '@images/pages/misc-mask-light.png'
import { useGenerateImageVariant } from '@core/composable/useGenerateImageVariant'

const authThemeMask = useGenerateImageVariant(miscMaskLight, miscMaskDark)
</script>

<template>
  <div class="misc-wrapper ">

    <ErrorHeader error-title="Страница не найдена :(" />
    <VBtn to="/" class="mb-12 mt-12" color="#602699" rounded="0">
      На главную страницу
    </VBtn>

    <!-- 👉 Image -->
    <div class="misc-avatar w-100 d-flex justify-center text-center">
      <VImg max-width="371" src="/images/logolight.svg" class="auth-illustration  mb-2" />
    </div>

    <VImg :src="authThemeMask" class="misc-footer-img d-none d-md-block" />


    <v-footer class="d-flex align-end justify-start w-100">
      &copy; &nbsp; Яркие люди /
      {{ new Date().getFullYear() }}

    </v-footer>
  </div>
</template>

<style lang="scss">
@use "@core-scss/template/pages/misc.scss";

body {
  background-color: white !important;
}

.v-application {
  background-color: white !important;
}
</style>

<route lang="yaml">
meta:
  layout: blank
  action: read
  subject: Auth
</route>
