import { Ability } from '@casl/ability'
import CryptoJS from 'crypto-js';

export const initialAbility = [
  {
    action: 'read',
    subject: 'Auth',
  },
  {
    action: 'read',
    subject: 'Testing',
  },
]

//  Read ability from localStorage
// 👉 Handles auto fetching previous abilities if already logged in user
// ℹ️ You can update this if you store user abilities to more secure place
// ❗ Anyone can update localStorage so be careful and please update this

var stringifiedUserAbilities ='undefined'
if (localStorage.getItem('accessToken') && localStorage.getItem('accessToken') !== 'undefined' && localStorage.getItem('userAbilities'))
{
try
{
 stringifiedUserAbilities  = CryptoJS.AES.decrypt(localStorage.getItem('userAbilities'), localStorage.getItem('accessToken')).toString(CryptoJS.enc.Utf8)
}
catch (err) {
  localStorage.setItem('userAbilities','undefined')
}
//stringifiedUserAbilities  = localStorage.getItem('userAbilities')
}

//const stringifiedUserAbilities = localStorage.getItem('userAbilities')
const existingAbility = stringifiedUserAbilities && stringifiedUserAbilities !== 'undefined' ? JSON.parse(stringifiedUserAbilities) : null
export default new Ability(existingAbility || initialAbility)
