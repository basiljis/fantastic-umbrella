export default class RefStorageDefiner {
  constructor(name, options) {
  }

  get_storage() {

  }
}
    
