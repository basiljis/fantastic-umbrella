/* eslint-disable import/order */
//import '@/@fake-db/db'
import '@/@iconify/icons-bundle'
import App from '@/App.vue'
import ability from '@/plugins/casl/ability'
import i18n from '@/plugins/i18n'
import layoutsPlugin from '@/plugins/layouts'
import vuetify from '@/plugins/vuetify'
import { loadFonts } from '@/plugins/webfontloader'
import router from '@/router'
import { abilitiesPlugin } from '@casl/vue'
import '@core-scss/template/index.scss'
import '@styles/styles.scss'
import '@styles/header.scss'
import '@styles/home.scss'
import '@styles/item.scss'
import '@styles/event.scss'
import { createPinia } from 'pinia'
import { createApp } from 'vue'


/*

import 'froala-editor/js/plugins.pkgd.min.js';
//Import third party plugins
import 'froala-editor/js/third_party/embedly.min';
import 'froala-editor/js/third_party/font_awesome.min';
import 'froala-editor/js/third_party/image_tui.min';
// Import Froala Editor css files.

import 'froala-editor/css/froala_editor.pkgd.min.css';
import 'froala-editor/css/froala_style.min.css';

import VueFroala from 'vue-froala-wysiwyg';*/


import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css';
import rate from 'vue-rate'
import 'vue-rate/dist/vue-rate.css'

loadFonts()


// Create vue app
const app = createApp(App)


// Use plugins
app.use(vuetify)

app.use(createPinia())
app.use(router)
app.use(rate)
app.use(layoutsPlugin)
app.use(i18n)
app.use(abilitiesPlugin, ability, {
  useGlobalProperties: true,
})


//app.use(VueFroala);
app.component('QuillEditor', QuillEditor)

app.config.globalProperties.window = window
app.config.globalProperties.navigator = navigator
// Mount vue app
app.mount('#app')
