<script setup>
import { initialAbility } from '@/plugins/casl/ability'
import { useAppAbility } from '@/plugins/casl/useAppAbility'

const router = useRouter()
const ability = useAppAbility()
const userData = JSON.parse(localStorage.getItem('userData') || 'null')

const logout = () => {

  // Remove "userData" from localStorage
  localStorage.removeItem('userData')

  // Remove "accessToken" from localStorage
  localStorage.removeItem('accessToken')
  router.push('/login').then(() => {

    // Remove "userAbilities" from localStorage
    localStorage.removeItem('userAbilities')

    // Reset ability to initial ability
    ability.update(initialAbility)
  })
}
</script>

<template>
  <VBadge dot location="bottom right" offset-x="3" offset-y="3" bordered color="success">
    <div class="d-sm-flex  d-none align-center">
      {{ userData?.name }}
      {{ userData?.ooid_name }}
      {{ userData?.rolename }}
    </div>

    <!--VImg v-if="userData?.avatar" :src="'/storage/' + userData?.avatar" />
      <VIcon v-else icon="tabler-user" /-->

    <!-- SECTION Menu -->
    <VMenu activator="parent" width="230" location="bottom end" offset="14px">

      <template v-slot:activator="{ on }">
        <VAvatar v-on="on" icon="tabler-user" class="cursor-pointer ms-3" color="primary" variant="tonal"
          :image="userData?.avatar ? '/storage/' + userData?.avatar : ''"></VAvatar>
      </template>


      <VList>
        <!-- 👉 User Avatar & Name -->
        <VListItem>
          <template #prepend>
            <VListItemAction start>
              <VBadge dot location="bottom right" offset-x="3" offset-y="3" color="success">
                <VAvatar color="primary" variant="tonal" 
                :image="userData?.avatar ? '/storage/' + userData?.avatar : ''" icon="tabler-user">

                </VAvatar>
              </VBadge>
            </VListItemAction>
          </template>

          <VListItemTitle class="font-weight-semibold">
            {{ userData?.fullName }}
          </VListItemTitle>
          <VListItemSubtitle>{{ userData?.role }}</VListItemSubtitle>
        </VListItem>






        <VListItem :to="{ name: 'profile', params: { tab: 'account' } }">
          <template #prepend>
            <VIcon class="me-2" icon="tabler-settings" size="22" />
          </template>

          <VListItemTitle>Профиль</VListItemTitle>
        </VListItem>


        <!--VListItem :to="{ name: 'pages-pricing' }">
            <template #prepend>
              <VIcon
                class="me-2"
                icon="tabler-currency-dollar"
                size="22"
              />
            </template>

            <VListItemTitle>Pricing</VListItemTitle>
          </VListItem>

 
          <VListItem :to="{ name: 'pages-faq' }">
            <template #prepend>
              <VIcon
                class="me-2"
                icon="tabler-help"
                size="22"
              />
            </template>

            <VListItemTitle>FAQ</VListItemTitle>
          </VListItem-->


        <VDivider class="my-2" />

        <!-- 👉 Logout -->
        <VListItem link @click="logout">
          <template #prepend>
            <VIcon class="me-2" icon="tabler-logout" size="22" />
          </template>

          <VListItemTitle>Выйти</VListItemTitle>
        </VListItem>
      </VList>
    </VMenu>
    <!-- !SECTION -->

  </VBadge>
</template>
