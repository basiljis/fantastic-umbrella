<script setup>
import { login } from "@/views/apps/helpers";
import { register } from "@/views/apps/helpers";
import { useAppAbility } from '@/plugins/casl/useAppAbility'
import DialogForm from "@/layouts/components/DialogForm.vue";
import { useConstStore } from "@/views/apps/useConstStore"

import {
  alphaDashValidator,
  emailValidator,
  requiredValidator,
  russianValidator,
  integerValidator,
  confirmedValidator,
} from "@validators";
const constStore = useConstStore()

const props = defineProps({
  selected_event: {
    type: String,
    required: true,
  },

  show: {
    type: Boolean,
    required: true,
  },


});

const dialogActive = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')

const router = useRouter()

const ability = useAppAbility()

//const loginShow = ref(false);
const registerShow = ref(false);
const refLoginForm = ref()
const refRegisterForm = ref()
const email = ref('')
const password = ref('')
const rememberMe = ref(false)
const isPasswordVisible = ref(false)
const errors = ref({
  email: undefined,
  password: undefined,
})



const messageShow = ref(false);
const infoMessage = ref("");



const username = ref('')
const emailreg = ref('')
const passwordreg = ref('')
const password_ = ref('')
const phone = ref('')
const privacyPolicies = ref(false)
const mailSending = ref(false)
const rules = ref(false)

const emit = defineEmits(["closemodal"]);

/*
watchEffect(() => {
 loginShow.value = props.show

 if (!loginShow.value) emit('closemodal')
})
*/


const onSubmitlogin = () => {

  refLoginForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid) {

      login(email.value, password.value).then(res => {
        errors.value = res.errors
        if (res.success) {
          //loginShow.value = false
          ability.update(res.abilities)
          emit('closemodal', false,true)

         /*  if (!isNaN(props.selected_event))
            router.push({ name: 'registerevent', params: { event: props.selected_event } })
          else w_open(props.selected_event)*/

        }
      })


    }
  })
}


const onSubmitregister = () => {

  refRegisterForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid) {


      register(phone.value, emailreg.value, username.value, passwordreg.value, password_.value,
        privacyPolicies.value, mailSending.value, rules.value).then(res => {
          errors.value = res.errors
          if (res.success) {

            registerShow.value = false
            infoMessage.value = res.message
            phone.value = ''
            emailreg.value = ''
            username.value = ''
            privacyPolicies.value = false
            mailSending.value = false
            rules.value = false
            messageShow.value = true

            refRegisterForm.value.reset()

            ability.update(res.abilities)

          }
        })

    }
  })
}


const w_open = (url) => {
  // window.location.href = 'https://www.google.com';
  window.open(url, '_blank');
}



</script>



<template>
  <v-dialog v-model="messageShow" width="auto">
    <DialogCloseBtn @click="messageShow = !messageShow" />
    <v-card class="px-4">
      <v-card-title>

      </v-card-title>
      <v-card-text v-html="infoMessage"> </v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="messageShow = false">Закрыть</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>


  <DialogForm :formActive="dialogActive" @closeform="dialogActive = false" :title="dialogTitle" :text="dialogText" />

  <v-dialog v-model="registerShow" max-width="600" class="h-100">
    <DialogCloseBtn @click="registerShow = !registerShow" />


    <VForm ref="refRegisterForm" @submit.prevent="onSubmitregister" class="register-form">

      <v-card class="px-4">

        <v-card-title class="px-4">
          Для регистрации на мероприятие необходимо войти в систему.
        </v-card-title>
        <v-card-text>
          <VRow>
            <!-- Username -->
            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">Ваше имя </p>
              <VTextField v-model="username" :rules="[requiredValidator, russianValidator]" label="Ваше имя"
                class="no-border" />
            </VCol>

            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">МОБИЛЬНЫЙ ТЕЛЕФОН </p>
              <VTextField pattern="[1-4]{5}" v-model="phone" :rules="[requiredValidator]" label="МОБИЛЬНЫЙ ТЕЛЕФОН"
                class="no-border" />
            </VCol>

            <!-- email -->
            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">ЭЛЕКТРОННАЯ ПОЧТА </p>
              <VTextField v-model="emailreg" :rules="[requiredValidator, emailValidator]" label="ЭЛЕКТРОННАЯ ПОЧТА"
                class="no-border" type="email" :error-messages="errors.email" />
            </VCol>

            <!-- password -->
            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">ПАРОЛЬ </p>
              <VTextField v-model="passwordreg" :rules="[requiredValidator]" label="Пароль" class="no-border"
                :type="isPasswordVisible ? 'text' : 'password'"
                :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'"
                @click:append-inner="isPasswordVisible = !isPasswordVisible" />
            </VCol>

            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">Повторить пароль </p>
              <VTextField v-model="password_" :rules="[requiredValidator, confirmedValidator(password_, passwordreg)]"
                class="no-border" label="Повторить пароль" :type="isPasswordVisible ? 'text' : 'password'"
                :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'"
                @click:append-inner="isPasswordVisible = !isPasswordVisible" />
            </VCol>


            <VCol cols="12">
              <VCheckbox label="Даю согласие на обработку моих персональных данных" id="privacy-policy"
                v-model="privacyPolicies" :rules="[requiredValidator]" />
              <VCheckbox label="Подписаться на рассылки" id="mailSending" v-model="mailSending" />
              <VCheckbox id="rules" v-model="rules">
                <template v-slot:label>
                  <div class="d-flex">
                    Правила &nbsp;
                    <div class=" cursor-pointer "
                      @click=" dialogTitle = 'Правила посещения'; dialogText = constStore.rules; dialogActive = true">
                      посещения</div>
                  </div>
                </template>
              </VCheckbox>
              <div class="w-100 d-flex">
                <VBtn type="submit" class="mt-5 fw-16 fs-700 mx-auto px-15" color="#602699" rounded="0">
                  Отправить
                </VBtn>
              </div>
            </VCol>

            <!-- create account -->
            <VCol cols="12" class="text-center text-base  d-block d-lg-none">
              <span>У вас есть аккаунт? </span>
              <a @click="registerShow = false; emit('closemodal', true,false)" class="cursor-pointer">
                Войти
              </a>
            </VCol>
          </VRow>

        </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="registerShow = false">Закрыть</v-btn>
        </v-card-actions>
      </v-card>
    </VForm>

  </v-dialog>

  <v-dialog v-model="props.show" max-width="600" class="h-100">
    <DialogCloseBtn @click="emit('closemodal', false,false)" />
    <VForm ref="refLoginForm" @submit.prevent="onSubmitlogin" class="register-form">
      <v-card class="px-4">

        <v-card-title class="px-4">
          Для регистрации на мероприятие необходимо войти в систему.
        </v-card-title>
        <v-card-text>

          <VRow>
            <!-- email -->
            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">Логин (адрес электронной почты) </p>
              <VTextField v-model="email" label="Логин (адрес электронной почты)" type="email" class="no-border"
                placeholder="fio@mail.u" :rules="[requiredValidator, emailValidator]" :error-messages="errors.email" />
            </VCol>

            <!-- password -->
            <VCol cols="12">
              <p class="color-black fs-16 fw-700 text-uppercase">Пароль </p>
              <VTextField v-model="password" label="Пароль" :rules="[requiredValidator]"
                :type="isPasswordVisible ? 'text' : 'password'" :error-messages="errors.password"
                :append-inner-icon="isPasswordVisible ? 'tabler-eye-off' : 'tabler-eye'" class="no-border"
                @click:append-inner="isPasswordVisible = !isPasswordVisible" />

              <div class="d-flex align-center flex-wrap justify-space-between mt-2 mb-4">
                <VCheckbox v-model="rememberMe" label="Запомнить меня" />
                <a class="text-primary ms-2 mb-1" href="/forgot-password">
                  Забыли пароль?
                </a>
              </div>

              <VBtn block type="submit" color="#602699" rounded="0">
                Войти
              </VBtn>
            </VCol>

            <!-- create account -->
            <VCol cols="12" class="text-center">
              <span>Впервые? </span>
              <a @click=" emit('closemodal', false,false); registerShow = true;" class="cursor-pointer">
                Получить доступ
              </a>
            </VCol>

          </VRow>
        </v-card-text>
        <v-card-actions>
          <v-btn color="primary" class="me-auto" @click="emit('closemodal', false,false)">Закрыть</v-btn>
        </v-card-actions>
      </v-card>
    </VForm>



  </v-dialog>
</template>





<style lang="scss"></style>
