<script setup>
const props = defineProps({
  title: {
    type: String,
    required: false,
  },
  usercount: {
    type: String,
    required: false,
  },

  date: {
    type: Date,
    required: true,
  },

  time: {
    type: String,
    required: true,
  },

  color: {
    type: String,
    required: false,
    default: "none",
  },

  about: {
    type: String,
    required: false,
  },

  who: {
    type: String,
    required: false,
  },

  bt_type: {
    type: String,
    required: false,
  },
});
</script>



<template>
  <v-card class="event-card mx-auto  ">
    <VRow>
      <VCol cols="3" class="ps-5 pt-5">

        <div v-if="usercount" class="usercount">
          <div class=" d-flex align-center">
            <VIcon :size="10" icon="tabler:circle-filled" class="me-0" color="info" /> +{{ usercount }}
          </div>
        </div>
      </VCol>
      <VCol cols="6" class="pt-15 justify-center d-flex">


        <VImg width="97" src="/images/event-pic.png" class="auth-illustration mb-2" />

      </VCol>
      <VCol cols="3" class="pt-5 pe-5 ">
        <div class="ava">
          <div>
            <VAvatar :color="color" size="large">
              {{ date.toLocaleString("ru-Ru", { weekday: "short" }) }}<br />
              {{ date.toLocaleString("ru-Ru", { day: "2-digit" }) }}<br />
              {{ date.toLocaleString("ru-Ru", { month: "short" }) }}
            </VAvatar>
          </div>
          <div class="text-center month-name">
            
          </div>
        </div>
      </VCol>
    </VRow>
    <div class="d-flex mt-2">
      <VChip color="primary" class="text-center mx-auto" :label="false" variant="elevated">
        <div class="text-center">{{ time }}</div>
      </VChip>
    </div>

    <v-card-text class="text-center color-blue fs-15 fw-600 lh-12 ">
      {{ title }}
    </v-card-text>

    <v-card-text class="text-center fs-17 text-uppercase ">
      {{ about }}
    </v-card-text>

    <!--v-card-text>
      {{ who }}
    </v-card-text-->

    <!--v-card-actions class="justify-center d-flex">



      <v-btn color="primary"  rounded="0" class=" mx-0 rounded-s"  variant="outlined">
        <VIcon start icon="tabler-search" />
        Подробнее
      </v-btn>

      <v-btn v-if="bt_type == 'plus'" rounded="0" variant="outlined" type="submit" class=" mx-0 rounded-e" >
        <VIcon size="20" icon="tabler-plus" /> Регистрация
      </v-btn>
      <v-btn v-else-if="bt_type == 'cancel'" color="error" rounded="0" variant="outlined" type="submit" class="mx-0 rounded-e">
        <VIcon size="20" class="me-0" icon="tabler-circle-x" /> Отмена
      </v-btn>
      <v-btn v-else-if="bt_type == 'ok'" color="success" rounded="0" variant="outlined" type="submit" class="mx-0 rounded-e">
        <VIcon size="20" class="me-0" icon="tabler-check" /> OK
      </v-btn>
      <v-btn v-else color="primary" rounded="0" variant="outlined" type="submit" class=" mx-0 rounded-e">Регистрация</v-btn>

  
    </v-card-actions-->


    <v-card-actions class="justify-center  d-flex">
      <v-btn color="primary" rounded="0" class=" me-0 rounded-s fw-600 fs-17  ">
        Подробнее
      </v-btn>

      <v-btn v-if="bt_type == 'plus'" rounded="0" variant="flat" type="submit" class="rounded-e mx-0 fw-600 fs-17 ">
        <VTooltip activator="parent" location="top">
          Регистрация на мероприятие
        </VTooltip> Регистрация
      </v-btn>
      <v-btn v-else-if="bt_type == 'cancel'" color="error" rounded="0" variant="flat" type="submit"
        class="rounded-e mx-0 fw-600 fs-17 ">
        <VTooltip activator="parent" location="top">
          Оменить регистрацию на мероприятие
        </VTooltip>
        Отмена
      </v-btn>
      <v-btn v-else-if="bt_type == 'ok'" color="warning" rounded="0" variant="flat" type="submit"
        class="rounded-e   mx-0 fw-600 fs-17 ">
        Вы зарегистрированы
      </v-btn>
      <v-btn v-else color="success" rounded="0" variant="flat" type="submit" class="rounded-e mx-0 flex-grow-1 fw-600 fs-17 ">
        <VTooltip activator="parent" location="top">
          Регистрация на мероприятие
        </VTooltip>
        Регистрация
      </v-btn>
    </v-card-actions>
  </v-card>
</template>





<style lang="scss">
.event-card {

  .bt-card
  {
    max-width: 130px;

  }

  .ava {
    max-width: 48px;
    ;

  }
}
</style>
