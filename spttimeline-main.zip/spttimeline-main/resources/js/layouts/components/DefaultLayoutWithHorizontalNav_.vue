<script setup>
import navItems from "@/navigation/horizontal";
import { useThemeConfig } from "@core/composable/useThemeConfig";
import { themeConfig } from "@themeConfig";

// Components
import Footer from "@/layouts/components/Footer.vue";
import NavBarI18n from "@/layouts/components/NavBarI18n.vue";
import NavBarNotifications from "@/layouts/components/NavBarNotifications.vue";
import NavbarShortcuts from "@/layouts/components/NavbarShortcuts.vue";
import NavbarThemeSwitcher from "@/layouts/components/NavbarThemeSwitcher.vue";
import NavSearchBar from "@/layouts/components/NavSearchBar.vue";
import UserProfile from "@/layouts/components/UserProfile.vue";
import { HorizontalNavLayout } from "@layouts";
import { VNodeRenderer } from "@layouts/components/VNodeRenderer";
import { isUserLoggedIn } from '@/router/utils'
import { useRouter } from 'vue-router'

const { appRouteTransition } = useThemeConfig();
const userData = JSON.parse(localStorage.getItem('userData') || 'null')
const breadCrumbs = ref([])
const router = useRouter()
const route = useRoute()

const getBreadcrumbs = () => {
  breadCrumbs.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      breadCrumbs.value.push(item)
    })
  }
}


watchEffect(getBreadcrumbs)


</script>

<template>
  <HorizontalNavLayout :nav-items="isUserLoggedIn() ? navItems : null">
    <!-- 👉 navbar -->
    <template #navbar>
      <RouterLink to="/" class="app-logo d-flex align-center gap-x-10">
        <VImg v-if="themeConfig.app.light"
              min-width="102" min-height="102"
              src="/images/logolight.svg"
              class="auth-illustration  mb-2"
            />
            <VImg v-else
              min-width="102" min-height="102"
              src="/images/logo-m.svg"
              class="auth-illustration  mb-2"
            />
        <h1 class="app-title font-weight-bold leading-normal text-xl">
          {{ themeConfig.app.title }}
        </h1>
      </RouterLink>
      <VSpacer />

      <!--NavSearchBar trigger-btn-class="ms-lg-n3" /-->
      <!--ul v-if="isUserLoggedIn()" class="main-nav d-flex gap-3">
        <li>
          <VBtn icon="tabler-home" size="37" rounded href="#" />
        </li>
        <li>
          <VBtn icon="tabler-calendar" size="37" rounded href="#" variant="text" />
        </li>
        <li>
          <VBtn icon="tabler-zoom-exclamation" size="37" rounded href="#" variant="text"/>
        </li>
        <li>
          <VBtn icon="tabler-key" rounded size="37" href="#" variant="text" />
        </li>
        <li>
          <VBtn icon="tabler-checkbox" size="37" rounded href="#" variant="text" />
        </li>
        <li>
          <VBtn icon="tabler-heart" size="37" rounded href="#" variant="text" />
        </li>

      </ul-->
      <VSpacer />
      <!--NavBarI18n />
      <NavbarThemeSwitcher />
      <NavbarShortcuts />
      <NavBarNotifications class="me-2" /-->
      <UserProfile v-if="isUserLoggedIn()" />
      <template v-else>
        
        <VBtn href="/login" color="success" class="me-5">
          Войти
        </VBtn>
        <VBtn href="/register">
          Зарегестрироваться
        </VBtn>


      </template>
    </template>

    <v-breadcrumbs :items="breadCrumbs" class="fs-15">
      <template v-slot:divider>
        <v-icon icon="tdesign:chevron-right-double-s"></v-icon>
      </template>
    </v-breadcrumbs>

    <!-- 👉 Pages -->
    <RouterView v-slot="{ Component, route }">
      <Transition :name="appRouteTransition" mode="out-in">
        <Component :is="Component" :key="route.path" />
      </Transition>
    </RouterView>

    <!-- 👉 Footer -->
    <template #footer>
      <Footer />
    </template>

    <!-- 👉 Customizer -->
    <!--TheCustomizer /-->
  </HorizontalNavLayout>
</template>

<style lang="scss">
.active {
  background: #7367f0;
  border-radius: 5px;
}

.login-item {
  display: flex;
  align-items: center;
}

.v-btn--rounded.v-btn--icon {
  border-radius: 6px;
}

.main-nav li {

  display: inline;
}

.layout-navbar
{

//background-color: #602699;




}
</style>
