<script setup>
import { themeConfig } from "@themeConfig";
const router = useRouter()


function goLogin(data) {
  router.push({ path: '/login' })
}

</script>




<template>
  <v-app-bar class="top-menu " scroll-behavior="hide" density="compact" scroll-threshold="30">
    <VImg v-if="themeConfig.app.light" max-width="88" height="100%" src="/images/logolight.svg"
      class="auth-illustration  mb-2" />
    <VImg v-else max-width="88" height="100%" src="/images/logo-m.svg" class="auth-illustration  mb-2" />



    <VBtn href="/login" color="success" class="ms-auto me-3" variant="flat">
      Войти
    </VBtn>
    <VBtn href="/register" variant="flat">
      Зарегестрироваться
    </VBtn>
  </v-app-bar>


  <v-breadcrumbs :items="breadCrumbs" class="fs-15">
    <template v-slot:divider>
      <v-icon icon="tdesign:chevron-right-double-s"></v-icon>
    </template>
  </v-breadcrumbs>
</template>

<route lang="yaml">
meta:
  action: read
  subject: Testing
</route>



<style lang="scss">
.top-menu {
  background: rgba(255, 255, 255, 0.5) !important;

}
</style>
