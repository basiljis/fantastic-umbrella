<script setup>
import axios from '@axios'

const formActive = ref(false)
const isshown = ref(false)

const props = defineProps({
  formActive: {
    type: Boolean,
  },
  title: {
    type: String,
  },
  text: {
    type: String,
  },

})

const emit = defineEmits(["closeform"]);



watchEffect(() => {
  props.formActive
  if (isshown.value == false && props.formActive==true  && formActive.value == false)
  {
    isshown.value = true
    formActive.value = props.formActive
  }
  else
  {
    isshown.value = false
    emit('closeform', false)
  }
  
 
})


const sendlink = () => {
  axios.post('/email/verification-notification',
    {},
  ).then(r => {
    formActive.value = false; emit('closeform', false);
  }).catch(e => {
    console.error(e)
  })
}

</script>





<template>
  <v-dialog max-width="800" v-model="formActive">

    <v-card :title="props.title">
      <v-card-text class="dialog-text" v-html="props.text" />
      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn text="Закрыть" variant="flat" color="#602699" rounded="0"
          @click="formActive = false; emit('closeform', false);"></v-btn>
        <v-btn v-if="props.title == 'Пользователь не подтвержден'" text="Выслать ссылку активации повторно" variant="flat"
          color="#602699" rounded="0" @click="sendlink"></v-btn>

      </v-card-actions>
    </v-card>
  </v-dialog>
</template>





<style lang="scss">
.dialog-text {
  li {

    padding-left: 40px;
  }

}
</style>
