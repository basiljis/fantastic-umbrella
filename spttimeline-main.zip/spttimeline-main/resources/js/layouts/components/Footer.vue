<script setup>
import { isUserLoggedIn } from '@/router/utils'
</script>
<template>
  <div class=" pa-10 d-none d-sm-flex" v-if="!isUserLoggedIn()">
    <div class=" d-flex flex-column">
      <div class=" me-auto">
        <RouterLink to="/" class="app-logo ">
          <VImg min-width="190" max-width="190" min-height="90" src="/images/logowhite.svg"
            class="auth-illustration mb-2" />
        </RouterLink>

      </div>
      <div class="d-flex justify-space-between mt-4">
        <a href="https://t.me/bright_people_agency" target="_blank">
          <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/telegrammw.svg" class=" " />
        </a>
        <a href="https://ru.pinterest.com/Bright_people_agency/" target="_blank">
          <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/hzw.svg" class=" " />
        </a>
        <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/watsupw.svg" class=" " />
        <a href="https://www.youtube.com/channel/UCnJPK_HUOXWQjQjsLx4_6XA" target="_blank">
          <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/youtubew.svg" class=" " />
        </a>
        <a href="https://vk.com/bright_people_agency" target="_blank">
          <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/vkw.svg" class=" " />
        </a>
      </div>
      <p class="color-white fs-15  mt-5">© 2023-{{ new Date().getFullYear() }} Bright People<br>Агентство "Яркие люди"
      </p>

    </div>


    <div class="ps-15 mt-auto">

      <p class="color-white fs-15  mt-5">КОНТАКТЫ<br>
        ООО «Компания «Брайт пипл»<br>ИНН 772382011<br>ОГРН 1117746957426
      </p>
      <p class="color-white fs-15  mt-5">

        123557, г. Москва, пер Электрический, д.1,<br> стр.12, помещ./эт. I/7 ком 708<br>
        +7 (495) 648-63-58<br> <a class="color-white" href="mailto:tickets@br-people.ru">tickets@br-people.ru</a></p>

    </div>



    <div class="ps-15 d-flex my-auto align-items-center">
      <div>
        <a class="color-white fs-15  " href="https://headquaters.space">HEADQUATERS </a>
      </div>
    </div>



  </div>


  <div class="d-sm-none py-8 d-flex" v-if="!isUserLoggedIn()">

    <div class="d-flex">
      <div>
        <div class="ms-10 d-flex flex-column gap-8 me-3">
          <a href="https://t.me/bright_people_agency" target="_blank">
            <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/telegrammw.svg" class=" " />
          </a>
          <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/watsupw.svg" class=" " />
          <a href="https://www.youtube.com/channel/UCnJPK_HUOXWQjQjsLx4_6XA" target="_blank">
            <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/youtubew.svg" class=" " />
          </a>
          <a href="https://vk.com/bright_people_agency" target="_blank">
            <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/vkw.svg" class=" " />
          </a>
        </div>
      </div>
      <div class="d-flex flex-column  ms-5  align-center">
        <p class="fw-600 white-color ma-0 fs-13 vertical "> ПОДПИШИТЕСЬ</p>
        <hr class=" h-100  white-color mt-3">
      </div>

    </div>
    <div class=" mx-auto ">
      <RouterLink to="/" class="app-logo ">
        <VImg min-width="150" max-width="190" min-height="90" src="/images/logowhite.svg"
          class="auth-illustration mb-2" />
      </RouterLink>
      <p class="color-white fs-15  mt-5">© 2023-{{ new Date().getFullYear() }} Bright People<br>Агентство "Яркие люди"
      </p>
      <div>
        <a class="color-white fs-15  " href="https://headquaters.space">HEADQUATERS </a>
      </div>

    </div>


  </div>




  <div v-if="isUserLoggedIn()" class='d-sm-none w-100' style="position: fixed; bottom:0px ">
    <div v-if="isUserLoggedIn()" class="d-sm-none page-footer   py-5 align-center justify-space-around d-flex"
      style="  background-color:white; " :v-if="isUserLoggedIn()">

      <RouterLink to="/">
        <VImg min-width="24" src="/images/icons/home.svg" class="cursor-pointer " />
      </RouterLink>

      <RouterLink v-if="$can('manage', 'all')" :to="{ name: 'apps-users-list' }">
        <VImg min-width="24" src="/images/icons/user.svg" class="cursor-pointer " />
      </RouterLink>

      <!--RouterLink :to="{ name: 'editevent', params: { event: '1' } }">
      <VImg min-width="53" src="/images/icons/addevent.svg" class="cursor-pointer " />
    </RouterLink-->

      <VMenu transition="slide-y-transition" v-if="$can('manage', 'all')">
        <template #activator="{ props }">
          <VBtn v-bind="props" icon variant="text" color="default" class="menu-button" size="small">
            <VImg min-width="24" src="/images/icons/beach.svg" class="cursor-pointer " />
          </VBtn>
        </template>
        <v-list>
          <!--v-list-item>
        <RouterLink :to="{ name: 'apps-usertypes-list' }">
          Уровни доступа
        </RouterLink>
      </v-list-item-->
          <v-list-item>
            <RouterLink :to="{ name: 'apps-spr-action-types-list' }">
              Типы мероприятий
            </RouterLink>
          </v-list-item>
          <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-action-forms-list' }">
          Форматы мероприятий
        </RouterLink>
      </v-list-item-->
          <v-list-item>
            <RouterLink :to="{ name: 'apps-spr-ages-list' }">
              Возрастные промежутки
            </RouterLink>
          </v-list-item>
          <v-list-item>
            <RouterLink :to="{ name: 'apps-spr-participants-list' }">
              С участием
            </RouterLink>
          </v-list-item>
          <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-partners-list' }">
          Партнеры мероприятий
        </RouterLink>
      </v-list-item-->
          <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-event-status-list' }">
          Статусы мероприятий
        </RouterLink>
      </v-list-item-->
          <v-list-item>
            <RouterLink :to="{ name: 'apps-logs-list' }">
              Лог авторизаций
            </RouterLink>
          </v-list-item>
          <v-list-item>
            <RouterLink :to="{ name: 'apps-logs-mail-list' }">
              Лог отправки почты
            </RouterLink>

          </v-list-item>
        </v-list>
      </VMenu>


      <RouterLink :to="$can('manage', 'all') ? { name: 'eventslistadm', } : { name: 'eventslistuser', }">
        <VImg min-width="24" src="/images/icons/calendar.svg" class="cursor-pointer " />
      </RouterLink>

    </div>
  </div>
</template>
