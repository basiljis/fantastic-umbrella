<script setup>
import { initialAbility } from '@/plugins/casl/ability'
import { useAppAbility } from '@/plugins/casl/useAppAbility'
import { ref, onMounted } from 'vue'
const router = useRouter()
const ability = useAppAbility()
const userData = JSON.parse(localStorage.getItem('userData') || 'null')
const currentMenu = ref('1')


const props = defineProps({

  menu: {
    type: String
  },



})


const emit = defineEmits(["menuChange"]);

const menus =
  [
    {
      'id': '1',
      'name': 'Спектакли',
      'color': 'back-red',
    },

    {
      'id': '2',
      'name': 'Городские мероприятия',
      'color': 'back-blue',
    },
    {
      'id': '3',
      'name': 'Фестивали',
      'color': 'back-yellow',
    },
    {
      'id': '4',
      'name': 'Экскурсии',
      'color': 'back-fiolet',
    },
    {
      'id': '5',
      'name': 'Лекции',
      'color': 'back-red',
    },
    {
      'id': '6',
      'name': 'Концерты',
      'color': 'back-blue',
    }
    , {
      'id': '7',
      'name': 'Выставки',
      'color': 'back-yellow',
    }
  ]

onMounted(() => {
  emit("menuChange", menus.find(o => o.id === currentMenu.value).name);
})

const setmenu = (id) => {
  currentMenu.value = id
  emit("menuChange", menus.find(o => o.id === currentMenu.value).name);
}


</script>

<template>
  <VCol cols="4" lg="2">

    <template v-for="menu in menus">

      <div v-if="menu.id !== currentMenu" class="cursor-pointer ps-5 py-5 " :class="menu.color" @click="setmenu(menu.id)">

        <p class="mt-auto fs-18 fw-600 mb-0 px-5">{{ menu.name }}</p>

      </div>
      <div v-else class="ps-5 py-3 " :class="menu.color">
        <p class="mt-auto fs-100 mb-16 fw-700 gothic px-5">00</p>
        <p class="mt-auto fs-18 fw-600 px-5">{{ menu.name }}</p>
      </div>


    </template>


  </VCol>
</template>
