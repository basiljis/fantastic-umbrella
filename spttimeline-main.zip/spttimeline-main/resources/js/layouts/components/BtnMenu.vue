<script setup>
const router = useRouter()

</script>



<template>
  <RouterLink to="/">
        <VImg min-width="24" src="/images/icons/home.svg" class="cursor-pointer " />
      </RouterLink>
  <RouterLink :to="{ name: 'apps-users-list' }" v-if="$can('manage','all')" >
    <VImg min-width="24" src="/images/icons/user.svg" class="cursor-pointer " />
  </RouterLink>

  <VMenu transition="slide-y-transition" v-if="$can('manage','all')" >
    <template #activator="{ props }">
      <VBtn v-bind="props" icon variant="text" color="default" class="menu-button" size="small">
        <VImg min-width="24" src="/images/icons/beach.svg" class="cursor-pointer " />
      </VBtn>
    </template>
    <v-list>
      <!--v-list-item>
        <RouterLink :to="{ name: 'apps-usertypes-list' }">
          Уровни доступа
        </RouterLink>
      </v-list-item-->
      <v-list-item>
        <RouterLink :to="{ name: 'apps-spr-action-types-list' }">
          Типы мероприятий
        </RouterLink>
      </v-list-item>
      <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-action-forms-list' }">
          Форматы мероприятий
        </RouterLink>
      </v-list-item-->
      <v-list-item>
        <RouterLink :to="{ name: 'apps-spr-ages-list' }">
          Возрастные промежутки
        </RouterLink>
      </v-list-item>
      <v-list-item>
        <RouterLink :to="{ name: 'apps-spr-participants-list' }">
         С участием
        </RouterLink>
      </v-list-item>
      <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-partners-list' }">
          Партнеры мероприятий
        </RouterLink>
      </v-list-item-->
      <!--v-list-item>
        <RouterLink :to="{ name: 'apps-spr-event-status-list' }">
          Статусы мероприятий
        </RouterLink>
      </v-list-item-->
      <v-list-item>
        <RouterLink :to="{ name: 'apps-logs-list' }">
              Лог авторизаций
            </RouterLink>

      </v-list-item>
      <v-list-item>
        <RouterLink :to="{ name: 'apps-logs-mail-list' }">
          Лог отправки почты
        </RouterLink>

      </v-list-item>
    </v-list>
  </VMenu>


  <RouterLink   :to="$can('manage','all') ?  { name: 'eventslistadm', } : { name: 'eventslistuser', } ">
    <VImg min-width="24" src="/images/icons/calendar.svg" class="cursor-pointer " />
  </RouterLink>
</template>





<style lang="scss"></style>
