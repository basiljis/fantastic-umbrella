<script setup>
import { useConstStore } from "@/views/apps/useConstStore"
import MailForm from "@/layouts/components/MailForm.vue";
import DialogForm from "@/layouts/components/DialogForm.vue";
const router = useRouter()


const mailActive = ref(false)
const constStore = useConstStore()
const dialogActive1 = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')


const emit = defineEmits(["select"]);

</script>



<template>
  <DialogForm :formActive="dialogActive1"  :title="dialogTitle" :text="dialogText" />
  <div>

    


    <v-list>
      <v-list-item>
        <div class="d-flex cursor-pointer "
          @click="emit('select', 1);">
          <VImg max-width="24px" min-width="24px" src="/images/icons/arrow-up-right.svg" class="me-2 " />О проекте
        </div>
      </v-list-item>
      <v-list-item>

        <div class="d-flex cursor-pointer "
          @click="emit('select', 2);">
          <VImg max-width="24px" min-width="24px" src="/images/icons/arrow-up-right.svg" class="me-2 " />О нас
        </div>
      </v-list-item>
      <v-list-item>
        <div class="d-flex cursor-pointer "
          @click="emit('select', 3);">
          <VImg max-width="24px" min-width="24px" src="/images/icons/arrow-up-right.svg" class="me-2 " />
          Сотрудничество
        </div>
      </v-list-item>
      <v-list-item>
        <div class="d-flex cursor-pointer "
          @click="emit('select', 4);">
          <VImg max-width="24px" min-width="24px" src="/images/icons/arrow-up-right.svg" class="me-2 " />Написать
          письмо
        </div>
      </v-list-item>
    </v-list>
  </div>
</template>





<style lang="scss"></style>
