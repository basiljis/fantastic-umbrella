<script setup>
import navItems from "@/navigation/horizontal";
import { useThemeConfig } from "@core/composable/useThemeConfig";
import { themeConfig } from "@themeConfig";
import { VContainer } from 'vuetify/components'

import 'vue3-carousel/dist/carousel.css'
import { Carousel, Slide, Pagination, Navigation } from 'vue3-carousel'

// Components
import Footer from "@/layouts/components/Footer.vue";
import NavBarI18n from "@/layouts/components/NavBarI18n.vue";
import NavBarNotifications from "@/layouts/components/NavBarNotifications.vue";
import NavbarShortcuts from "@/layouts/components/NavbarShortcuts.vue";
import NavbarThemeSwitcher from "@/layouts/components/NavbarThemeSwitcher.vue";
import NavSearchBar from "@/layouts/components/NavSearchBar.vue";
import UserProfile from "@/layouts/components/UserProfile.vue";
import { HorizontalNavLayout } from "@layouts";
import { VNodeRenderer } from "@layouts/components/VNodeRenderer";
import { isUserLoggedIn } from '@/router/utils'
import { useRouter } from 'vue-router'



import { ref, onMounted, onUnmounted } from 'vue'


const bottom = ref(false)

const onScroll = (event) => {
  if (window.scrollY > 110)
  bottom.value = true
  else bottom.value = false

}

onMounted(() => {
  window.addEventListener('scroll', onScroll);
})

onUnmounted(() => {
  window.removeEventListener('scroll', onScroll);
})




const { appRouteTransition } = useThemeConfig();
const userData = JSON.parse(localStorage.getItem('userData') || 'null')
const breadCrumbs = ref([])
const router = useRouter()
const route = useRoute()
const dateCalend = ref('')


const background = '/images/data/carousel.png'

const getBreadcrumbs = () => {
  breadCrumbs.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      breadCrumbs.value.push(item)
    })
  }
}


watchEffect(getBreadcrumbs)


</script>

<template>
  <HorizontalNavLayout :nav-items="isUserLoggedIn() ? navItems : null"  :class="{ 'layout-small': bottom }">
    <!-- 👉 navbar -->
    <template #navbar>

      <RouterLink to="/" class="app-logo d-flex align-center gap-x-10 ">

        <VImg :class="{ 'logo-small': bottom }"
        v-if="themeConfig.app.light" min-width="155" max-width="155" min-height="90" src="/images/logolight.svg"
          class="auth-illustration mb-2" />
        <VImg v-else min-width="102" min-height="102" src="/images/logo-m.svg" class="auth-illustration  mb-2" />

      </RouterLink>
      <VContainer> </VContainer>
      <VSpacer />


      <!--NavSearchBar trigger-btn-class="ms-lg-n3" /-->


      <!--NavBarI18n />
      <NavbarThemeSwitcher />
      <NavbarShortcuts />
      <NavBarNotifications class="me-2" /-->

      <div class="d-flex gap-3 ">

        <VImg min-width="24" min-height="24" src="/images/icons/search.svg" class=" " />

        <div class="header-input">
          <AppDateTimePicker v-model="dateCalend" rounded="0" class="w-100" placeholder="Дата" />
        </div>
        <div class="header-input">
          <VSelect label="Формат" class="w-100" rounded="0" :items="['Тот', 'Этот']" />
        </div>
        <div class="header-input">
          <VSelect label="Тип мероприятия" class="w-100" rounded="0" :items="['Профиль', 'Фас']" />
        </div>
      </div>>


      <UserProfile v-if="isUserLoggedIn()" />
      <template v-else>

        <VBtn href="/login" variant="outlined" color="#ffffff" rounded="0" class="ms-1 me-5">
          Войти
        </VBtn>


      </template>

    </template>


    <div class="layout-header">


      <div class="d-flex  ">
        <div class="d-flex">
          <div>
            <div class="ms-10 d-flex flex-column gap-5">
              <a href="https://t.me/bright_people_agency" target="_blank">
              <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/telegramm.svg" class=" " />
              </a>
              <VImg max-width="22" src="/images/icons/watsup.svg" class=" " />
              <a href="https://www.youtube.com/channel/UCnJPK_HUOXWQjQjsLx4_6XA" target="_blank">
              <VImg max-width="22" src="/images/icons/youtube.svg" class=" " />
              </a>
              <a href="https://vk.com/bright_people_agency" target="_blank">
              <VImg max-width="22" src="/images/icons/vk.svg" class=" " />
              </a>
            </div>
          </div>
          <div class="d-flex flex-column  ms-5  align-center">
            <p class="fw-600 vertical"> ПОДПИШИТЕСЬ</p>
            <hr class=" mt-3">
          </div>

        </div>

        <div class=" ps-15">
          <div class="fw-700 mt-10 fs-100">Кoнтекст-клуб</div>
          <div class="fw-600 mb-8 fs-18">АФИША МЕРОПРИЯТИЙ</div>
        </div>

        <VSpacer />
        <div class="pt-10 pb-0 px-0 middle-zone">
          <div class="back-yellow d-flex mt-auto h-100 ">
            <p class="mt-auto fs-18 px-5 text-420">Проект “Контекст-клуб” поле новых смыслов, масштабная творческая
              лаборатория и сообщество созидателей</p>
          </div>

        </div>

        <div class="pt-10 pb-0 px-0 right-zone">
          <div class="back-red d-flex mt-auto h-100 ">
            <p class="mt-auto fs-18 px-5">О проекте</p>
          </div>

        </div>
      </div>




    </div>


    <div class="d-flex  ">

      <div class="courusel-zone">

        <Carousel :items-to-show="1" :wrapAround="true" min-height="490px">
          <slide v-for="slide in 10" :key="slide">
            <!--VImg   style="background-image: url('{{background}}')" src="/images/data/carousel.png" class=" " /-->

            <a href="#test" :style="{ backgroundImage: 'url(' + background + ')' }" 
              class=" w-100 h-100   py-12 courusel-img">

              <p class="fs-64 fw-700 text-left">“Будет, что почитать”</p>
              <div class="mt-12 d-flex gap-5">
                <VImg max-width="22" src="/images/icons/users.svg" class=" " />
                <VImg max-width="22" src="/images/icons/movie.svg" class=" " />
                <VImg max-width="22" src="/images/icons/age12.svg" class=" " />

                <VChip color="error" radius="20" variant="elevated" class="fw-600">
                  cпектакль
                </VChip>
              </div>

              <div class="mt-5 d-flex gap-5">
                <VImg max-width="22" src="/images/icons/ticket.svg" class=" " />
                <p class="fw-300 fs-30 mb-0 text-left">
                  бесплатно
                </p>
              </div>

              <p class="fw-300 mt-5 mb-0 fs-30 text-left">ПЛАСТИЧЕСКИЙ </p>
              <p class="fs-17 mt-5 fw-600 text-left" style="max-width:660px">Мультижанровый спектакль «Будет что почитать»
                с участием поэтессы
                Тины Бем и «ЭТО» русской компании современного танца Александра Могилева при участии композитора
                Александра Муравьева.</p>



            </a>
          </slide>

          <template #addons>
            <navigation />
            <pagination />
          </template>
        </Carousel>

      </div>




      <div class=" pb-0 px-0 right-zone ">
        <div class="back-blue d-flex mt-auto h-50 ">
          <p class="mt-auto fs-18 px-5 ">О нас</p>
        </div>
        <div class="back-yellow d-flex mt-auto h-50 ">
          <p class="mt-auto fs-18 px-5">Сотрудничество</p>
        </div>

      </div>

    </div>

    <div>

      <v-breadcrumbs :items="breadCrumbs" class="fs-15 fw-400 back-red my-2">
        <!--VImg max-width="22" src="/images/icons/home.svg" class=" " /-->
        <template v-slot:divider>
          <v-icon icon="tabler:chevron-right" color="white"></v-icon>
        </template>
      </v-breadcrumbs>

    </div>
    <!-- 👉 Pages -->
    <RouterView v-slot="{ Component, route }">
      <Transition :name="appRouteTransition" mode="out-in">
        <Component :is="Component" :key="route.path" />
      </Transition>
    </RouterView>

    <!-- 👉 Footer -->
    <template #footer>
      <Footer />
    </template>

    <!-- 👉 Customizer -->
    <!--TheCustomizer /-->
  </HorizontalNavLayout>
</template>

<style lang="scss">
.active {
  background: #7367f0;
  border-radius: 5px;
}

.login-item {
  display: flex;
  align-items: center;
}

.v-btn--rounded.v-btn--icon {
  border-radius: 6px;
}

.main-nav li {

  display: inline;
}


</style>
