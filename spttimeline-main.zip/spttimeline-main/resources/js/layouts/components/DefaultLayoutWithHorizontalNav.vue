<script setup>
import navItems from "@/navigation/horizontal";
import { useThemeConfig } from "@core/composable/useThemeConfig";
import { themeConfig } from "@themeConfig";
import { VContainer } from 'vuetify/components'
import { useConstStore } from "@/views/apps/useConstStore"
import axios from '@axios'


// Components
import Footer from "@/layouts/components/Footer.vue";
import NavBarI18n from "@/layouts/components/NavBarI18n.vue";
import NavBarNotifications from "@/layouts/components/NavBarNotifications.vue";
import NavbarShortcuts from "@/layouts/components/NavbarShortcuts.vue";
import NavbarThemeSwitcher from "@/layouts/components/NavbarThemeSwitcher.vue";
import NavSearchBar from "@/layouts/components/NavSearchBar.vue";
import BtnMenu from "@/layouts/components/BtnMenu.vue";
import MainMenu from "@/layouts/components/MainMenu.vue";
import MailForm from "@/layouts/components/MailForm.vue";
import DialogForm from "@/layouts/components/DialogForm.vue";
import UserProfile from "@/layouts/components/UserProfile.vue";
import { HorizontalNavLayout } from "@layouts";
import { VNodeRenderer } from "@layouts/components/VNodeRenderer";
import { isUserLoggedIn } from '@/router/utils'
import { useRouter } from 'vue-router'

const mainMenu = ref(false)
const mainMenusmall = ref(false)
const search = ref('')
const constStore = useConstStore()

import { ref, onMounted, onUnmounted } from 'vue'

axios.defaults.headers.common = {
  Authorization: `Bearer ${localStorage.accessToken}`,

}


const mailActive = ref(false)

const dialogActive = ref(false)
const dialogTitle = ref('')
const dialogText = ref('')


const bottom = ref(false)
const windowWidth = ref(window.innerWidth)

const onScroll = (event) => {
  if (window.scrollY > 150)
    bottom.value = true

  else if (window.scrollY < 100){
    bottom.value = false
    mainMenu.value = false
  }

}

onMounted(() => {
  window.addEventListener('scroll', onScroll);
})

onUnmounted(() => {
  window.removeEventListener('scroll', onScroll);
})




const { appRouteTransition } = useThemeConfig();
const userData = JSON.parse(localStorage.getItem('userData') || 'null')
const breadCrumbs = ref([])
const router = useRouter()
const route = useRoute()
const dateCalend = ref('')



const getBreadcrumbs = () => {
  breadCrumbs.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      breadCrumbs.value.push(item)
    })
  }
}


const globalSearch = () => {

}

const openmodal = (val) => {
  if (val==1)
  {
    dialogTitle.value = 'О проекте'
    dialogText.value = constStore.aboutform
    dialogActive.value = true
  }
  else if (val==2)
  {
    dialogTitle.value = 'О нас'
    dialogText.value = constStore.aboutus
    dialogActive.value = true
  }
  else if (val==3)
  {
    dialogTitle.value = 'Сотрудничество'
    dialogText.value = constStore.construct
    dialogActive.value = true
  }
  else if (val==4)
  {
    mailActive.value = true
  }

}



watchEffect(getBreadcrumbs)




</script>

<template>
  <HorizontalNavLayout :nav-items="isUserLoggedIn() ? navItems : null" :class="{ 'layout-small': bottom }"
    class="container ">

    <DialogForm :formActive="dialogActive" @closeform="dialogActive = false" :title="dialogTitle" :text="dialogText" />

    <!-- 👉 navbar -->
    <template #navbar>

      <div class="navbar-content-container d-none d-sm-flex">
        <VMenu v-model="mainMenu" transition="slide-y-transition">
          <template #activator="{ props }">
            <VBtn v-bind="props" :class="{ 'hidden': !bottom && (route.meta.variant == 'outer') }" icon variant="text"
              color="default" class="menu-button" size="small">
              <VImg min-width="24" src="/images/icons/menu.svg" class="cursor-pointer " />
            </VBtn>
          </template>
          <MainMenu  @select="openmodal"/>
        </VMenu>
        <RouterLink :class="{ 'logo-small': bottom }" to="/" class="app-logo d-flex align-center gap-x-10 ">
          <VImg min-width="155" max-width="155" min-height="90" src="/images/logolight.svg"
            class="auth-illustration mb-2" />
        </RouterLink>

        <VContainer> </VContainer>
        <VSpacer />

        <!--NavSearchBar trigger-btn-class="ms-lg-n3" /-->
        <!--NavBarI18n />
      <NavbarThemeSwitcher />
      <NavbarShortcuts />
      <NavBarNotifications class="me-2" /-->

        <template v-if="isUserLoggedIn()">
          <div class="gap-4 d-flex align-center me-5">
            <BtnMenu />
          </div>
          <UserProfile class="" />
        </template>
        <template v-else>
          <VBtn href="/login" variant="flat" color="#602699" rounded="0" class="ms-1 ">
            Войти
          </VBtn>
        </template>
      </div>


      <div class="navbar-content-container px-0 d-sm-none" id="logo-mobile">
        <VMenu transition="slide-y-transition">
          <template #activator="{ props }">
            <VBtn v-bind="props" icon variant="text" color="default" class="menu-button" size="small">
              <VImg min-width="24" src="/images/icons/menu.svg" class="cursor-pointer " />
            </VBtn>
          </template>
          <MainMenu  @select="openmodal"/>
        </VMenu>

        <RouterLink to="/" class="app-logo d-flex align-center mx-auto gap-x-10 ">
          <VImg min-width="99" max-width="99" min-height="90" src="/images/logolight.svg" class="auth-illustration " />
        </RouterLink>

        <!--NavSearchBar trigger-btn-class="ms-lg-n3" /-->
        <!--NavBarI18n />
      <NavbarThemeSwitcher />
      <NavbarShortcuts />
      <NavBarNotifications class="me-2" /-->

        <div class="d-flex fs-18 fw-600 align-center gap-3" id="search">
          <VTextField append-inner-icon="tabler-search" base-color="#602699" v-model="search" color='#602699'
            placeholder="поиск" rounded="0" v-on:keyup.enter="globalSearch" />
        </div>

        <template v-if="isUserLoggedIn()">

          <UserProfile class="" />
        </template>
        <template v-else>
          <VBtn href="/login" variant="text" class="ms-3 px-0 login-btn">
            <VImg min-width="24" src="/images/icons/door-enter.svg" class="cursor-pointer " />
          </VBtn>
        </template>
      </div>
    </template>
    <div class="layout-header d-none d-sm-block" v-if="route.meta.variant == 'outer'">
      <div class="d-flex justify-space-between border-menu ">
        <div>

        </div>
        <div class=" border-left">
          <div class="colored fs-18 fw-600 d-flex mb-2 ps-3 cursor-pointer "
            @click="openmodal(1)">
            <p class="mt-5  mb-0"> О проекте</p>
            <VImg min-width="24px" src="/images/icons/arrow-up-right.svg" class="align-self-start ms-5" />
          </div>
        </div>

        <div class="colored fs-18 fw-600 mb-2 d-flex cursor-pointer"
          @click="openmodal(2)">
          <p class="mt-5 mb-0"> О нас</p>
          <VImg min-width="24px" src="/images/icons/arrow-up-right.svg" class="align-self-start ms-5" />
        </div>

        <div class="colored fs-18 fw-600 mb-2 d-flex cursor-pointer"
          @click="openmodal(3)">
          <p class=" mt-5 mb-0">Сотрудничество</p>
          <VImg min-width="24px" src="/images/icons/arrow-up-right.svg" class="align-self-start ms-5" />
        </div>

        <div class="colored fs-18 fw-600 mb-2 d-flex cursor-pointer" @click="openmodal(4)">
          <p class="mt-5 mb-0">Написать письмо</p>
          <VImg min-width="24px" src="/images/icons/arrow-up-right.svg" class="align-self-start ms-5" />
        </div>
        <MailForm :mailActive_="mailActive" @closeform="mailActive = false"
          @sended="dialogTitle = 'Сообщение отправлено'; dialogText = 'Благодарим за ваше обращение, ответим вам ближайшее время'; dialogActive = true" />



      </div>


      <div class="pinnots   ">

      </div>

      <VRow>
        <VCol cols="12" md="8">
          <div class="d-flex ">
            <div class="d-flex">
              <div>
                <div class="ms-10 d-flex flex-column gap-5">
                  <a href="https://t.me/bright_people_agency" target="_blank">
                  <VImg max-width="22" min-width="22" min-height="22" src="/images/icons/telegramm.svg" class=" " />
                  </a>
                  <VImg max-width="22" src="/images/icons/watsup.svg" class=" " />
                  <a href="https://www.youtube.com/channel/UCnJPK_HUOXWQjQjsLx4_6XA" target="_blank">
                  <VImg max-width="22" src="/images/icons/youtube.svg" class=" " />
                  </a>
                  <a href="https://vk.com/bright_people_agency" target="_blank">
                  <VImg max-width="22" src="/images/icons/vk.svg" class=" " />
                  </a>
                </div>
              </div>
              <div class="d-flex flex-column  ms-5  align-center">
                <p class="fw-600 vertical colored"> ПОДПИШИТЕСЬ</p>
                <hr class=" colored mt-3">
              </div>

            </div>

            <div class=" ps-15">
              <div class="fw-700 size-800 fs-100 colored" style="line-height:80px">Кoнтекст-клуб</div>
              <div class="fw-600 ps-1 mt-12 mb-3 fs-30 colored">ПОЛЕ НОВЫХ СМЫСЛОВ</div>
            </div>
          </div>
        </VCol>
        <VCol cols="12" md="4" class="mt-auto  ps-15 ps-md-0">
          <div class=" pb-0 pe-0 ps-15 ps-md-0">

            <p class="mt-auto fs-18 pe-5 ps-15 ps-md-5 colored text-480">Проект “Контекст-клуб” - масштабная творческая
              лаборатория и
              сообщество созидателей</p>
          </div>
        </Vcol>
      </VRow>


    </div>

    <div>

      <!--v-breadcrumbs :items="breadCrumbs" class="fs-15 fw-400 back-red my-2">
        <VImg max-width="22" src="/images/icons/home.svg" class=" " />
        <template v-slot:divider>
          <v-icon icon="tabler:chevron-right" color="white"></v-icon>
        </template>
      </v-breadcrumbs-->

    </div>
    <!-- 👉 Pages -->
    <RouterView v-slot="{ Component }">

    </RouterView>

    <!--template #navigate v-if="route.meta.variant == 'outer'">
      <div class="back-red color-white d-flex justify-center align-center gap-10 py-3 cursor-pointer">
        <div class="fs-18 fw-600 ">загрузить еще</div> 
        <VImg max-width="80px" src="/images/icons/arrow-right.svg" class=" " />
      </div>

    </template-->

    <!-- 👉 Footer -->


    <template #footer>
      <Footer />
    </template>

    <!-- 👉 Customizer -->
    <!--TheCustomizer /-->
  </HorizontalNavLayout>
</template>

<style lang="scss">
.active {
  background: #7367f0;
  border-radius: 5px;
}

.login-item {
  display: flex;
  align-items: center;
}

.v-btn--rounded.v-btn--icon {
  border-radius: 6px;
}

.main-nav li {

  display: inline;
}
</style>
