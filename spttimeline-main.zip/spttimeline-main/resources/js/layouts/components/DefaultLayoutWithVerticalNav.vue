<script setup>
import navItems from '@/navigation/vertical'
import { useThemeConfig } from '@core/composable/useThemeConfig'

// Components
import Footer from '@/layouts/components/Footer.vue'
import Header from '@/layouts/components/Header.vue'
import NavBarI18n from '@/layouts/components/NavBarI18n.vue'
import NavBarNotifications from '@/layouts/components/NavBarNotifications.vue'
import NavbarShortcuts from '@/layouts/components/NavbarShortcuts.vue'
import NavbarThemeSwitcher from '@/layouts/components/NavbarThemeSwitcher.vue'
import NavSearchBar from '@/layouts/components/NavSearchBar.vue'
import UserProfile from '@/layouts/components/UserProfile.vue'
import { can } from '@layouts/plugins/casl'
import axios from '@axios'
import { isUserLoggedIn } from '@/router/utils'

// @layouts plugin
import { VerticalNavLayout } from '@layouts'
import { useRouter } from 'vue-router'

const searchID = ref('')

const { appRouteTransition, isLessThanOverlayNavBreakpoint } = useThemeConfig()
const { width: windowWidth } = useWindowSize()

axios.defaults.headers.common = {
  Authorization: `Bearer ${localStorage.accessToken}`,

}


const route = useRoute()
const router = useRouter()

const items = ref([])

const getBreadcrumbs = () => {
  items.value = []
  if (route.meta.breadcrumb) {
    route.meta.breadcrumb.forEach(element => {
      const item = element
      item['to'] = router.resolve({
        name: element['name']
      }).path
      items.value.push(item)
    })
  }
}


watchEffect(getBreadcrumbs)

const globalSearch = () => {
  router.push({ name: "personrezult", params: { personid: searchID.value } })
}

</script>

<template>
  <VerticalNavLayout v-if="isUserLoggedIn()" :nav-items="isUserLoggedIn() ? navItems : null">
    <!-- 👉 navbar -->
    <template #navbar="{ toggleVerticalOverlayNavActive }">
      <div class="d-flex h-100 align-center">
        <VBtn v-if="isLessThanOverlayNavBreakpoint(windowWidth)" icon variant="text" color="default" class="ms-n3"
          size="small" @click="toggleVerticalOverlayNavActive(true)">
          <VIcon icon="tabler-menu-2" size="24" />
        </VBtn>
        <template v-if="can('manage', 'globalSearch')">
          <VBtn prepend-icon="tabler-search" class=" " rounded="0" @click="globalSearch" variant="text" />
          <VTextField v-model="searchID" placeholder="ID" rounded="0" v-on:keyup.enter="globalSearch" />
        </template>
        <VSpacer />


        <!--NavBarNotifications class="me-2" /-->
        <UserProfile />
      </div>
    </template>


    <v-breadcrumbs :items="items">
      <template v-slot:divider>
        <v-icon icon="mdi-chevron-right"></v-icon>
      </template>
    </v-breadcrumbs>


    <!-- 👉 Pages -->
    <RouterView v-slot="{ Component }">
      <Transition :name="appRouteTransition" mode="out-in">
        <Component :is="Component" />
      </Transition>
    </RouterView>

    <!-- 👉 Footer -->
    <template #footer>
      <Footer />
    </template>

  </VerticalNavLayout>
  <template v-else>

      <Header />
      <v-breadcrumbs :items="items" class="fs-15 mt-3">
        <template v-slot:divider>
          <v-icon icon="tdesign:chevron-right-double-s"></v-icon>
        </template>
      </v-breadcrumbs>
      <RouterView v-slot="{ Component }">
      </RouterView>


    <div class=" d-flex align-center justify-space-between">
      <!-- 👉 Footer: left content -->
      <span class="d-flex align-center">
        &copy; &nbsp; || Яркие люди /
        {{ new Date().getFullYear() }}

      </span>

    </div>
  </template>
</template>
