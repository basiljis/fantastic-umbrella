<script setup>
const router = useRouter()
const backgroundcolor = '#EA5455'
import { isUserLoggedIn } from '@/router/utils'
import { useServiceStore } from "@/views/apps/service/serviceStore";

const serviceStore = useServiceStore();


const props = defineProps({
  event: {
    type: Object,
    required: true,
  },

});

const messageShow = ref(false);
const nullShow = ref(false);
const draftShow = ref(false);
const infoMessage = ref("");
const deleteId = ref()
const emit = defineEmits(["openlogin", 'openconfirm', 'refresh']);

function uRouter() {
  router.push({ name: 'MyComponent', query: { p: myArr[i], r: rangeInput.value } });
}


function preview() {
  let files = JSON.parse(props.event.events_files)

  if (files?.wallpaper)
    return '/storage/' + files.wallpaper
  else return ''

}

function register() {

  if (props.event.events_tickets_www) {
    window.open(props.event.events_tickets_www,'_self').focus()
    return
  }



  if (!isUserLoggedIn()  && !props.event.events_tickets_www ) emit('openlogin', props.event.events_id, props.event.events_tickets_www)

  else {
    serviceStore.userConfirmd({}).then(response => {
      if (response.data.confirmed) {
        if (props.event.events_tickets_www) {

          serviceStore.registerEvent({ event_id: props.event.events_id }).then(response => {
            messageShow.value = true;
            infoMessage.value = "Вы зарегестрировались на " + props.event.events_name
            emit('refresh')

          }).catch(error => {
            console.error(error)
          })

          window.open(props.event.events_tickets_www, '_blank').focus();

        }
        else {
          serviceStore.registerEvent({ event_id: props.event.events_id }).then(response => {
            router.push({ name: 'registerevent', params: { event: props.event.events_id } })
          }).catch(error => {
            console.error(error)
          })


        }


      }
      else {
        emit('openconfirm')

      }
    }).catch(error => {
      console.error(error)
    })

  }
}

const buy_ticket = () => {
  if (props.event.events_tickets_www)
    window.open(props.event.events_tickets_www, '_blank').focus()
  else router.push({ name: 'registerevent', params: { event: props.event.events_id } })

}



const nullevent = () => {

  serviceStore
    .nullEvent({
      event_id: deleteId.value
    })
    .then((response) => {
      emit('refresh')
    }).catch((error) => {

    })
  nullShow.value = false;
}


const draftevent = () => {

  serviceStore
    .nullEvent({
      event_id: deleteId.value
    })
    .then((response) => {
      emit('refresh')
    }).catch((error) => {

    })
  draftShow.value = false;
}


</script>



<template>
  <v-dialog v-model="messageShow" width="auto">
    <DialogCloseBtn @click="messageShow = !messageShow" />
    <v-card class="px-4">
      <v-card-title>
      </v-card-title>
      <v-card-text v-html="infoMessage"> </v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="messageShow = false;">Закрыть</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>

  <v-dialog v-model="nullShow" width="auto">
    <DialogCloseBtn @click="nullShow = !nullShow" />
    <v-card class="px-4">
      <v-card-text> Аннулировать мероприятие?</v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="nullShow = false;">Закрыть</v-btn>
        <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="nullevent">Аннулировать</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>

  <v-dialog v-model="draftShow" width="auto">
    <DialogCloseBtn @click="draftShow = !draftShow" />
    <v-card class="px-4">
      <v-card-text> Снять с публикации?</v-card-text>
      <v-card-actions>
        <v-btn color="primary" class="me-auto" @click="draftShow = false;">Закрыть</v-btn>
        <v-btn variant="flat" color="#602699" rounded="0" class="me-auto" @click="draftevent">Да</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>



  <div class="event-item my-2 mx-2 mx-sm-2">
    <div>
      <div class="d-flex align-center">
        <div>
          <p class="fs-20 fw-600 mb-0 text-uppercase"> {{ props.event.events_name }}</p>
          <p class="fs-25 fw-900 panton-bold mb-0"> {{ props.event.events_desc }}</p>
        </div>
        <div class="ms-auto" v-if="$can('manage', 'all')">
          <VMenu transition="slide-y-transition">
            <template #activator="{ props }">
              <VImg v-bind="props" min-width="50px" src="/images/icons/arrow-up-circle.svg" class="cursor-pointer " />
            </template>
            <v-list>
              <v-list-item>
                <div class="d-flex cursor-pointer "
                  @click="router.push({ name: 'editevent', params: { event: props.event.events_id } })">
                  <VImg max-width="24px" min-width="24px" src="/images/icons/list.svg" class="me-2 " />
                  Редактировать
                </div>
              </v-list-item>
              <v-list-item>
                <div class="d-flex cursor-pointer " @click="draftShow = true; deleteId = props.event.events_id">
                  <VImg max-width="24px" min-width="24px" src="/images/icons/list.svg" class="me-2 " />
                  Снять с публикации
                </div>
              </v-list-item>

              <v-list-item>
                <div class="d-flex cursor-pointer " @click="nullShow = true; deleteId = props.event.events_id">
                  <VImg max-width="24px" min-width="24px" src="/images/icons/delete.svg" class="me-2 " />
                  Аннулировать
                </div>
              </v-list-item>
            </v-list>
          </VMenu>


        </div>
      </div>
      <div class="  mt-3 align-center ">
        <p class="fs-15 mb-0 fw-700">
          {{ new Date(props.event.events_dt_start).toLocaleString("ru-Ru", {
            weekday: "short", day: "2-digit", month:
              "long"
          }) }}
          {{ props.event.events_start_time }}
        </p>
        <div class="d-flex gap-3 align-center">

          <VImg max-width="25" max-height="25" :src="'/images/icons/' + props.event.spr_action_formats_icon"
            class=" invert ">
            <VTooltip open-on-click :open-on-hover="true" location="bottom" activator="parent" class="tooltip-menu">
              {{ props.event.spr_action_formats_name }}
            </VTooltip>
          </VImg>
          <VImg max-width="25" max-height="25" min-height="25" :src="'/images/icons/' + props.event.spr_ages_icon"
            class=" ">
            <VTooltip class="tooltip-menu" open-on-click :open-on-hover="true" location="bottom" activator="parent">
              рекомендованный возраст
            </VTooltip>

          </VImg>
          <div class="d-flex align-center gap-3">
            <div class="mx-auto round-type text-center d-flex align-center justify-center color-white fs-13 fw-600"
              :style="{
                backgroundColor: props.event.spr_action_types_color
              }">
              {{ props.event.spr_action_types_name.charAt(0).toUpperCase() }}
            </div>
            <div class=" align-self-center"> {{ props.event.spr_action_types_name }}</div>
          </div>

        </div>
        <div class="d-flex align-center gap-3 ">
          <VImg max-width="25" max-height="25" src="/images/icons/ticket.svg" class=" invert " />
          <template v-if="props.event.events_price">
            от {{ props.event.events_price }} ₽
          </template>
          <template v-else>
            бесплатно
          </template>

        </div>
        <div class="fs-17 mt-4 fw-400" v-html="props.event.events_anons_short"></div>
      </div>

    </div>

    <div v-if="preview()" class="">
      <VImg :src="preview()" cover class="preview-img" />
    </div>
    <p class="fs-17 mt-2 fw-100">
      {{ props.event.events_local_name }}
    </p>
    <p class="fs-17 mt-2 fw-100">
      {{ props.event.events_adress }}
    </p>
    <div>
      <v-btn color="white" rounded="0" variant="flat"
        @click="router.push({ name: 'event', params: { event: props.event.events_id } })"
        class=" mx-0 w-50 fw-600 fs-17 ">
        Подробнее
      </v-btn>

      <v-btn v-if="props.event.registered" color="#602699" @click="buy_ticket" rounded="0" variant="flat"
        class=" mx-0  w-50 fw-600 fs-17 ">
        Купить билет
      </v-btn>
      <v-btn v-else color="#602699" rounded="0" @click="register" variant="flat" class=" mx-0  w-50 fw-600 fs-17 ">
        Регистрация
      </v-btn>


    </div>


  </div>
</template>





<style lang="scss"></style>
