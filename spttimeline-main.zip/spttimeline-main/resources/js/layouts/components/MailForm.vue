<script setup>
import { useServiceStore } from "@/views/apps/service/serviceStore";
import {
  emailValidator,
  requiredValidator,
} from '@validators'


const mailname = ref('')
const mailemail = ref('')
const mailphone = ref('')
const mailmessage = ref('')
const mailprivacy = ref(true)
const sendmailForm = ref()
const mailActive = ref(false)
const serviceStore = useServiceStore();

const onSubmit = () => {
  sendmailForm.value?.validate().then(({ valid: isValid }) => {
    if (isValid) {
      serviceStore
        .sendMail({
          // start ==5 ,email,name,phone,text(сообщение),accept(согласие на персуху)
          start:5,
          email :mailemail.value,
          name :mailname.value,
          phone :mailphone.value,
          text :mailmessage.value,
          accept :true,
        })
        .then((response) => {
          mailActive.value = false
          emit("closeform", false);
          emit('sended', true);
        })
        .catch((error) => {
          console.error(error)
        })

    }
  })
}

const props = defineProps({
  mailActive_: {
    type: Boolean,

  },

})

const emit = defineEmits(["closeform", "sended"]);

watchEffect(() => {
  mailActive.value = props.mailActive_
})

</script>





<template>
  <v-dialog max-width="800" v-model="mailActive">
    <VForm ref="sendmailForm" @submit.prevent="onSubmit">
      <v-card title="Написать письмо">
        <v-card-text>
          <VRow>
            <VCol cols="12">
              <VTextField v-model="mailname" label="Имя" type="text" placeholder="Имя" :rules="[requiredValidator]" />
            </VCol>
            <VCol cols="12">
              <VTextField v-model="mailphone" label="Контактный номер телефона" type="text"
                placeholder="Контактный номер телефона" />
            </VCol>
            <VCol cols="12">
              <VTextField v-model="mailemail" label="Эл. почта" type="email" placeholder="fio@mail.ru"
                :rules="[requiredValidator, emailValidator]" />
            </VCol>
            <VCol cols="12">
              <VTextarea v-model="mailmessage" label="Текст сообщения" type="text" :rules="[requiredValidator]" />
            </VCol>
            <VCol cols="12">
              <VCheckbox label="Даю согласие на обработку моих персональных данных" checked v-model="mailprivacy"
                :rules="[requiredValidator]" />
            </VCol>
          </VRow>

        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <VBtn type="submit" variant="flat" color="#602699" rounded="0"> Отправить </VBtn>
          <v-btn text="Закрыть" variant="flat" color="#602699" rounded="0"
            @click="mailActive = false; emit('closeform', false);"></v-btn>
        </v-card-actions>
      </v-card>
    </VForm>

  </v-dialog>
</template>





<style lang="scss"></style>
