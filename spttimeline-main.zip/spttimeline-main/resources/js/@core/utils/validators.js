import { isEmpty, isEmptyArray, isNullOrUndefined } from './index'

// 👉 Required Validator
export const requiredValidator = value => {
  if (isNullOrUndefined(value) || isEmptyArray(value) || value === false)
    return 'Это поле обязательно'

  return !!String(value).trim().length || 'Это поле обязательно'
}

// 👉 Email Validator
export const emailValidator = value => {
  if (isEmpty(value))
    return true
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  if (Array.isArray(value))
    return value.every(val => re.test(String(val))) || 'Неверный формат почтового адреса'

  return re.test(String(value)) || 'Неверный формат почтового адреса'
}

// 👉 Password Validator
export const passwordValidator = password => {
  const regExp = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%&*()]).{8,}/
  const validPassword = regExp.test(password)

  return (
    // eslint-disable-next-line operator-linebreak
    validPassword ||
        'Поле должно содержать как минимум одну заглавную и строчную букву, цифру и специальный символ. Минимальная длина 8 знаков')
}

// 👉 Confirm Password Validator
export const confirmedValidator = (value, target) => value === target || 'Пароли не совпадают'

// 👉 Between Validator
export const betweenValidator = (value, min, max) => {
  const valueAsNumber = Number(value)

  return (Number(min) <= valueAsNumber && Number(max) >= valueAsNumber) || `Enter number between ${min} and ${max}`
}

// 👉 Integer Validator
export const integerValidator = value => {
  if (isEmpty(value))
    return true
  if (Array.isArray(value))
    return value.every(val => /^-?[0-9]+$/.test(String(val))) || 'Введите число'

  return /^-?[0-9]+$/.test(String(value)) || 'Введите число'
}

export const klassValidator = value => {
  if (isEmpty(value))
    return true
  if (Array.isArray(value))
    return value.every(val => /^([7-9]|1[012])$/.test(String(val))) || 'Классы с 7 по 12'

  return /^([7-9]|1[012])$/.test(String(value)) || 'Классы с 7 по 12'
}


export const ageValidator = value => {
  if (isEmpty(value))
    return true
  if (Array.isArray(value))
    return value.every(val => /^([0-9]){2}$/.test(String(val))) || 'Неверный возраст'

  return /^([0-9]){2}$/.test(String(value)) || 'Неверный возраст'
}

export const courseValidator = value => {
  if (isEmpty(value))
    return true
  if (Array.isArray(value))
    return value.every(val => /^([1-5])$/.test(String(val))) || 'Курсы с 1 по 5'

  return /^([1-5])$/.test(String(value)) || 'Курсы с 1 по 5'
}

// 👉 Regex Validator
export const regexValidator = (value, regex) => {
  if (isEmpty(value))
    return true
  let regeX = regex
  if (typeof regeX === 'string')
    regeX = new RegExp(regeX)
  if (Array.isArray(value))
    return value.every(val => regexValidator(val, regeX))

  return regeX.test(String(value)) || 'The Regex field format is invalid'
}

// 👉 Alpha Validator
export const alphaValidator = value => {
  if (isEmpty(value))
    return true

  return /^[A-Z]*$/i.test(String(value)) || 'Поле должно содержать только буквы'
}

// 👉 URL Validator
export const urlValidator = value => {
  if (isEmpty(value))
    return true
  const re = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/

  return re.test(String(value)) || 'URL is invalid'
}

// 👉 Length Validator
export const lengthValidator = (value, length) => {
  if (isEmpty(value))
    return true

  return String(value).length === length || `The Min Character field must be at least ${length} characters`
}

// 👉 Alpha-dash Validator
export const alphaDashValidator = value => {
  if (isEmpty(value))
    return true
  const valueAsString = String(value)

  return /^[0-9A-Z_-]*$/i.test(valueAsString) || 'Поле должно содержать только буквы или цифры'
}




export const russianValidator = value => {
  if (isEmpty(value))
    return true

  return /^[\u0401\u0451\u0410-\u044f ]*$/i.test(String(value)) || 'Поле должно содержать только буквы'
}


export const russianoneValidator = value => {
  if (isEmpty(value))
    return true

  return /^[\u0401\u0451\u0410-\u044f]{1,2}$/i.test(String(value)) || 'Одна/две русские буквы'
}

export const dateRangeValidator = (value, target) =>( ((value) >= (target) ) || value==null )  || 'Дата окончания должна быть позже даты начала'