import { defineStore } from 'pinia'
import axios from '@axios'


export const useGuideStore = defineStore('GuideStore', {
  actions: {
    // 👉 Fetch usertypes data
    async getGuideData(params) {
      const x = await axios.get(params.url)
      return x
    },


    async getButtonsData(params) {
      const x = await axios.get('/apps/spr_buttons/', { params })
      return x
    },


    async getColsData(params) {
      const x = await axios.get('/apps/spr_cols/', { params })
      return x
    },


    async fetchGuideList(params,url) {
      const x = await axios.get(url, { params })
      return x
    },


    async getAccessData(params) {
      const x = await axios.post('/apps/access/getModalAccess',  params )
      return x
    },



    async sendFormData(params,method,url) {
      var x = ''
      if (method.toLowerCase()==='get')
         x = await axios.get(url,  params )
      else if (method.toLowerCase()==='delete')
         x = await axios.delete(url,  params )
      else if (method.toLowerCase()==='put')
          x = await axios.put(url,  params )
      else if (method.toLowerCase()==='file')
          x = await axios.post(url,  params,{ headers: { 'Content-Type': 'multipart/form-data' }} )
      else 
          x = await axios.post(url,  params ,{ headers: { 'Content-Type': 'multipart/form-data' }} )
      return x
    },



  },
})
