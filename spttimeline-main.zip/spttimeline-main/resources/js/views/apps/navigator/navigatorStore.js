import { defineStore } from 'pinia'
import axios from '@axios'

export const useNavigatorStore = defineStore('NavigatorListStore', {
  actions: {

    async fetchThemes(params) {
      const x = await axios.get('/apps/navigator/list', { params })

      return x
    },

    async getActionTypes(params) {
      const x = await axios.get('/apps/spr_pactype/list')

      return x
    },


    async fetchEvents(params) {
      const x = await axios.post('/apps/navigator/actionslist', params)
      return x
    },



    async addNewEvent(params) {
      const x = await axios.post('/apps/navigator/addaction',  params )
      return x
    },


    async editEvent(params) {
      const x = await axios.post('/apps/navigator/updaction',  params )
      return x
    },



    async getFile(params) {
      const x = await axios.get('/apps/prof/getThemeFile', { params} )
      return x
    },



    async getLeftWeeks(params) {
      const x = await axios.get('/apps/navigator/NavigatorWeekstLeft', { params} )
      return x
    },
    




  },
})
