
import axios from '@axios'

import CryptoJS from 'crypto-js';
import { useServiceStore } from "@/views/apps/service/serviceStore";


export  function  registerEvent(eventid, redirect)
{
  const serviceStore = useServiceStore();


}



export async function login(email, password) {



  var errors = ref({
    email: undefined,
    password: undefined,
  })


  let success = false

  const userAbilities = [
    {
      action: 'manage',
      subject: 'register',
    },
    {
      action: 'read',
      subject: 'Auth',
    },
    {
      action: 'read',
      subject: 'Testing',
    },]




  await axios.post('/api/auth/login', {
    email: email.toLowerCase(),
    password: password,
  }).then(r => {

    const { accessToken, } = r.data
    const userData_ = {
      name: r.data.access_array['name'],
      rolename: r.data.access_array['a_type'],
      ooid: r.data.access_array['ooid'],
      ooid_name: r.data.access_array['ooid_name'],
      avatar: r.data.access_array['avatar'],
    }

    userAbilities.push({ action: "manage", subject: "user" })

    if (r.data.access_array['admin'] > 1) {
      userAbilities.push({ action: "manage", subject: "all" })
    }


    localStorage.setItem('accessToken', accessToken)

    axios.defaults.headers.common = {
      Authorization: `Bearer ${accessToken}`,
    }

    localStorage.setItem('userAbilities', CryptoJS.AES.encrypt(JSON.stringify(userAbilities), accessToken).toString())

    //localStorage.setItem('userAbilities',JSON.stringify(userAbilities))



    localStorage.setItem('userData', JSON.stringify(userData_))

    // Redirect to `to` query if exist or redirect to index route
    success = true

  }).catch(e => {
    const { errors: formErrors } = e.response.data
    errors = formErrors

  })

  return { abilities: userAbilities, errors: errors, success: success }
}



export async function register(phone, email, username,  password, password_, privacyPolicies, mailSending, rules) {

 
  var errors = {
    email: undefined,
    password: undefined,
  }

  let message = ''
  let success = false

  const userAbilities = [{
    action: 'manage',
    subject: 'register',
  },
  {
    action: 'read',
    subject: 'Auth',
  },
  {
    action: 'read',
    subject: 'Testing',
  },
  ]

  await axios.post('/api/auth/register', {

    phone: phone,
    email: email.toLowerCase(),
    name: username,
    password: password,
    password_: password_,
    spt_access_agreement: privacyPolicies ? 1 : 0,
    mailSending: mailSending ? 1 : 0,
    rules: rules ? 1 : 0,

  }).then(r => {


    message = r.data.message
  
    console.log(r.data)

    if (r.data.status == 'registered') {

      const { accessToken, } = r.data
      const userData_ = {
        name: r.data.access_array['name'],
        rolename: r.data.access_array['a_type'],
        ooid: r.data.access_array['ooid'],
        ooid_name: r.data.access_array['ooid_name']
      }





      localStorage.setItem('accessToken', accessToken)

      axios.defaults.headers.common = {
        Authorization: `Bearer ${accessToken}`,
      }

      localStorage.setItem('userAbilities', CryptoJS.AES.encrypt(JSON.stringify(userAbilities), accessToken).toString())
      //localStorage.setItem('userAbilities',JSON.stringify(userAbilities))
    
      localStorage.setItem('userData', JSON.stringify(userData_))

      success =true


    }

  }).catch(e => {

    //console.error(e.response)
    const { errors: formErrors } = e.response.data
    errors = formErrors
    

  })


  
  return { abilities: userAbilities, errors: errors, success: success, message:message }

}