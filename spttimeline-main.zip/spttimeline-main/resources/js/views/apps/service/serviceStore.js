import { defineStore } from 'pinia'
import axios from '@axios'
import { isUserLoggedIn } from '@/router/utils'

export const useServiceStore = defineStore('serviceStore', {
  actions: {

    /*
        async decodeRezultSave() {
          const x = await axios.get('/apps/tech/decodeRezultSave?start=1&new=1')
    
          return x
        },
    */
    async getFormatsList() {
      const x = await axios.get('/apps/spr_action_formats/list')
      return x
    },
    async getTypesList() {
      const x = await axios.get('/apps/spr_action_types/list')
      return x
    },
    async getAgesList() {
      const x = await axios.get('/apps/spr_ages/list')
      return x
    },

    async getStatusesList() {
      const x = await axios.get('/apps/spr_statuses/list')
      return x
    },

    async getPartnersList() {
      const x = await axios.get('/apps/users/Partnlist')
      return x
    },

    async getPartiList() {
      const x = await axios.get('/apps/users/Partilist')
      return x
    },


    async storeEvent(params) {
      const x = await axios.post('/apps/event/store', params)
      return x
    },

    async fetchRows(params) {
      var  x = await axios.get('/apps/event/listadm', { params })
      return x

    },

    

    async fetchRowshome(params) {
      var x = null
      if (isUserLoggedIn())
        x = await axios.get('/apps/event/listall', { params })
      else
        x = await axios.get('/apps/event/listall_ext', { params })
      return x
    },


    async getEvent(params) {
      var x = null
      if (isUserLoggedIn())
        x = await axios.get('/apps/event/getreg', { params })
      else
        x = await axios.get('/apps/event/get', { params })
      return x
    },


    async getFiles(params) {
      const x = await axios.get('/apps/file/get', { params })
      return x
    },

    async delFile(params) {
      const x = await axios.post('/apps/file/delete', params)
      return x
    },

    async getcountperDay(params) {
      const x = await axios.get('/apps/event/getcountperDay', params)
      return x
    },

    async registerEvent(params) {
      const x = await axios.post('/apps/events/register', params)
      return x
    },


    async unregisterEvent(params) {
      const x = await axios.post('/apps/events/unregister', params)
      return x
    },


    async listuser(params) {
      const x = await axios.get('/apps/event/listuser', { params })
      return x
    },

    async markEvent(params) {
      const x = await axios.post('/apps/events/mark', params)
      return x
    },


    async getStatusesList(params) {
      const x = await axios.get('/apps/spr_event_status/list', { params })
      return x
    },


    async getProfile(params) {
      const x = await axios.get('/apps/profile/get', { params })
      return x
    },


    async updateProfile(params) {
      const x = await axios.post('/apps/profile/update', params)
      return x
    },

    async userConfirmd(params) {
      const x = await axios.get('/apps/users/confirmed', { params })
      return x
    },


    async nullEvent(params) {
      const x = await axios.post('/apps/event/nullEvent', params)
      return x
    },

    async unpublishEvent(params) {
      const x = await axios.post('/apps/event/unpublishEvent', params)
      return x
    },

    async publishEvent(params) {
      const x = await axios.post('/apps/event/publishEvent', params)
      return x
    },

   
    async likeEvents(params) {
      var x = null
      if (isUserLoggedIn())
        x = await axios.get('/apps/event/listlike', { params })
      else
        x = await axios.get('/apps/event/listlike_ext', { params })
      return x
    },


    async eventspartList(params) {
      const x = await axios.get('/apps/event/eventspartList',{ params})
      return x
    },


    async getCarousel(params) {
      const x = await axios.get('/apps/event/getcarousel',{ params})
      return x
    },

    async sendMail(params) {
      const x = await axios.post('/apps/mail/sendmain', params)
      return x
    },

    
    
    

  },
})
