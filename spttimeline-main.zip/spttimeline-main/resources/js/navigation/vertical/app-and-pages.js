export default [




  {
    heading: 'Пользователи',
    action: "manage",
    subject: "requests"
  },
  {
    title: 'Заявки на доступ',
    icon: { icon: 'tabler-mail' },
    to: 'apps-access-list',
    action: "manage",
    subject: "requests"
  },

  {
    heading: 'Администрирование',

  },
  {
    title: 'Уровни доступа',
    icon: { icon: 'ic:baseline-list' },
    to: 'apps-usertypes-list',
  },
  {
    title: 'Лог пользователей',
    icon: { icon: 'ic:baseline-list' },
    to: 'apps-logs-list',
  },


  {
    title: 'Пользователи',
    icon: { icon: 'ic:baseline-list' },
    to: 'apps-users-list',
  },


  {
    title: 'Сервисные функции ОО',
    icon: { icon: 'fluent-mdl2:process-meta-task' },
    to: 'apps-service-functions',
  },
]
