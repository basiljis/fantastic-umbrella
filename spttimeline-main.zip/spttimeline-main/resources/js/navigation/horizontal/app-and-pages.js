export default [
  {
    title: 'Пользователи',
    icon: { icon: 'tabler-file' },
    action: "manage",
    subject: "requests",

    children: [
      {
        title: 'Заявки на доступ',
        icon: { icon: 'tabler-mail' },
        to: 'apps-access-list',
        action: "manage",
        subject: "all"

      },

      {
        title: 'Уровни доступа',
        icon: { icon: 'ic:baseline-list' },
        to: 'apps-usertypes-list',
        action: "manage",
        subject: "all"

      },

 
      {
        title: 'Пользователи',
        icon: { icon: 'ic:baseline-list' },
        to: 'apps-logs-list',
        action: "manage",
        subject: "all"

      },

      {
        title: 'Сервисные функции ОО',
        icon: { icon: 'apps-service-functions' },
        to: 'apps-service-functions',
        action: "manage",
        subject: "all"

      },


     
    ]
  },
]

