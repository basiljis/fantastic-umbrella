import appAndPages from './app-and-pages'

export default [...appAndPages]
