<?php



use App\Models\spt_users_type;



use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;




if (! function_exists('check_null')) {
    function check_null($is)
    {

        $yid = 0;

        if (!is_null($is)) {
            $yid = $is;
        }
        return $yid;
    }
}


if (! function_exists('get_user_admin')) {
    function get_user_admin(int $uid)
    {
        $admin = 0;
        if (!is_null($uid)) {
            $admin = 0;


            $spt_ut = User::where('spt_user_id',$uid )->first()->spt_users_type;

            if (!is_null($spt_ut)) {
                $admin = spt_users_type::where('spt_users_type_id',$spt_ut )->first()->spt_users_type_admin;
            }

If ($admin == 2 || $admin == 3 || $admin == 4) {
    $admin = 1;
    }

        }
        return $admin ;
    }
}



