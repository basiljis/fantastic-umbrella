<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class events_users extends Model
{
    protected $table = 'events_users';
    protected $primaryKey = 'events_users_id';
}
