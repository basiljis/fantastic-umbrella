<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class spt_login extends Model
{
    protected $table = 'spt_login';
    protected $primaryKey = 'id_login';
}
