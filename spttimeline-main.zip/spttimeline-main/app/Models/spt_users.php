<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class spt_users extends Model
{
    protected $table = 'spt_users';
    protected $primaryKey = 'spt_user_id';

    public function setEmailAttribute($value)
    {
        $this->attributes['email'] = strtolower($value);
    }
    public function getEmailAttribute($value)
    {
        $this->attributes['email'] = strtolower($value);
    }

}

