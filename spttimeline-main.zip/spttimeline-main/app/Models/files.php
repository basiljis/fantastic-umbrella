<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;

class files extends Model
{
    protected $table = 'files';
    protected $primaryKey = 'files_id';
}
