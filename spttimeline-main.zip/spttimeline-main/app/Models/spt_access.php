<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class spt_access extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'spt_access';
    protected $primaryKey = 'spt_access_id';
}
