<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class spr_event_status extends Model
{
    protected $table = 'spr_event_status';
    protected $primaryKey = 'spr_event_status_id';
}
