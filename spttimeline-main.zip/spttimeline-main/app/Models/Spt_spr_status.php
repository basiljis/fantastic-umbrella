<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class spt_spr_status extends Model
{
    protected $table = 'spt_spr_status';
    protected $primaryKey = 'spt_spr_status_id';
}
