<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class spr_ages extends Model
{
    protected $table = 'spr_ages';
    protected $primaryKey = 'spr_ages_id';
}
