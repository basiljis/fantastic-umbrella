<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use SoftDeletes;
class mail_log extends Model
{
    protected $table = 'mail_log';
    protected $primaryKey = 'id';
}
