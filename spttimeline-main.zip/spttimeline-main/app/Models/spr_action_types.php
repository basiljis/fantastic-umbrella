<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class spr_action_types extends Model
{
    protected $table = 'spr_action_types';
    protected $primaryKey = 'spr_action_types_id';
}
