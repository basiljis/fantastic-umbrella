<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Notifications\VerifyEmail;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Notifications\ResetPasswordNotification;

class User extends Authenticatable implements MustVerifyEmail
{


    protected $table = 'spt_users';
    protected $primaryKey = 'spt_user_id';

    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $guarded = [];

    public function sendEmailVerificationNotification()
	{
		$this->notify(new VerifyEmail()); // my notification
	}
    

    public function setEmailAttribute($value)
    {
        $this->attributes['email'] = strtolower($value);
    }
  //  public function getEmailAttribute($value)
   // {
    //    $em = $this->email;
   //     return strtolower($value);
   // }
    public function getEmailAttribute($value)
    {
       // $this->attributes['email'] = strtolower($value);
        return strtolower($value);
    }

    public function sendPasswordResetNotification($token)
    {
    $this->notify(new ResetPasswordNotification($token));
    }



    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


}

