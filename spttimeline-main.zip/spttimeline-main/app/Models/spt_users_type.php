<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class spt_users_type extends Model
{
    protected $table = 'spt_users_type';
    protected $primaryKey = 'spt_users_type_id';
}
