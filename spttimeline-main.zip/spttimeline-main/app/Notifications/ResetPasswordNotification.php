<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Lang;

class ResetPasswordNotification extends Notification
{
    use Queueable;


    public $token;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($token)
    {
        $this->token = $token;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $url =   $this->resetUrl($notifiable);

        return (new MailMessage)
		->subject('Запрос сброса пароля')
		->markdown('mail.tpls.forgot', [
			'verify' =>$url,
            'count' => config('auth.passwords.'.config('auth.defaults.passwords').'.expire')
			]);
/*
        return (new MailMessage)
            ->subject('Запрос сброса пароля')
            ->line('Вы получили это письмо потому мы получили запрос на сброс пароля для вашего аккаунта')
            ->action('Сбросить пароль', $url)
            ->line(Lang::get('Время действия ссылки :count минут.', ['count' => config('auth.passwords.'.config('auth.defaults.passwords').'.expire')]))
            ->line('Если вы не запрашивали сброс пароля просто не реагируйте на это письмо')
        ->salutation("С уважением, \n Служба поддержки пользователей");*/

    }
    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    protected function resetUrl($notifiable)
    {
        return url(route('password.reset', [
            'token' => $this->token,
            'email' => $notifiable->getEmailForPasswordReset(),
        ], false));
    }


}
