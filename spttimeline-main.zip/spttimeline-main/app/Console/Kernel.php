<?php

namespace App\Console;

use App\Http\Controllers\ServiceController;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;


class Kernel extends ConsoleKernel
{

    protected $commands = [
        Commands\MonitoringUpdate::class,
        commands\RezultsDecode::class,
         commands\KlassProgress::class,
        commands\ReportItog::class,
        commands\ReportPMOItog::class,
        commands\ReportItogRisk::class
    ];


    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('Monitor:update')
            ->twiceDaily(7, 17)->withoutOverlapping();// ->daily()->at('02:00')->withoutOverlapping();// ->everyTenMinutes()->withoutOverlapping();;//
        // $schedule->command('inspire')->hourly();
     //   $schedule->call(function () {
            //DB::table('recent_users')->delete();
     //       $data=[];
       //     $data =  json_decode(ServiceController::updateMonitoringTableF(1, 99999));
       // })->daily()->at('02:00')->withoutOverlapping();//->everyFiveMinutes();->withoutOverlapping();


        $schedule->command('Decode:update')
            ->everyTwoMinutes()->withoutOverlapping();

       // $schedule->command('Decode:update2')
       //     ->everyTwoMinutes()->withoutOverlapping();

    $schedule->command('Progress:update')

        ->everyTwoMinutes()->withoutOverlapping();

        $schedule->command('Report:itog')
            ->twiceDaily(6, 18)->withoutOverlapping();
        $schedule->command('Report:pmo_itog')
            ->twiceDaily(8, 20)->withoutOverlapping();
        $schedule->command('Report:itogrisk')
            ->dailyAt('01:00')->withoutOverlapping();
     //   $schedule->call(function () {
       //    $data=[];
        //    $data =  json_decode(ServiceController::decodeRezultSaveS(1));
       // })->everyFiveMinutes()->withoutOverlapping();

    }



    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {

        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
