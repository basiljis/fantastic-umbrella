<?php

namespace App\Console\Commands;

use App\Http\Controllers\ServiceController;
use Illuminate\Console\Command;

class KlassProgress extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Progress:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Рассчет прогресса по классам';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        $data =  json_decode(ServiceController::UpdateKlassProgressF(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
