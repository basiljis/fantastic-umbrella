<?php

namespace App\Console\Commands;

use App\Http\Controllers\ServiceController;
use Illuminate\Console\Command;

class MonitoringUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Monitor:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Расчет для таблиц СПТ мониторинг';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

       // $data=[];
        $data = json_decode(ServiceController::updateMonitoringTableF(1, 99999));
        return json_encode($data);
       // return Command::SUCCESS;
    }
}
