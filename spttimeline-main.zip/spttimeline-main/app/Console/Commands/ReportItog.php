<?php

namespace App\Console\Commands;

use App\Http\Controllers\ReportController;
use Illuminate\Console\Command;

class ReportItog extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Report:itog';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Рассчет итогового отчета';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        $data =  json_decode(ReportController::rep_itog_save(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
