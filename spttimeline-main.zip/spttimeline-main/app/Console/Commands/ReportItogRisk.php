<?php

namespace App\Console\Commands;

use App\Http\Controllers\ReportController;
use Illuminate\Console\Command;

class ReportItogRisk extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Report:itogrisk';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Рассчет итогового отчета по риску';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        $data =  json_decode(ReportController::rep_itog_risk_save(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
