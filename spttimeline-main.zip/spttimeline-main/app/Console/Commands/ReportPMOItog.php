<?php

namespace App\Console\Commands;

use App\Http\Controllers\ReportController;
use Illuminate\Console\Command;

class ReportPMOItog extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Report:pmo_itog';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Рассчет итогового отчета ПМО';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        $data =  json_decode(ReportController::rep_PMO_itog_save(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
