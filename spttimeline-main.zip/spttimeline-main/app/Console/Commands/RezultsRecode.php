<?php

namespace App\Console\Commands;

use App\Http\Controllers\ServiceController;
use Illuminate\Console\Command;

class RezultsRecode extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Decode:update2';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'ПереРасшифровка результатов_2';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        //$data =  json_decode(ServiceController::decodeRezultSaveS2(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
