<?php

namespace App\Console\Commands;

use App\Http\Controllers\DecodeController;
use App\Http\Controllers\ReportController;
use Illuminate\Console\Command;

class Report500 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Report:r500';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Рассчет 500';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
        $data =  json_decode(DecodeController::getRez500(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
