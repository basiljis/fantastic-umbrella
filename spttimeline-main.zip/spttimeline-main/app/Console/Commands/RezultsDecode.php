<?php

namespace App\Console\Commands;

use App\Http\Controllers\ServiceController;
use Illuminate\Console\Command;

class RezultsDecode extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Decode:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Расшифровка результатов';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       // $data=[];
       // $data =  json_decode(ServiceController::decodeRezultSaveS(1));
        return json_encode($data);//Command::SUCCESS;
    }
}
