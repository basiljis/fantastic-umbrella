<?php

namespace App\Http\Middleware;

use Closure;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use JWTAuth;
use PHPOpenSourceSaver\JWTAuth\Token;
use Symfony\Component\HttpFoundation\Response as HttpCodes;

class JWTAuthenticate
{
    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return Response
     */
    public function handle(Request $request, Closure $next): Response
    {
      try {
        $rawToken = $request->cookie('testing');
        $token = new Token($rawToken);
        $payload = JWTAuth::decode($token);
        if($payload['kod'] && $payload['kod']===$request->input('kod'))
        return $next($request);
        else {
          return response(
            ['message'=> 'invalid token'],
            HttpCodes::HTTP_INTERNAL_SERVER_ERROR
          );
        }


      } catch(Exception $e) {
        return response(
          ['message'=> 'invalid token'],
          HttpCodes::HTTP_INTERNAL_SERVER_ERROR
        );
      }

      return response(
        ['message'=> 'invalid token'],
        HttpCodes::HTTP_INTERNAL_SERVER_ERROR
      );
    }
}
