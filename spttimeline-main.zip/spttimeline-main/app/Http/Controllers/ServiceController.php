<?php

namespace App\Http\Controllers;

use App\Models\events_users;
use App\Models\mail_log;
use Illuminate\Http\Request;
use App\Models\spr_action_formats;
use App\Models\spr_action_types;
use App\Models\spr_event_status;
use App\Models\spr_ages;
use App\Models\events;
use App\Models\files;
use Hamcrest\Arrays\IsArray;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Mail\FromMainMail;
use Illuminate\Support\Facades\Mail;

use SoapClient;

use Illuminate\Support\Facades\Log;

class ServiceController extends Controller
{
    private $image_ext = ['jpg', 'jpeg', 'png', 'gif', 'tiff', 'tif'];
    private $audio_ext = ['mp3', 'ogg', 'mpga'];
    private $video_ext = ['mp4', 'mpeg'];
    private $document_ext = ['doc', 'docx', 'pdf', 'odt', 'xlsx', 'xls'];

    private function allExtensions()
    {
        return array_merge($this->image_ext, $this->audio_ext, $this->video_ext, $this->document_ext);
    }

    private function getType($ext)
    {
        $type = 'any';
        if (in_array($ext, $this->image_ext)) {
            $type = 'image';//return 'image';
        }

        if (in_array($ext, $this->audio_ext)) {
            $type = 'audio';//return 'audio';
        }

        if (in_array($ext, $this->video_ext)) {
            $type = 'video';//return 'video';
        }

        if (in_array($ext, $this->document_ext)) {
            $type = 'document';//return 'document';
        }
        return $type;
    }

    public function SpractionformatsAdd(Request $request)
    {

        $Useru = new spr_action_formats;
        if (!$request->spr_action_formats_status) $st = 2; else $st = $request->spr_action_formats_status;
        //if($request->spr_action_formats_status) $st=$request->spr_action_formats_status;
        $Useru->spr_action_formats_name = $request->spr_action_formats_name;
        //$Useru->spr_action_formats_status = $request->spr_action_formats_status;
        $Useru->spr_action_types_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }

    public function SpractiontypesAdd(Request $request)
    {

        $Useru = new spr_action_types;
        if (!$request->spr_action_types_status) $st = 2; else  $st = $request->spr_action_types_status;
        $Useru->spr_action_types_name = $request->spr_action_types_name;
        $Useru->spr_action_types_icon = $request->spr_action_types_icon;
        $Useru->spr_action_types_color = $request->spr_action_types_color;
        $Useru->spr_action_types_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }

    public function SpragesAdd(Request $request)
    {

        $Useru = new spr_ages;
        if (!$request->spr_ages_status) $st = 2; else  $st = $request->spr_ages_status;
        $Useru->spr_ages_name = $request->spr_ages_name;
        $Useru->spr_ages_icon = $request->spr_ages_icon;
        $Useru->spr_ages_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }

    public function SpreventstatusAdd(Request $request)
    {

        $Useru = new spr_event_status;
        if (!$request->spr_event_status_status) $st = 2; else  $st = $request->spr_event_status_status;
        $Useru->spr_event_status_name = $request->spr_event_status_name;
        $Useru->spr_event_status_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }


    public function storeEvent(Request $request)
    {
        $f_array = [];
        $ff_array = [];
        $path1 = $request->file('cropped')?->store('cropped', 'public');
        $f_array['cropped'] = $path1;
        $path2 = $request->file('wallpaper')?->store('wallpaper', 'public');
        $f_array['wallpaper'] = $path2;
        // Log::info($path1);
        if (is_array($request->file('files')))
            foreach ($request->file('files') as $key => $value) {
                $path = $request->file('files')[$key]->store('files', 'public');
                //  $ff_array['files']= $path;
                array_push($ff_array, $path);

                //  Log::info($path);
            }
        $f_array['files'] = $ff_array;
        $event = new events;
        $event->events_type = $request->type;
        $event->events_format = $request->format;
        if (isset($request->age)) $event->events_age = $request->age;
        if (isset($request->price)) $event->events_price = $request->price;
        if (isset($request->datebegin)) $event->events_start_date = $request->datebegin;
        if (isset($request->dateend)) $event->events_end_date = $request->dateend;
        if (isset($request->events_dt_start)) $event->events_dt_start = $request->events_dt_start;
        if (isset($request->timebegin)) $event->events_start_time = $request->timebegin;
        if (isset($request->events_dt_end)) $event->events_dt_end = $request->events_dt_end;
        if (isset($request->timeend)) $event->events_end_time = $request->timeend;
        if (isset($request->events_status)) $event->events_status = $request->events_status;
        /* if ($request->datebegin)$event->events_dt_start = $request->datebegin;
         if (isset($request->timebegin)) $event->events_start_time = $request->timebegin;
         if (isset($request->dateend)) $event->events_dt_end = $request->dateend;
         if (isset($request->timeend)) $event->events_end_time = $request->timeend;
         */
        if (isset($request->subline)) $event->events_desc = $request->subline;
        if (isset($request->name)) $event->events_name = $request->name;
        if (isset($request->userscout)) $event->events_users = $request->userscout;
        if (isset($request->shortdesc)) $event->events_anons_short = $request->shortdesc;
        if (isset($request->fulldesk)) $event->events_anons_long = $request->fulldesk;
        if (isset($request->carousel)) $event->events_carusel = $request->carousel;
        if (isset($f_array)) $event->events_files = json_encode($f_array);
        if (isset($request->partners)) $event->events_partners = json_encode($request->partners);
        if (isset($request->participants)) $event->events_participants = json_encode($request->participants);
        if (isset($request->video)) $event->events_video_www = $request->video;
        if (isset($request->tickets)) $event->events_tickets_www = $request->tickets;
        if (isset($request->site)) $event->events_local_www = $request->site;
        if (isset($request->place)) $event->events_local_name = $request->place;
        if (isset($request->address)) $event->events_adress = $request->address;
        isset($request->map) ? $event->events_maps = $request->map : $event->events_maps = '';
        //$event->events_ = $request->'];

        $event->save();
        $id_new = $event->events_id;

        $data['status'] = 'Данные сохранены успешно';
        $data['new_id'] = $id_new;
        // $data['data'] =  $request;
        return json_encode($data);
    }

    public function updateEvent(Request $request)
    {


        $event_id = $request->event_id;
        if (isset($event_id)) {

            /*файл*/
            // $data['ERROR1'] = 'Не проходит';

            // Log::info($request->files);


            if (!is_null(auth()->user()->spt_user_id)) {
                $event_id = $request->event_id;
                $uid = auth()->user()->spt_user_id;
                $f_array = [];
                $fpre_array = [];
                $ff_array = [];
                $ft = date('dMYHis');
                $max_size = (int)ini_get('upload_max_filesize') * 1000;
                $all_ext = implode(',', $this->allExtensions());
                $event = events::find($event_id);
                $fpre_array = $event->events_files ? json_decode($event->events_files, true) : [];
                if (!isset($fpre_array['files'])) $fpre_array['files'] = [];
                $path1 = $request->file('cropped')?->store('cropped', 'public');
                //array_push($f_array['cropped'], $path);
                if (isset($path1)) {
                    //     $fpre_array=json_decode($event->events_files,true) ;
                    $f_array['cropped'] = $path1;
                } else {
                    if (isset($fpre_array['cropped'])) {
                        $f_array['cropped'] = $fpre_array['cropped'];
                    } else {
                        $f_array['cropped'] = null;
                    }

                }
                // $f_array['cropped']= $path1;
                //  Log::info($path1);
                $path2 = $request->file('wallpaper')?->store('wallpaper', 'public');
                // array_push($f_array['wallpaper'], $path);

                if (isset($path2)) {
                    //   $fpre_array=json_decode($event->events_files,true) ;
                    $f_array['wallpaper'] = $path2;
                } else {
                    if (isset($fpre_array['wallpaper'])) {
                        $f_array['wallpaper'] = $fpre_array['wallpaper'];
                    } else {
                        $f_array['wallpaper'] = null;
                    }
                    //    $f_array['wallpaper']= $fpre_array['wallpaper'];

                }


                //  Log::info($path2);
                //  $nm = 0;
                // $nmf = 2;
                if (is_array($request->file('files')))
                    foreach ($request->file('files') as $key => $value) {
                        //   $nm = $nm + 1;
                        $path = $request->file('files')[$key]?->store('files', 'public');
                        //  Log::info("path - ".$path);
                        $fpre_array['files'][] = $path;
                        // array_push($ff_array, $path);
                        /*if (isset($fpre_array['files'])) {
                            array_push($fpre_array['files'], $path);
                            $nmf = 0;
                        } else {
                            array_push($ff_array, $path);
                            $nmf = 1;
                        }*/
                        //Log::info($path);
                    }
                /*   if ($nmf == 1 or $nmf == 2) {
                       $f_array['files'] = $fpre_array['files'];
                   }
                   if ($nmf == 0) {
                       $f_array['files'] = $ff_array;
                   }
   */
                $f_array['files'] = $fpre_array['files'];

                /*
                if ($nm==0)   {
                   // $fpre_array=json_decode($event->events_files,true) ;
                    $f_array['files'] = $fpre_array['files'];} else {
                    $f_array['files']= $ff_array;}*/
                ///    $f_array['files'] = $fpre_array['files'];
                /*
                $file = $request->files->get('0');//files['cropped'];
                $ext = $file->getClientOriginalExtension();
                $type = $this->getType($ext);

                if (!is_null($file)) {

                    $Event_file = files::where('files_event_id', '=', $event_id)->where('files_status', '=', '1')->first();
                    if (!is_null($Event_file)) {
                        // обнуляем запись
                        $Event_file->files_status = '2';
                        $Event_file->files_editor = $uid;
                        $Event_file->update();
                        $data['action'] = 'файл аннулирован';
                    }


                    if (Storage::putFileAs('/public/files/' . $type . '/', $file, 'file' . $ft . '.' . $ext)) {

                        $adr = '/storage/files/' . $type . '/file' . $ft . '.' . $ext;

                        $NEWFILE = new files;

                        $NEWFILE->files_event_id = $event_id;
                        $NEWFILE->files_status = '1';
                        $NEWFILE->files_adr = $adr;
                        $NEWFILE->files_creator = $uid;
                        $NEWFILE->save();
                        $data['ok3'] = 'файл сохранен';

                    }
                } else {

                    $data['ERROR2'] = 'файл не передан';
                }*/
            } else {

                $data['ERROR1'] = 'Не авторизован';
            }


            // $event =  events::find($event_id);
            $event->events_type = $request->type;
            $event->events_format = $request->format;

            if (isset($request->age)) $event->events_age = $request->age;
//            if (isset($request->price)) $event->events_price = $request->price;
            isset($request->price) ? $event->events_price = $request->price : $event->events_price = '0';
            if (isset($request->datebegin)) $event->events_start_date = $request->datebegin;
//            if (isset($request->dateend)) $event->events_end_date = $request->dateend;
            isset($request->dateend) ? $event->events_end_date = $request->dateend : $event->events_end_date = null;
            if (isset($request->events_dt_start)) $event->events_dt_start = $request->events_dt_start;
            if (isset($request->timebegin)) $event->events_start_time = $request->timebegin;
            isset($request->events_dt_end) ? $event->events_dt_end = $request->events_dt_end : $event->events_dt_end = null;
            //if (isset($request->events_dt_end)) $event->events_dt_end = $request->events_dt_end;
            //           if (isset($request->timeend)) $event->events_end_time = $request->timeend;
            isset($request->timeend) ? $event->events_end_time = $request->timeend : $event->events_end_time = null;
            isset($request->subline) ? $event->events_desc = $request->subline : $event->events_desc = '';

//            if (isset($request->subline)) $event->events_desc = $request->subline;
            //     if (isset($request->name)) $event->events_name = $request->name;
            isset($request->name) ? $event->events_name = $request->name : $event->events_name = '';
            isset($request->userscout) ? $event->events_users = $request->userscout : $event->events_users = null;
            // if (isset($request->userscout)) $event->events_users = $request->userscout;
            isset($request->shortdesc) ? $event->events_anons_short = $request->shortdesc : $event->events_anons_short = '';
            //          if (isset($request->shortdesc)) $event->events_anons_short = $request->shortdesc;
            isset($request->fulldesk) ? $event->events_anons_long = $request->fulldesk : $event->events_anons_long = '';
            //if (isset($request->fulldesk)) $event->events_anons_long = $request->fulldesk;
            isset($request->carousel) ? $event->events_carusel = $request->carousel : $event->events_carusel = null;
//            if (isset($request->carousel)) $event->events_carusel = $request->carousel;

            if (isset($request->partners)) $event->events_partners = json_encode($request->partners);
            if (isset($f_array)) $event->events_files = json_encode($f_array);
            if (isset($request->participants)) $event->events_participants = json_encode($request->participants);
            isset($request->video) ? $event->events_video_www = $request->video : $event->events_video_www = '';
            isset($request->tickets) ? $event->events_tickets_www = $request->tickets : $event->events_tickets_www = '';
            isset($request->site) ? $event->events_local_www = $request->site : $event->events_local_www = '';
            isset($request->place) ? $event->events_local_name = $request->place : $event->events_local_name = '';
            isset($request->address) ? $event->events_adress = $request->address : $event->events_adress = '';
            isset($request->map) ? $event->events_maps = $request->map : $event->events_maps = '';

            if (isset($request->events_status)) $event->events_status = $request->events_status;
            $event->update();

            $data['status'] = 'Данные успешно обновлены';
            $data['wallpaper'] = $f_array;
        } else {
            $data['status'] = 'Ошибка.Не передан параметр';

        }
        $data['data'] = $request;
        return json_encode($data);
    }

    public function updateactiontypes(Request $request)//, $id
    {
        $UserType = spr_action_types::find($request->input('spr_action_types_id'));
        $UserType->spr_action_types_name = $request->input('spr_action_types_name');
        $UserType->spr_action_types_color = $request->input('spr_action_types_color');
        $UserType->spr_action_types_icon = $request->input('spr_action_types_icon');
        $UserType->spr_action_types_status = $request->input('spr_action_types_status');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';
        return json_encode($data);
    }

    public function updateactionformats(Request $request)//, $id
    {
        $UserType = spr_action_formats::find($request->input('spr_action_formats_id'));
        $UserType->spr_action_formats_name = $request->input('spr_action_formats_name');
        $UserType->spr_action_formats_status = $request->input('spr_action_formats_status');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';
        return json_encode($data);
    }

    public function updateages(Request $request)//, $id
    {
        $UserType = spr_ages::find($request->input('spr_ages_id'));
        $UserType->spr_ages_name = $request->input('spr_ages_name');
        $UserType->spr_ages_icon = $request->input('spr_ages_icon');
        $UserType->spr_ages_status = $request->input('spr_ages_status');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';
        return json_encode($data);
    }

    public function updateeventstatus(Request $request)//, $id
    {
        $UserType = spr_event_status::find($request->input('spr_event_status_id'));
        $UserType->spr_event_status_name = $request->input('spr_event_status_name');
        $UserType->spr_event_status_status = $request->input('spr_event_status_status');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';
        return json_encode($data);
    }

    public function getEventlistadm(Request $request)
    {
        $currentPage = $request->get('currentPage');//??1
        $perPage = $request->get('perPage');
        $q = $request->get('q');
        $eventformat = $request->eventformat;
        $eventtype = $request->eventtype;
        $eventstatus = $request->eventstatus;
        $datebegin = $request->datebegin;
        $data = DB::table('events')
            ->select("spr_event_status.*", "spr_action_formats.*", "spr_action_types.*", "events.*")
            ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
        if ($eventformat) $data = $data->where('events_format', $eventformat);
        if ($eventtype) $data = $data->where('events_type', $eventtype);
        if ($eventstatus) $data = $data->where('events_status', $eventstatus);
        if ($datebegin) $data = $data->where('events_start_date', $datebegin);
        if (!is_null($q)) $data = $data->where(function ($query) use ($q) {
            $query->where('events_name', 'ILIKE', "%{$q}%")
                ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
        });
        $data = $data->addSelect([
            'reg_count' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                ->whereColumn('events_users_event_id', 'events.events_id')
                ->where('events_users.events_users_status', '=', 1)
                //  ->Where('events_users.events_users_event_id', '=', $user_id)
                ->where('deleted_at', NULL)
        ]);
        $data = $data->addSelect([
            'heartcount' => events_users::selectraw('COUNT(*)')
                ->whereColumn('events_users_event_id', 'events.events_id')
                ->where('events_users.events_users_status', '=', 1)
                ->Where('events_users.events_users_mark', '>', 0)
                ->where('deleted_at', NULL)
        ]);
        $data = $data->addSelect([
            'heartsum' => events_users::selectraw('coalesce(SUM(events_users_mark),0)')
                ->whereColumn('events_users_event_id', 'events.events_id')
                ->where('events_users.events_users_status', '=', 1)
                ->Where('events_users.events_users_mark', '>', 0)
                ->where('deleted_at', NULL)
        ]);
        $data = $data->orderby('events_id')->paginate($perPage, ['*'], null, $currentPage);

        return json_encode($data);
    }

    public function getEvent(Request $request)
    {
        if (isset($request->event_id)) {
            if (is_numeric($request->event_id)) {
                $data = events:://find($request->input('event_id'))
                Where('events_id', '=', $request->input('event_id'))
                    ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
                    ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
                    ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id')
                    ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
                    ->get();
                if ($data->count() < 1) {
                    $data['ERROR'] = ' Данные не получены';
                }

            } else {
                $data['ERROR'] = 'Параметр в неверном формате';
            }
        } else {
            $data['ERROR'] = 'Не передан параметр';
        }
        return json_encode($data);
    }

    public function getEventreg(Request $request)
    {
        if (isset($request->event_id)) {
            if (is_numeric($request->event_id)) {
                $data = events:://find($request->input('event_id'))
                select("spr_ages.*", "spr_action_formats.*", "spr_action_types.*", "events.*", "spr_event_status.*")
                    ->Where('events_id', '=', $request->input('event_id'))
                    ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
                    ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
                    ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
                    ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
                if (!is_null(auth()->user()->spt_user_id)) {
                    $user_id = auth()->user()->spt_user_id;
                    $data = $data->addSelect([
                        'registered' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                            ->whereColumn('events_users_event_id', 'events.events_id')
                            ->where('events_users.events_users_status', '=', 1)
                            ->Where('events_users.events_users_user_id', '=', $user_id)
                            ->where('deleted_at', NULL)
                    ]);
                }
                $data = $data->get();
                if ($data->count() < 1) {
                    $data['ERROR'] = ' Данные не получены';
                }
            } else {
                $data['ERROR'] = 'Параметр в неверном формате';
            }
        } else {
            $data['ERROR'] = 'Не передан параметр';
        }
        return json_encode($data);
    }

    public function getSprActionTypesListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('spr_action_types')
            ->select('spr_action_types_name', 'spr_action_types_color', 'spr_action_types_icon', 'spr_action_types_id', 'spr_action_types_status', 'spt_spr_status_name as spr_action_types_status_txt')
            ->leftJoin('spt_spr_status', 'spr_action_types.spr_action_types_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('spr_action_types_id')->paginate($perPage, ['*'], null, $currentPage);
        //->get();
        return json_encode($data);
    }

    public function getSprActionTypesList(Request $request)
    {
        $data = DB::table('spr_action_types')
            ->select('spr_action_types_id as id', 'spr_action_types_name as name', 'spr_action_types_color as color', 'spr_action_types_icon as icon')
            ->where('spr_action_types_status', '1')
            ->get();
        return json_encode($data);
    }

    public function getSprAgesListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('spr_ages')
            ->select('spr_ages_name', 'spr_ages_id', 'spr_ages_status', 'spr_ages_icon', 'spt_spr_status_name as spr_ages_status_txt')
            ->leftJoin('spt_spr_status', 'spr_ages.spr_ages_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('spr_ages_id')->paginate($perPage, ['*'], null, $currentPage);

        return json_encode($data);
    }

    public function getSprEventStatusListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('spr_event_status')
            ->select('spr_event_status_name', 'spr_event_status_id', 'spr_event_status_status', 'spt_spr_status_name as spr_event_status_txt')
            ->leftJoin('spt_spr_status', 'spr_event_status.spr_event_status_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('spr_event_status_id')->paginate($perPage, ['*'], null, $currentPage);

        return json_encode($data);
    }

    public function getSprAgesList(Request $request)
    {
        $data = DB::table('spr_ages')
            ->select('spr_ages_id as id', 'spr_ages_name as name')
            ->where('spr_ages_status', '1')->orderBy('id')
            ->get();
        return json_encode($data);
    }

    public function getSprActionFormatsListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('spr_action_formats')
            ->select('spr_action_formats_name', 'spr_action_formats_id', 'spr_action_formats_status', 'spt_spr_status_name as spr_action_formats_status_txt')
            ->leftJoin('spt_spr_status', 'spr_action_formats.spr_action_formats_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('spr_action_formats_id')->paginate($perPage, ['*'], null, $currentPage);
        //->get();
        return json_encode($data);
    }

    public function getSprActionFormatsList(Request $request)
    {
        $data = DB::table('spr_action_formats')
            ->select('spr_action_formats_id as id', 'spr_action_formats_name as name')
            //->select('spr_action_formats_name', 'spr_action_formats_id')
            ->where('spr_action_formats_status', '1')
            ->orderby('spr_action_formats_id')
            ->get();
        return json_encode($data);
    }

    //
    public function myCmpS($a, $b)
    {
        if ($a['n6'] == $b['n6']) return 0;
        return $a['n6'] > $b['n6'] ? 1 : -1;
    }

    public function myCmpD($a, $b)
    {
        if ($a['n6'] == $b['n6']) return 0;
        return $a['n6'] < $b['n6'] ? 1 : -1;
    }

    public function Median($Array)
    {
        return ServiceController::Quartile_50($Array);
    }

    public static function Quartile_25($Array)
    {
        return ServiceController::Quartile($Array, 0.25);
    }

    public static function Quartile_50($Array)
    {
        return ServiceController::Quartile($Array, 0.5);
    }

    public static function Quartile_75($Array)
    {
        return ServiceController::Quartile($Array, 0.75);
    }

    public static function Quartile($Array, $Quartile)
    {
        sort($Array);
        $pos = (count($Array) - 1) * $Quartile;

        $base = floor($pos);
        //$base = round($pos, 2)
        $rest = $pos - $base;

        if (count($Array) < 1) {
            return 0;// пустой массив
        }

        if (isset($Array[$base + 1])) {
            return $Array[$base] + $rest * ($Array[$base + 1] - $Array[$base]);
        } else {
            return $Array[$base];
        }
    }

    public function Average($Array)
    {
        return array_sum($Array) / count($Array);
    }

    public function StdDev($Array)
    {
        if (count($Array) < 2) {
            return 0;//убрать если ошибка
        }

        $avg = ServiceController::Average($Array);

        $sum = 0;
        foreach ($Array as $value) {
            $sum += pow($value - $avg, 2);
        }

        return sqrt((1 / (count($Array) - 1)) * $sum);
    }


    public function countperDay(Request $request)
    {
        $data = DB::table('events')
            ->select(DB::raw("to_char(events_start_date::date, 'DD.MM.YYYY') as date"), DB::raw('count(*) as count'))
            ->where('events_status', '2')
            ->groupBy('events_start_date')
            ->get();
        return json_encode($data);
    }

    public function getMailLog(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $q = $request->get('q');

        $data = mail_log::orderby('id', 'desc');
        if (!is_null($q)) $data = $data->where(function ($query) use ($q) {
            $query->where('user_email', 'ILIKE', "%{$q}%")
                ->orWhere('user_name', 'ILIKE', "%{$q}%")
                ->orWhere('theme', 'ILIKE', "%{$q}%");
        });
        $data = $data->paginate($perPage, ['*'], null, $currentPage);

        return json_encode($data);
    }
    public function tomail(Request $request)
    {
return array(
"driver" => "smtp",
"host" => "app.debugmail.io",
"port" => "25",
"from" => array(
"address" => "john.doe@example.org",
"name" => "John Doe"
),
"encryption" => "tls",
"username" => "df23fb0c-71a0-4356-be9e-79dd2ab05e6c",
"password" => "828305a0-072d-4a40-822a-5902c09c13db",
"sendmail" => "/usr/sbin/sendmail -bs",
"pretend" => false
);
}
    public function MailFromMain(Request $request)
    {
        if ($request->start ==5) {
            $main_email = 'hello@example.com';//! указать
            $data_mail['email'] = $request->email;
            $data_mail['name'] = $request->name;
            $data_mail['phone'] = $request->phone;
            $data_mail['text'] = $request->text;
            $data_mail['accept'] = $request->accept;
            $send_rez = "TEST";

            if (Mail::to($main_email)->send(new FromMainMail($data_mail))) {
                $send_rez = "TRUE";
            } else {
                $send_rez = "FALSE";
            }


            $LOG_MAIL = new mail_log;
            //$LOG_MAIL->id_user_initiator = $userId;
          // $LOG_MAIL->id_user = $datau['spt_user_id'];
            $LOG_MAIL->IP_adr =   $request->ip();
            $LOG_MAIL->user_name = $request->name;
            $LOG_MAIL->user_email = $request->email;
            $LOG_MAIL->theme = 'Сообщение с главной страницы сайта' . config('app.name');
            $LOG_MAIL->rez = $send_rez;
            // $SPT_MAIL->spt_rep_list_comment = "Сформировано " . date('Y-m-d H:i:s');
            $LOG_MAIL->save();
            $data['REZULT'] = 'Результат: '.$send_rez ;
        }else{
            $data['ERROR'] = 'Не передан параметр';
        }
        return json_encode($data);
    }
}
