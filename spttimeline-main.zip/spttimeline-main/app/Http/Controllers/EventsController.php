<?php

namespace App\Http\Controllers;
use Illuminate\Support\Collection;
//use Illuminate\Support\Number;
use Illuminate\Support\Carbon;
use App\Models\events;
use App\Models\events_users;
use App\Models\participants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EventsController extends Controller
{
    public function starstoEvent(Request $request)
    {
        $date_now = date('Y-m-d H:i:s');

        $data['status'] = 0;
        $event_id = $request->event_id;
        $datae = events::where('events_id', $event_id)
                        ->first();
        if (!is_null($datae)) {
        if($datae['events_dt_end'] < $date_now){
        $mark = $request->mark;
        if (isset($event_id) and isset($mark)) {
            if (isset(auth()->user()->spt_user_id)) {
                $user_id = auth()->user()->spt_user_id;

                $dataau = events_users::where('events_users_event_id', $event_id)
                    ->where('events_users_user_id', $user_id)
                    ->where('events_users_status', '1')
                    ->first();
                if (!is_null($dataau)) {

                    // $Useru = new events_users;
                    $dataau->events_users_mark = $mark;
                    $dataau->update();
                    $data['status'] = 'Оценка учтена';

                } else {
                    $data['status'] = 'На мероприятие не зарегистрирован';
                }

            }}}else {
            $data['status'] = 'Дождитесь окончания мероприятия';
        }

        }
        return json_encode($data);
    }
    public function registertoEvent(Request $request)
    {
        $data['status'] = 0;
        $event_id = $request->event_id;
        if (isset($event_id)) {
            if (!is_null(auth()->user()->spt_user_id)) {
                $user_id  = auth()->user()->spt_user_id;
                $confirmed = auth()->user()->email_verified_at;
              if ($confirmed != null) {

                  $dataau = events_users::where('events_users_event_id', $event_id)
                      ->where('events_users_user_id', $user_id)
                      ->where('events_users_status', '1')
                      ->first();
                  if (is_null($dataau)) {

                      $Useru = new events_users;
                      $Useru->events_users_user_id = $user_id;
                      $Useru->events_users_event_id = $event_id;
                      $Useru->events_users_status = 1;
                      $Useru->save();
                      $data['status'] = 'Регистрация на мероприятие прошла успешно';

                  } else {
                      $data['status'] = 'Ранее зарегистрирован';
                  }
              }else {
                  $data['status'] ='Пожалуйста подтвердите учетную запись';
              }
            }
        }
        return json_encode($data);
    }
    public function unregistertoEvent(Request $request)
    {
        $data['status'] = 0;
        $event_id = $request->event_id;
        if (isset($event_id)) {
            if (!is_null(auth()->user()->spt_user_id)) {
                $user_id  = auth()->user()->spt_user_id;

                $dataau = events_users::where('events_users_event_id', $event_id)
                    ->where('events_users_user_id', $user_id)
                    ->where('events_users_status', '1')
                    ->first();
                if (!is_null($dataau)) {
                    events_users::where('events_users_status', 1)
                        ->where('events_users_user_id', $user_id)
                        ->where('events_users_event_id', $event_id)
                        ->update(['events_users_status' => 0]);

                    $data['status'] = 'Регистрация на мероприятие отменена';

                } else {
                    $data['status'] = 'Ранее не зарегистрирован';
                }

            }
        }
        return json_encode($data);
    }
    public function getuserEventlist(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $user_id = auth()->user()->spt_user_id;
            $currentPage = $request->get('currentPage');//??1
            $perPage = $request->get('perPage');
            if (is_null($perPage)){ $perPage =10;}
            $q = $request->get('q');
            $eventformat = $request->eventformat;
            $eventtype = $request->eventtype;
            $datebegin = $request->datebegin;
            $data = DB::table('events')
                ->leftJoin('spt_spr_status', 'events.events_status', '=', 'spt_spr_status.spt_spr_status_id')
                ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
                ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
                ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id')
                ->leftJoin('events_users', 'events.events_id', '=', 'events_users.events_users_event_id')
                ->where('events_status', 2)
            ->where('events_users_status', 1);
            if ($eventformat) $data = $data->where('events_format', $eventformat);
            if ($eventtype) $data = $data->where('events_type', $eventtype);
            if ($datebegin) $data = $data->where('events_start_date', $datebegin);
            if (!is_null($q)) $data = $data->where(function ($query) use ($q) {
                $query->where('events_name', 'ILIKE', "%{$q}%")
                    ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                    ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
            });
        /*    $data = $data ->addSelect([
                'registered' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                    ->whereColumn('events_users_event_id', 'events.events_id')
                    ->where('events_users.events_users_status', '=', 1)
                    ->Where('events_users.events_users_user_id', '=',  $user_id)
                    ->where('deleted_at', NULL)
            ]);*/
            $data = $data->where('events_users_user_id', $user_id);
            $data = $data->orderby('events_id')->paginate($perPage, ['*'], null, $currentPage);


        } else {
            $data['error'] = 'Пользователь не авторизован';
        }
        return json_encode($data);
    }
    public function getEventsLike(Request $request){
        $datebegin = date('Y-m-d');
              $data = events:: select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")
            ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spt_spr_status', 'events.events_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->where('events_status', 2)
            ->where('events_start_date','>=', $datebegin);
        if (!is_null(auth()->user()->spt_user_id)) {
            $user_id = auth()->user()->spt_user_id;
            $data = $data->addSelect([
                'registered' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                    ->whereColumn('events_users_event_id', 'events.events_id')
                    ->where('events_users.events_users_status', '=', 1)
                    ->Where('events_users.events_users_user_id', '=', $user_id)
                    ->where('deleted_at', NULL)
            ]);
        }
        $data = $data ->orderby('events_id','desc')
            ->take(4)
            ->get();
        return json_encode($data);
    }
    public function getEventsLike_ext(Request $request){
        $datebegin = date('Y-m-d');
      //  $data = DB::table('events')
        $data = events:: select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")
            ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spt_spr_status', 'events.events_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
           // ->leftJoin('events_users', 'events.events_id', '=', 'events_users.events_users_event_id')
            ->where('events_status', 2)
          //  ->where('events_users_event_id',null)

            ->where('events_start_date','>=', $datebegin);
              $data = $data ->orderby('events_id','desc')
        ->take(4)
            ->get();
        return json_encode($data);
    }
    public function getEventsCarousel_ext(Request $request){
        $datebegin = date('Y-m-d');
        //  $data = DB::table('events')
        $data = events:: select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")
            ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spt_spr_status', 'events.events_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->where('events_status', 2)
            ->where('events_carusel', 'true')

            ->where('events_start_date','>=', $datebegin);
        $data = $data ->orderby('events_id','desc')
            ->take(8)
            ->get();
        return json_encode($data);
    }
    public function getEventlistall(Request $request){
        $currentPage = $request->get('currentPage');//??1
        $perPage = $request->get('perPage');
        $q = $request->get('q');
        $eventformat =$request->eventformat;
        $eventtype =$request->eventtype;
        $datebegin =$request->datebegin;
        $data = events:: select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")//DB::table('events')
            ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
        if ($eventformat)   $data = $data->where('events_format', $eventformat);
        if ($eventtype)   $data = $data->where('events_type', $eventtype);
        if ($datebegin)   $data = $data->where('events_start_date', $datebegin);
        if (!is_null($q)) $data =  $data->where(function ($query) use ($q) {
            $query->where('events_name', 'ILIKE', "%{$q}%")
                ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
        });
        if (isset(auth()->user()->spt_user_id)) {
            $user_id = auth()->user()->spt_user_id;
            $data = $data->addSelect([
                'registered' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                    ->whereColumn('events_users_event_id', 'events.events_id')
                    ->where('events_users.events_users_status', '=', 1)
                    ->Where('events_users.events_users_user_id', '=', $user_id)
                    ->where('deleted_at', NULL)
            ]);
        }
        $data = $data->addSelect([
            'reg_count' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                ->whereColumn('events_users_event_id', 'events.events_id')
                ->where('events_users.events_users_status', '=', 1)
                ->where('deleted_at', NULL)
        ]);
        $data = $data ->where('events_status', '=', 2);
        $data = $data ->orderby('events_id')->paginate($perPage,['*'],null,$currentPage);

        return json_encode($data);
    }
    public function getEventlistall_ext(Request $request){
        $currentPage = $request->get('currentPage');//??1
        $perPage = $request->get('perPage');
        $q = $request->get('q');
        $eventformat =$request->eventformat;
        $eventtype =$request->eventtype;
        $datebegin =$request->datebegin;

        $data_pre = events:: //select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")//DB::table('events')
        leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
        if ($eventformat)   $data_pre = $data_pre->where('events_format', $eventformat);
        if ($eventtype)   $data_pre = $data_pre->where('events_type', $eventtype);
        if ($datebegin)   $data_pre = $data_pre->where('events_start_date', $datebegin);
        if (!is_null($q)) $data_pre =  $data_pre->where(function ($query) use ($q) {
            $query->where('events_name', 'ILIKE', "%{$q}%")
                ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
        });
        $data_pre = $data_pre ->where('events_status', '=', 2)->get();
        $data_pre_count = $data_pre->count();
        if ($data_pre_count<1){
            $date_before = events::select("events.events_id")
                ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
                    ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
                    ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
                    ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
            if ($eventformat)   $date_before = $date_before->where('events_format', $eventformat);
            if ($eventtype)   $date_before = $date_before->where('events_type', $eventtype);
            if ($datebegin)   $date_before = $date_before->where('events_dt_start','<', (new Carbon($datebegin))->format('%Y%m%d'));//STR_TO_DATE($datebegin,'%Y%m%d'));
            if (!is_null($q)) $date_before =  $date_before->where(function ($query) use ($q) {
                $query->where('events_name', 'ILIKE', "%{$q}%")
                    ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                    ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
            });
            $date_before = $date_before ->where('events_status', '=', 2)->orderby('events_dt_start','desc') ->take(2)->get();
            $date_before_a = json_decode(json_encode($date_before));
            $date_before_count =  $date_before->count();
            if ($date_before_count>0){
                $idc = 0; $idr = '';
                foreach( $date_before  as $before) {
                    $idc =$idc +1;
                    $id = $before->events_id;
                    if($date_before_count==2 and $idc == 1){$id=$id.","; }
                    $idr=$idr.$id;
                }


            }
        }
        $data = events:: select("spr_ages.*", "spr_action_formats.*" ,"spr_action_types.*","events.*","spr_event_status.*")//DB::table('events')
        ->leftJoin('spr_event_status', 'events.events_status', '=', 'spr_event_status.spr_event_status_id')
            ->leftJoin('spr_ages', 'events.events_age', '=', 'spr_ages.spr_ages_id')
            ->leftJoin('spr_action_types', 'events.events_type', '=', 'spr_action_types.spr_action_types_id')
            ->leftJoin('spr_action_formats', 'events.events_format', '=', 'spr_action_formats.spr_action_formats_id');
        if ($eventformat)   $data = $data->where('events_format', $eventformat);
        if ($eventtype)   $data = $data->where('events_type', $eventtype);
        if ($data_pre_count>0){
            if ($datebegin)   $data = $data->where('events_dt_start','>=', (new Carbon($datebegin))->format('%Y%m%d'));
        } else {
            if ($date_before_count>0){
                $dArray = explode(",", $idr);
             //  if ($datebegin) $data = $data->where('events_start_date','>=', $datebegin);
                if ($datebegin) $data =  $data->where(function ($query) use (  $dArray , $datebegin) {
                    $query->whereIn('events_id',$dArray)
                        ->orWhere('events_dt_start','>=', (new Carbon($datebegin))->format('%Y%m%d'));
                });
               }
        }
        // if ($datebegin)   $data = $data->where('events_start_date', $datebegin);
        if (!is_null($q)) $data =  $data->where(function ($query) use ($q) {
            $query->where('events_name', 'ILIKE', "%{$q}%")
                ->orWhere('events_desc', 'ILIKE', "%{$q}%")
                ->orWhere('events_anons_short', 'ILIKE', "%{$q}%");
        });
        $data = $data->addSelect([
            'reg_count' => events_users::selectraw('Coalesce(COUNT(events_users_id),0)')
                ->whereColumn('events_users_event_id', 'events.events_id')
                ->where('events_users.events_users_status', '=', 1)
                ->where('deleted_at', NULL)
        ]);
        $data = $data ->where('events_status', '=', 2);
        $data = $data ->orderby('events_id')->paginate($perPage,['*'],null,$currentPage);

        return json_encode($data);
    }
    public function nullEvent(Request $request)
    {
        $event_id = $request->event_id;
        if (isset($event_id)) {

            $Useru = events::find($event_id);
            $Useru->events_status = 3;
            $Useru->update();
            $data['status'] = 'Мероприятие аннулировано';

        } Else {
            $data['status']='Запуск без параметра';
        }
        return json_encode($data);
    }
    public function publishEvent(Request $request)
    {
        $event_id = $request->event_id;
        if (isset($event_id)) {

            $Useru = events::find($event_id);
            $Useru->events_status = 2;
            $Useru->update();
            $data['status'] = 'Мероприятие опубликовано';

        } Else {
            $data['status']='Запуск без параметра';
        }
        return json_encode($data);
    }
    public function unpublishEvent(Request $request)
    {
        $event_id = $request->event_id;
        if (isset($event_id)) {

            $Useru = events::find($event_id);
            $Useru->events_status = 1;
            $Useru->update();
            $data['status'] = 'Мероприятие снято с публикации';

        } Else {
            $data['status']='Запуск без параметра';
        }
        return json_encode($data);
    }

    public function getEventsRegList(Request $request){
        $event_id = $request->event_id;
        if (isset($event_id)) {
            $data = events_users:: select("events_users.*", "spt_users.spt_user_id", "spt_users.email_verified_at", "spt_users.name", "spt_users.email")
                ->leftjoin('spt_users', 'events_users.events_users_user_id', 'spt_users.spt_user_id')
                ->where('events_users.events_users_status', '=', 1)
                ->Where('events_users.events_users_event_id', '=', $event_id)
                ->where('events_users.deleted_at', NULL)
                ->orderby('spt_users.name', 'asc')
                ->get();

        } else {
            $data['error'] = "Не передан параметр";
        }
        return json_encode($data);
    }

    public function getEventsPartList(Request $request){
        $event_id = $request->event_id;
        if (isset($event_id)) {
            $data = events:: select("events_id", "events_participants")
                ->Where('events_id', '=', $event_id)
                ->where('deleted_at', NULL)
                ->first();
            if (isset($data)) {
                $string = str_replace('"','',$data['events_participants']);
                $array = explode(",", $string);
                //$collect_1 = new Collection();
                $collection = new Collection();
                //$collect_1 = collect( $array);
                foreach($array as $item) {
                    $datae = participants:://find(intval($item))->first();
                     Where('participants_id', '=', $item)->first();

                    $collection->push((object)['id' => $item,
                        'name' => $datae['participants_name'],
                        'desc_1' => $datae['participants_desc_1'],
                        'desc_2' => $datae['participants_desc_2'],
                        'desc_3' => $datae['participants_desc_3'],
                        'photo' => $datae['participants_photo'],

                    ]);

                }
                //$data['test'] =$array;
                $dataw['list'] = $collection->toArray();
                $dataw['count'] = $collection->count();

            } else {
                $dataw['status'] = "Нет участников";
                $dataw['count'] = 0;
            }

        } else {
            $dataw['error'] = "Не передан параметр";
        }
        return json_encode($dataw);
    }
}
