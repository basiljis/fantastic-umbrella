<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Models\spr_event_status;
use App\Models\spt_users;
use App\Models\partners;
use App\Models\participants;
use Illuminate\Support\Facades\DB;
use App\DataTables\UsersDataTable;
use App\Models\spt_users_type;
use App\Models\User;
use App\Models\files;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    public function types(UsersDataTable $dataTable)
    {
        return $dataTable->render('users.types');
    }
    //
    public function index()
    {
//поставь как надо
        return view('content.users');
    }

    public function getUserTypes(Request $request)
    {

        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('spt_users_type')
        //->select('spt_users_type_name as name', 'spt_users_type_id as id', 'spt_users_type_status as status', 'spt_users_type_comment as comment', 'spt_users_type_posts as posts','spt_users_type_admin', 'spt_users_type_s1', 'spt_users_type_s2', 'spt_users_type_s3', 'spt_users_type_s4', 'spt_users_type_s5', 'spt_users_type_s6', 'spt_users_type_s7')
        ->select('spt_users_type_name', 'spt_users_type_id', 'spt_users_type_status','spt_spr_status_name as spt_users_type_status_txt', 'spt_users_type_comment', 'spt_users_type_posts','spt_users_type_admin', 'spt_users_type_s1', 'spt_users_type_s2', 'spt_users_type_s3', 'spt_users_type_s4', 'spt_users_type_s5', 'spt_users_type_s6', 'spt_users_type_s7', 'spt_users_type_s8', 'spt_users_type_s9', 'spt_users_type_s10', 'spt_users_type_s11')
        ->Join('spt_spr_status', 'spt_users_type.spt_users_type_status', '=', 'spt_spr_status.spt_spr_status_id')
        ->orderby('spt_users_type_id')->paginate($perPage,['*'],null,$currentPage);
         //->limit($perPage)->offset($currentPage*$perPage)->get();
               return json_encode($data);



      }
    public function storeUserTypes(Request $request)
    {
        $UserType = new spt_users_type;
        $UserType->spt_users_type_name = $request->input('spt_users_type_name');
        $UserType->spt_users_type_status = $request->input('spt_users_type_status');
        $UserType->spt_users_type_comment = $request->input('spt_users_type_comment');
        $UserType->spt_users_type_posts = $request->input('spt_users_type_posts');
        $UserType->spt_users_type_admin = $request->input('spt_users_type_admin');
        $UserType->spt_users_type_s1 = $request->input('spt_users_type_s1');
        $UserType->spt_users_type_s2 = $request->input('spt_users_type_s2');
        $UserType->spt_users_type_s3 = $request->input('spt_users_type_s3');
        $UserType->spt_users_type_s4 = $request->input('spt_users_type_s4');
        $UserType->spt_users_type_s5 = $request->input('spt_users_type_s5');
        $UserType->spt_users_type_s6 = $request->input('spt_users_type_s6');
        $UserType->spt_users_type_s7 = $request->input('spt_users_type_s7');
        $UserType->spt_users_type_s8 = $request->input('spt_users_type_s8');
        $UserType->spt_users_type_s9 = $request->input('spt_users_type_s9');
        $UserType->spt_users_type_s10 = $request->input('spt_users_type_s10');
        $UserType->spt_users_type_s11 = $request->input('spt_users_type_s11');
        $UserType->save();
        $data['status'] = 'Новый тип пользователя добавлен успешно';
        return json_encode($data);

    }
    public function UpdateUserTypes(Request $request)//, $id
    {
        $UserType = spt_users_type::find($request->input('spt_users_type_id'));
        $UserType->spt_users_type_name = $request->input('spt_users_type_name');
        $UserType->spt_users_type_status = $request->input('spt_users_type_status');
        $UserType->spt_users_type_comment = $request->input('spt_users_type_comment');
   //     $UserType->spt_users_type_posts = $request->input('spt_users_type_posts');
        $UserType->spt_users_type_admin = $request->input('spt_users_type_admin');
        $UserType->spt_users_type_s1 = $request->input('spt_users_type_s1');
        $UserType->spt_users_type_s2 = $request->input('spt_users_type_s2');
        $UserType->spt_users_type_s3 = $request->input('spt_users_type_s3');
      /*  $UserType->spt_users_type_s4 = $request->input('spt_users_type_s4');
        $UserType->spt_users_type_s5 = $request->input('spt_users_type_s5');
        $UserType->spt_users_type_s6 = $request->input('spt_users_type_s6');
        $UserType->spt_users_type_s7 = $request->input('spt_users_type_s7');
        $UserType->spt_users_type_s8 = $request->input('spt_users_type_s8');
        $UserType->spt_users_type_s9 = $request->input('spt_users_type_s9');
        $UserType->spt_users_type_s10 = $request->input('spt_users_type_s10');
        $UserType->spt_users_type_s11 = $request->input('spt_users_type_s11');*/
        $UserType->update();
        $data['status'] = 'Тип пользователя обновлен успешно';
        return json_encode($data);
    }

    public function EditUserTypes($id)
    {
        $UserType = spt_users_type::find($id);
        return view('UserType.edit', compact('UserType'));
    }

    public function DeleteUserTypes(Request $request)
    {
        $UserType = spt_users_type::find($request->input('spt_users_type_id'));
        $UserType->delete();
        $data['status'] = 'Тип пользователя удален успешно';
        return json_encode($data);
          }




    public function getUserList(Request $request)
    {

        $currentPage = $request->get('currentPage') ;
        $perPage = $request->get('perPage');

        $data = User::select('name', 'spt_user_id as id')
        //DB::table('users')
             ->orderby('name')
            ->get()->paginate($perPage,['*'],null,$currentPage);;
        return json_encode($data);
    }
    public function getUserPartner(Request $request)
    {

       /*  $data = User::select('name', 'spt_user_id as id')
            ->where('spt_users_partner','=','1')
             ->orderby('name')
            ->get();*/
        $data = partners::select('partners_name as name', 'partners_id as id')
            ->where('partners_status','=','1')
            ->orderby('partners_name')
            ->get();
        return json_encode($data);
    }
    public function getUserParticipant(Request $request)
    {

       /* $data = User::select('name', 'spt_user_id as id')
            ->where('spt_users_participant','=','1')
            ->orderby('name')
            ->get();*/
        $data = participants::select('participants_name as name', 'participants_id as id')
            ->where('participants_status','=','1')
            ->orderby('participants_name')
            ->get();
        return json_encode($data);
    }
    public function getSprParticipantsListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('participants')
            ->select('participants_name', 'participants_id','participants_status','participants_desc_1','participants_desc_2','participants_desc_3','participants_photo','spt_spr_status_name as participants_status_txt')
            ->leftJoin('spt_spr_status', 'participants.participants_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('participants_id')->paginate($perPage,['*'],null,$currentPage);
        //->get();
        return json_encode($data);
    }
    public function getSprPartnersListAdm(Request $request)
    {
        $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $data = DB::table('partners')
            ->select('partners_name', 'partners_id','partners_desc_1','partners_desc_2','partners_desc_3','partners_photo','partners_status','spt_spr_status_name as partners_status_txt')
            ->leftJoin('spt_spr_status', 'partners.partners_status', '=', 'spt_spr_status.spt_spr_status_id')
            ->orderby('partners_id')->paginate($perPage,['*'],null,$currentPage);
        //->get();
        return json_encode($data);
    }
    public function getUserListSel(Request $request)
    {

     //   $currentPage = $request->get('currentPage') ;
     //   $perPage = $request->get('perPage');

        $data = User::select('name', 'spt_user_id as id')
            //DB::table('users')
            ->orderby('name')
            ->get();
            //->paginate($perPage,['*'],null,$currentPage);;
        return json_encode($data);
    }
    public function getUserlistSpr(Request $request)
    {
   $t = 'spt_users';
   $ut = 'spt_users_type';
   $a = 'spt_spr_status';
   $a0 = 'st';
  // $a1 = 'partn';
  // $a2 = 'parti';
   $a3 = 'ut';

        $currentPage = $request->get('currentPage') ;
        $perPage = $request->get('perPage');
        $q= $request->get('q');
        $data = DB::table($t)
        ->leftjoin("$a as $a0", "$a0.spt_spr_status_id", '=', "$t.spt_users_status")
    //        ->leftjoin("$a as $a1", "$a1.spt_spr_status_id", '=', "$t.spt_users_partner")
    //        ->leftjoin("$a as $a2", "$a2.spt_spr_status_id", '=', "$t.spt_users_participant")
            ->leftjoin("$ut as $a3", "$t.spt_users_type", '=',"$a3.spt_users_type_id" )
            ->select("$t.name as name","$t.email as email","$t.spt_users_type as spt_users_type",
                "$t.spt_user_id as spt_user_id","$t.spt_user_comment as spt_user_comment",
                "$t.spt_user_mobile as spt_user_mobile","$t.spt_users_status as spt_users_status",
                "$a3.spt_users_type_name as spt_users_type_txt",
                "$a0.spt_spr_status_name as spt_users_status_txt",
      //          "$a2.spt_spr_status_short as spt_users_participant_txt", "$a1.spt_spr_status_short as spt_users_partner_txt",
                "$t.spt_users_participant as spt_users_participant",
                "$t.spt_users_partner as spt_users_partner",
                "$t.email_verified_at as email_verified_at");
                 if (!is_null($q)) $data =$data ->where("$t.name",'ILIKE',"%{$q}%");
           $data=$data ->orderby("$t.name")
            ->paginate($perPage,['*'],null,$currentPage);

        return json_encode($data);
    }

    public function UserUpdate(Request $request)
    {
        $Useru = spt_users::find($request->spt_user_id);
        $Useru->name = $request->name;
        $Useru->email = $request->email;
        $Useru->spt_users_type = $request->spt_users_type;
       // $Useru->spt_users_partner = $request->spt_users_partner;
       // $Useru->spt_users_participant = $request->spt_users_participant;
        $Useru->spt_user_mobile = $request->spt_user_mobile;
        $Useru->spt_users_status = $request->spt_users_status;
        $Useru->spt_user_comment = $request->spt_user_comment;

        $Useru->email_verified_at = $request->email_verified_at;

        $Useru->update();
        $data['status'] = 'Данные о пользователей обновлены успешно';
        return json_encode($data);
    }
    public function UserAdd(Request $request)
    {
        $datau = User::where('email','=',$request->email)
            ->first();
        if(is_null($datau)) {

            $Useru = new User;
            $Useru->name = $request->name;
            $Useru->email = $request->email;
            $Useru->spt_users_type = $request->spt_users_type;
            $Useru->password=bcrypt($request->password);
            $Useru->spt_user_mobile = $request->spt_user_mobile;
         //   $Useru->spt_users_partner = $request->spt_users_partner;
          //  $Useru->spt_users_participant = $request->spt_users_participant;
            $Useru->spt_users_status = $request->spt_users_status;
            $Useru->spt_user_comment = $request->spt_user_comment;
            $Useru->email_verified_at = $request->email_verified_at;
            $Useru->save();
            $data['status'] = 'Данные о пользователе сохранены успешно';
        } else {
            $data['status'] = 'Пользователь с таким E-mail существует';
        }
        return json_encode($data);
    }

    public function UserAdd2(Request $request)
    {
        $datau = User::where('email','=',$request->email)
            ->first();
        if(is_null($datau)) {

            $Useru = new User;
            $Useru->name = $request->name;
            $Useru->email = $request->email;
            $Useru->spt_users_type = $request->spt_users_type;
            $Useru->password=bcrypt($request->password);
            $Useru->spt_user_mobile = $request->spt_user_mobile;
         //   $Useru->spt_users_partner = $request->spt_users_partner;
         //   $Useru->spt_users_participant = $request->spt_users_participant;
            $Useru->spt_users_status = $request->spt_users_status;
            $Useru->spt_user_comment = $request->spt_user_comment;
            $Useru->save();
            $data['status'] = 'Данные о пользователе сохранены успешно';
        } else {
            $data['status'] = 'Пользователь с таким E-mail существует';
        }
        return json_encode($data);
    }
    public function getuserConfirmed(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $user_id = auth()->user()->spt_user_id;
//            $confirmed = auth()->user()->spt_user_email_confirm;
            $confirmed = auth()->user()->email_verified_at;
            if ($confirmed!=null){$confirmed1 = 1; } else {$confirmed1 = 0;}
            $data['confirmed'] = $confirmed1;
            $data['u_id'] = $user_id;
        }

        return json_encode($data);
    }
    public function getuserProfile(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $user_id = auth()->user()->spt_user_id;
            $name = auth()->user()->name;
            $icon = auth()->user()->spt_users_icon;
            $photo = auth()->user()->spt_users_photo;
            $phone = auth()->user()->spt_user_mobile;
            $email = auth()->user()-> email;
            //$confirmed = auth()->user()->spt_user_email_confirm;
            $confirmed = auth()->user()->email_verified_at;
            if ($confirmed!=null){$confirmed1 = 1; } else {$confirmed1 = 0;}
            $data['confirmed'] = $confirmed1;
            $data['name'] =$name;
            $data['icon'] =$icon;
            $data['spt_users_photo'] =$photo;
            $data['spt_user_mobile'] =$phone;
            $data['email'] =$email;
            $data['u_id'] = $user_id;
        }

        return json_encode($data);
    }
    public function updateuserProfile(Request $request)
    {

        if (!is_null(auth()->user()->spt_user_id)) {
            $user_id =  auth()->user()->spt_user_id;
            $Useru = spt_users::find( $user_id);
            $Useru->name = $request->name;
           // $Useru->email = $request->email;
            $Useru->spt_user_mobile = $request->spt_user_mobile;
            $Useru->spt_users_icon = $request->spt_users_icon;

            
            
            if ($path = $request->file('avatar')?->store('avatar','public'))
            $Useru->spt_users_photo = $path;
           //   $Useru->spt_user_comment = $request->spt_user_comment;
            $Useru->update();

            $data['status'] = 'Данные успешно обновлены';
        } else {
            $data['status'] = 'Ошибка - не авторизован';
        }
        return json_encode($data);
    }
    public function updateparticipants(Request $request)//, $id
    {
        $UserType = participants::find($request->input('participants_id'));
        $UserType->participants_name = $request->input('participants_name');
        $UserType->participants_status = $request->input('participants_status');
        //$path='';
     //   if ($path = $request->file('participants_photo_load')?->store('files','public'))
      //              $UserType->participants_photo = $path;
        //$UserType->participants_photo = $request->input('participants_photo');

        //$path = $request->file('participants_photo_load')->store('files','public');
        $path = $request->file('participants_photo_load')?->store('files','public');
               if (isset($path)) {
            $UserType->participants_photo = $path;//$request->partners_photo_load;
                        //$data['status2'] = $path1;
        }

        $UserType->participants_desc_1 = $request->input('participants_desc_1');
        $UserType->participants_desc_2 = $request->input('participants_desc_2');
        $UserType->participants_desc_3 = $request->input('participants_desc_3');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';

        return json_encode($data);
    }
    public function updatepartners(Request $request)//, $id
    {
        $UserType = partners::find($request->input('partners_id'));
        $UserType->partner_name = $request->input('partners_name');
        $UserType->partners_status = $request->input('partners_status');

        //if ($path = $request->file('partners_photo_load')?->store('files','public'))
        $path = $request->file('partners_photo_load')?->store('files','public');
        if (isset($path)) {
            $UserType->partners_photo = $path;//$request->partners_photo_load;
        }
       // $UserType->partners_photo = $request->input('partners_photo');
        $UserType->partners_desc_1 = $request->input('partners_desc_1');
        $UserType->partners_desc_2 = $request->input('partners_desc_2');
        $UserType->partners_desc_3 = $request->input('partners_desc_3');
        $UserType->update();
        $data['status'] = 'Запись обновлена успешно';
        return json_encode($data);
    }
    public function SprpartnersAdd(Request $request)
    {

        $Useru = new partners;
        if(!$request->partners_status) $st=2; else  $st=$request->partners_status;
        $Useru->partners_name = $request->partners_name;
        $path = $request->file('partners_photo_load')?->store('files','public');
        if (isset($path)) {
            $Useru->partners_photo = $path;//$request->partners_photo_load;
        }
        // $Useru->partners_photo = $request->partners_photo_load;
        $Useru->partners_desc_1 = $request->partners_desc_1;
        $Useru->partners_desc_2 = $request->partners_desc_2;
        $Useru->partners_desc_3 = $request->partners_desc_3;
        $Useru->partners_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }
    public function SprparticipantsAdd(Request $request)
    {

        $Useru = new participants;
        if(!$request->participants_status) $st=2; else  $st=$request->participants_status;
        $Useru->participants_name = $request->participants_name;
      //  $Useru->participants_photo = $request->participants_photo_load;
        $path = $request->file('participants_photo_load')?->store('files','public');
        if (isset($path)) {
            $Useru->participants_photo = $path;//$request->partners_photo_load;
        }
        $Useru->participants_desc_1 = $request->participants_desc_1;
        $Useru->participants_desc_2 = $request->participants_desc_2;
        $Useru->participants_desc_3 = $request->participants_desc_3;
        $Useru->participants_status = $st;
        $Useru->save();
        $data['status'] = 'Данные сохранены успешно';

        return json_encode($data);
    }
}
