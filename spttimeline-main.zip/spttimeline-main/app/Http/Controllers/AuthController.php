<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\spt_login;
use Validator;
use Illuminate\Support\Facades\Mail;

use Illuminate\Auth\Events\Registered;

use Illuminate\Contracts\Events\Dispatcher;


class AuthController extends Controller
{

    private $dispatcher;


    public function __construct(Dispatcher $dispatcher)
    {
        $this->dispatcher = $dispatcher;
    }



    /**
     * Create user
     *
     * @param  [string] name
     * @param  [string] email
     * @param  [string] password
     * @param  [string] password_confirmation
     * @return [string] message
     */
    public function register(Request $request)
    {

        $request->validate([
            'name' => 'required|string',
            'email' => 'required|string|unique:spt_users',
            'password' => 'required|string',
            // 'c_password' => 'required|same:password'
        ]);

        $user_salt = mt_rand(100, 999);

        $user = new User([
            'name'  => $request->name,
            'spt_user_login' => strtolower($request->email),
            'spt_user_email' => strtolower($request->email),
            'spt_user_email_confirm' => 0,
            'email' => strtolower($request->email),
            'password' => bcrypt($request->password),
            'spt_user_passwd' => bcrypt($request->password),
            'spt_user_salt' => $user_salt,
        ]);



        if ($user->save()) {
            

            $this->dispatcher->dispatch(new Registered($user));



            /*  $email_data = array(
                'name' => $request->name,
                'email' => $request->email,
            );
    
    
            Mail::send('welcome_email', $email_data, function ($message) use ($email_data) {
                $message->to($email_data['email'], $email_data['name'])
                    ->subject('Welcome to MyNotePaper')
                    ->from('info@mynotepaper.com', 'MyNotePaper');
            });
*/




            $tokenResult = $user->createToken('Personal Access Token');
            $token = $tokenResult->plainTextToken;

           return  $this->login($request,'Регистрация пройдена. Вам на почту отправлена ссылка для подтверждения.','registered');
            /*return response()->json([
                'message' => 'Регистрация пройдена. Вам на почту отправлена ссылка для подтверждения.',
                'accessToken' => $token,
                'status' => 'registered',
            ], 201);*/
        } else {
            return response()->json(['error' => 'Provide proper details']);
        }
    }

    /**
     * Login user and create token
     *
     * @param  [string] email
     * @param  [string] password
     * @param  [boolean] remember_me
     */


    public function login(Request $request, $message="", $status='')
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            'remember_me' => 'boolean'
        ]);
        $user_salt = 0;
        $reu = 0;
        $user_id = 0;
        $usersalt = User::where('email', strtolower(request('email')))
            ->first();
        if ($usersalt) {
            $user_salt = $usersalt->spt_user_salt;
            $user_block = $usersalt->spt_user_block;
            $user_status = $usersalt->spt_users_status;
            $user_id = $usersalt->spt_user_id;


            if ($user_block == '1' or $user_status == '2') {
                return response()->json([
                    'message' => 'Unauthorized',
                    'errors' => [
                        'email' => 'Пользователь заблокирован ',
                        'password' => 'Обратитесь в службу поддержки'
                    ],
                ], 401);
            }
        }
        //$credentials = request(['email', 'password']);
        $credentials['email'] = strtolower(request('email'));
        $credentials['password'] = request('password');

        if (!Auth::attempt($credentials)) {
            $attlog = new spt_login;
            $attlog->login_log =  $credentials['email']; //request('email')
            $attlog->passwd_log =  $credentials['password'];
            $attlog->user_name =  "Ошибка";
            $attlog->id_user_log = $user_id;
            $attlog->IP_adr = request()->ip();
            $attlog->time_login = date('Y-m-d H:i:s');
            $attlog->save();
            return response()->json([
                'message' => 'Unauthorized',
                'errors' => [
                    'email' => 'Проверьте почтовый адрес ', //.$oldpass. ' user_salt = '.$user_salt. ' reu = '.$reu
                    'password' => 'Проверьте пароль'
                ],
            ], 401);
        }


        $user = $request->user();
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->plainTextToken;

        $usertype = User::where('email', strtolower(request('email')))
            //$usertype= User::where('email',request('email'))
            ->LEFTJOIN('spt_users_type', 'spt_users.spt_users_type', '=', 'spt_users_type.spt_users_type_id')

            ->select('spt_users_type_admin as admin', 'spt_users_type_s1 as s1', 'spt_users_type_s2 as s2', 'spt_users_type_s3 as s3', 
            'spt_users_type_s4 as s4', 'spt_users_type_s5 as s5', 'spt_users_type_s6 as s6', 'spt_users_type_s7 as s7',
             'spt_users_type_s8 as s8', 'spt_users_type_s9 as s9', 'spt_users_type_s10 as s10', 'spt_users_type_s11 as s11', 
             'spt_users_type_id as a_id', 'spt_users_type_name as a_type', 'name' ,'spt_users_photo as avatar')
            ->first();
        $attlog = new spt_login;
        $attlog->login_log =  $credentials['email']; //request('email')
        $attlog->passwd_log =  "correct"; //$credentials['password'] ;
        $attlog->user_name =  $usertype->name;
        $attlog->block_log = $user_block;
        $attlog->id_user_log = $user_id;
        $attlog->time_login = date('Y-m-d H:i:s');
        $attlog->IP_adr = request()->ip();
        $attlog->save();
        return response()->json([
            'accessToken' => $token,
            'message' => $message,
            'status' => $status,
            'token_type' => 'Bearer',
            'access_array' => $usertype,
        ]);
    }


    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function user(Request $request)
    {
        return response()->json($request->user());
    }


    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }
}
