<?php

namespace App\Http\Controllers;

use App\Models\events;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App;
use App\Models\files;
//use App\files;

class FileController extends Controller
{
    private $image_ext = ['jpg', 'jpeg', 'png', 'gif', 'tiff', 'tif'];
    private $audio_ext = ['mp3', 'ogg', 'mpga'];
    private $video_ext = ['mp4', 'mpeg'];
    private $document_ext = ['doc', 'docx', 'pdf', 'odt', 'xlsx', 'xls'];

    private function allExtensions()
    {
        return array_merge($this->image_ext, $this->audio_ext, $this->video_ext, $this->document_ext);
    }

    private function getType($ext)
    {
        $type = 'any';
        if (in_array($ext, $this->image_ext)) {
            $type = 'image';//return 'image';
        }

        if (in_array($ext, $this->audio_ext)) {
            $type = 'audio';//return 'audio';
        }

        if (in_array($ext, $this->video_ext)) {
            $type = 'video';//return 'video';
        }

        if (in_array($ext, $this->document_ext)) {
            $type = 'document';//return 'document';
        }
        return $type;
    }

    /*  public function __construct()
      {
          $this->middleware('auth');
      }
  */
    public function storeEventFile(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $event_id = $request->event_id;
            $uid = auth()->user()->spt_user_id;
             $ft = date('dMYHis');
            $max_size = (int)ini_get('upload_max_filesize') * 1000;
            $all_ext = implode(',', $this->allExtensions());

            $file = $request->file('0');
            $ext = $file->getClientOriginalExtension();
            $type = $this->getType($ext);

            if (!is_null($file)) {

                $Event_file = files::where('files_event_id', '=', $event_id)->where('files_status', '=', '1')->first();
                if (!is_null($Event_file)) {
                    // обнуляем запись
                    $Event_file->files_status = '2';
                    $Event_file->files_editor = $uid;
                    $Event_file->update();
                    $data['action'] = 'файл аннулирован';
                }


                if (Storage::putFileAs('/public/files/' . $type . '/', $file, 'file' . $ft . '.' . $ext)) {

                    $adr = '/storage/files/' . $type . '/file' . $ft . '.' . $ext;

                   $NEWFILE = new files;

                   $NEWFILE->files_event_id = $event_id;
                   $NEWFILE->files_status = '1';
                   $NEWFILE->files_adr = $adr;
                   $NEWFILE->files_creator = $uid;
                   $NEWFILE->save();
                    $data['ok'] = 'файл сохранен';

                }
            } else {

                $data['ERROR'] = 'файл не передан';
            }

            return json_encode($data);
        }
    }
    public function deleteEventFile(Request $request)
    {
        $data['status'] = 0;
        $event_id = $request->event_id;
        if (isset($event_id)) {
            if (!is_null(auth()->user()->spt_user_id)) {
                if ($request->fileadr and $request->filetype) {
                    Storage::delete($request->fileadr);
                    $event = events::find($event_id);
                    $fpre_array = [];
                    $f_array = [];
                    $fpre_array = json_decode($event->events_files, true);
                    if ($request->filetype == 'wallpaper') {

                        $f_array['wallpaper'] = "";
                    } else {
                        $f_array['wallpaper'] = $fpre_array['wallpaper'];
                    }
                    if ($request->filetype == 'cropped') {
                        $f_array['cropped'] = "";
                    } else {
                        $f_array['cropped'] = $fpre_array['cropped'];
                    }
                    if ($request->filetype == 'files') {
                        unset($fpre_array['files'][array_search($request->fileadr, $fpre_array['files'])]);
                        $f_array['files'] = $fpre_array['files'];
                    } else {
                        $f_array['files'] = $fpre_array['files'];
                    }
                    if (isset($f_array)) $event->events_files = json_encode($f_array);
                    $event->update();


                    $data['status'] = 'Удаление успешно';
                } else {

                    $data['ERROR'] = 'Не указан файл для удаления либо тип файла';
                }

            } else {

                $data['ERROR'] = 'Не авторизован';
            }
        }else {

            $data['ERROR'] = 'Не указан EVENT_ID';
        }
        // $data['data'] =  $request;
        return json_encode($data);
    }
    public function getEventFile(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $event_id = $request->event_id;

            if (!is_null($event_id) ) {
                $event =  events::find($event_id);
                if (isset($event->events_files)) {
                    $data['files'] = json_decode($event->events_files);
                } else {
                    $data['no_files'] = '1';
                }
        } else {

            $data['ERROR'] = 'не переданы данные';
        }
    } else {

$data['ERROR'] = 'Требуется авторизация';
}

return json_encode($data);
        }
    public function getEventFile_bk(Request $request)
    {
        if (!is_null(auth()->user()->spt_user_id)) {
            $event_id = $request->event_id;
            $retj = '';
            if (!is_null($event_id) ) {
                $Check_file = files::where('files_event_id', '=', $event_id)->where('files_status', '=', '1')->first();
                if (!is_null($Check_file)) {
                    //SHOW
                    $retj = $Check_file->files_adr;
                    $loaded = 1;
                } else {
                    $retj = '';
                    $loaded = 0;
                    $data['ERROR'] = 'файл не загружен';
                }
                $data['loaded'] = $loaded;
                $data['file_link'] = $retj;
            } else {

                $data['ERROR'] = 'не переданы данные';
            }
        } else {

            $data['ERROR'] = 'Требуется авторизация';
        }

        return json_encode($data);
    }
}
