<?php

namespace App\Http\Controllers;



use App\Models\spt_users_type;
use App\Models\spt_spr_status;
use App\Models\spr_event_status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SoapClient;

class BtnController extends Controller
{


    public function getSprSexList(Request $request)
    {
        $data = DB::table('spt_spr_sex')
            ->select('spt_spr_sex_name as name', 'spt_spr_sex_id as id')
            ->orderby('spt_spr_sex_id')
            ->get();
        return json_encode($data);
    }
    public function getSprEventStatusList(Request $request)
    {
        $data = DB::table('spr_event_status')
            ->select('spr_event_status_name as name', 'spr_event_status_id as id')
            ->orderby('spr_event_status_id')
            ->get();
        return json_encode($data);
    }
    public function getSpruTypeList(Request $request)
    {
        $data = spt_users_type::select('spt_users_type_name as name', 'spt_users_type_id as id')
            ->orderby('spt_users_type_id')
            ->where('spt_users_type_status', '=', '1')
            ->where('deleted_at', '=', null)
            ->get();
        return json_encode($data);
    }
    public function getSprStatusList(Request $request)
    {
        $data = DB::table('spt_spr_status')
            ->select('spt_spr_status_name as name', 'spt_spr_status_id as id')
            ->orderby('spt_spr_status_id')
            ->get();
        return json_encode($data);
    }
    public function getSprStatusList2(Request $request)
    {
        $data = DB::table('spt_spr_status')
            ->select('spt_spr_status_short as name', 'spt_spr_status_id as id')
           ->where('spt_spr_status_status',1)
            ->orderby('spt_spr_status_id')
            ->get();
        return json_encode($data);
    }
    public function getSprAccStatusList(Request $request)
    {
        $data = DB::table('spt_spr_access_status')
            ->select('spt_spr_access_status_name as name', 'spt_spr_access_status_id as id')
            ->orderby('spt_spr_access_status_id')
            ->get();
        return json_encode($data);
    }
    public function getSprAccessList(Request $request)
    {
        $data = DB::table('spt_spr_access_type')
            ->select('spt_spr_access_type_name as name', 'spt_spr_access_type_id as id')
            ->orderby('spt_spr_access_type_id')
            ->get();
        return json_encode($data);
    }
   
    public function getBTN_table(Request $request)
    {
        //         //название иконка урл метод список параметров
        if (!is_null($request->page_name)) {

            if ($request->page_name == 'UserType') {
                /*
                 * action list
                 */
                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/usertypes/update'; ///{'.$request->spt_users_type_id.'}';
                $buttons[0]['form_definition'] = "[
{title: 'Уровень доступа', field: 'spt_users_type_name', type: 'text',limit: 100, order: 1},
{title: 'Комментарий', field: 'spt_users_type_comment', type: 'text',limit: 100,order: 3},
{title: 'Статус', field: 'spt_users_type_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'СуперАдмин', field: 'spt_users_type_admin', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 4},
{title: 'Мероприятия (S1)', field: 'spt_users_type_s1', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 5},
{title: 'Мой календарь (S2)', field: 'spt_users_type_s2', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 6},
{title: 'Пользователи (S3)', field: 'spt_users_type_s3', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 7},


]";
                $buttons[0]['method'] = 'post';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spt_users_type_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/usertypes/usertype'; /*/../apps/spr_test*/
                $buttons[1]['form_definition'] = "[
{title: 'Уровень доступа', field: 'spt_users_type_name', type: 'text',limit: 100, order: 1},
{title: 'Комментарий', field: 'spt_users_type_comment', type: 'text',limit: 100,order: 3},
{title: 'Статус', field: 'spt_users_type_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'СуперАдмин', field: 'spt_users_type_admin', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 4},
{title: 'Мероприятия (S1)', field: 'spt_users_type_s1', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 5},
{title: 'Мой календарь (S2)', field: 'spt_users_type_s2', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 6},
{title: 'Пользователи (S3)', field: 'spt_users_type_s3', type: 'select', url:'/apps/spr_access/list',limit: 0,order: 7},

]";
                $buttons[1]['method'] = 'post';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';

                $buttons[2]['name'] = 'Удалить';
                $buttons[2]['icon'] = 'ph:trash';
                $buttons[2]['url'] = '/apps/usertypes/delete';
                $buttons[2]['method'] = 'post';
                $buttons[2]['position'] = 'row';
                $buttons[2]['parametrs'] = 'spt_users_type_id';
                $buttons[2]['variant'] = 'outlined';
                $buttons[2]['color'] = 'error';
            }
           
           


            if ($request->page_name == 'Spr_action_types_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/spractiontypes/update';
                // type: 'select', url:'/apps/userss/list',limit: 0,order: 1},
                $buttons[0]['form_definition'] = "[
{title: 'Тип мероприятия', field: 'spr_action_types_name',type: 'text',limit: 255,order: 1}, 
{title: 'Цвет', field: 'spr_action_types_color',type: 'text',limit: 100,order: 2}, 

{title: 'Статус', field: 'spr_action_types_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},
]";

                $buttons[0]['method'] = 'post';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spr_action_types_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/spractiontypes/add';
                $buttons[1]['form_definition'] = "[
  {title: 'Тип мероприятия', field: 'spr_action_types_name',type: 'text',limit: 255,order: 1}, 
  {title: 'Цвет', field: 'spr_action_types_color',type: 'text',limit: 100,order: 2}, 
 {title: 'Иконка', field: 'spr_action_types_icon',type: 'text',limit: 100,order: 3}, 
{title: 'Статус', field: 'spr_action_types_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 4},
]";
                $buttons[1]['method'] = 'post';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }

            if ($request->page_name == 'Spr_action_formats_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/spractionformats/update';
                $buttons[0]['form_definition'] = "[
{title: 'Формат мероприятия', field: 'spr_action_formats_name',type: 'text',limit: 255,order: 1}, 
{title: 'Иконка', field: 'spr_action_formats_icon',type: 'text',limit: 100,order: 2}, 
{title: 'Статус', field: 'spr_action_formats_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spr_action_formats_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/spractionformats/add';
                $buttons[1]['form_definition'] = "[
  {title: 'Формат мероприятия', field: 'spr_action_formats_name',type: 'text',limit: 255,order: 1}, 
  {title: 'Иконка', field: 'spr_action_formats_icon',type: 'text',limit: 100,order: 2}, 
  {title: 'Статус', field: 'spr_action_formats_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }

            if ($request->page_name == 'Spr_ages_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/sprages/update';
                $buttons[0]['form_definition'] = "[
{title: 'Возрастной промежуток', field: 'spr_ages_name',type: 'text',limit: 255,order: 1}, 
{title: 'Иконка', field: 'spr_ages_icon',type: 'text',limit: 100,order: 2}, 
{title: 'Статус', field: 'spr_ages_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spr_ages_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/sprages/add';
                $buttons[1]['form_definition'] = "[
  {title: 'Возрастной промежуток', field: 'spr_ages_name',type: 'text',limit: 255,order: 1}, 
 {title: 'Иконка', field: 'spr_ages_icon',type: 'text',limit: 100,order: 2}, 
  {title: 'Статус', field: 'spr_ages_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }
            if ($request->page_name == 'Spr_event_status_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/spreventstatus/update';
                $buttons[0]['form_definition'] = "[
{title: 'Название статуса', field: 'spr_event_status_name',type: 'text',limit: 255,order: 1}, 
{title: 'Иконка', field: 'spr_event_status_icon',type: 'text',limit: 100,order: 2}, 
 {title: 'Статус', field: 'spr_event_status_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spr_event_status_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/spreventstatus/add';
                $buttons[1]['form_definition'] = "[
  {title: 'Название статуса', field: 'spr_event_status_name',type: 'text',limit: 255,order: 1}, 
 {title: 'Иконка', field: 'spr_event_status_icon',type: 'text',limit: 100,order: 2}, 
  {title: 'Статус', field: 'spr_event_status_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 3},

]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }
            if ($request->page_name == 'Spr_partners_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/sprpartners/update';
                $buttons[0]['form_definition'] = "[
{title: 'ФИО', field: 'partners_name',type: 'text',limit: 255,order: 1}, 
{title: 'Статус', field: 'partners_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'Описание 1', field: 'partners_desc_1',type: 'text',limit: 255,order: 3}, 
{title: 'Описание 2', field: 'partners_desc_2',type: 'text',limit: 255,order: 4}, 
{title: 'Описание 3', field: 'partners_desc_3',type: 'text',limit: 255,order: 5}, 
{title: 'Фото', field: 'partners_photo',type: 'img',limit: 500,order: 6}, 
{title: 'Загрузить Фото', field: 'partners_photo_load',type: 'file',limit: 500,order: 7},  

]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'partners_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/sprpartners/add';
                $buttons[1]['form_definition'] = "[
  {title: 'ФИО', field: 'partners_name',type: 'text',limit: 255,order: 1}, 
  {title: 'Статус', field: 'partners_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'Описание 1', field: 'partners_desc_1',type: 'text',limit: 255,order: 3}, 
{title: 'Описание 2', field: 'partners_desc_2',type: 'text',limit: 255,order: 4}, 
{title: 'Описание 3', field: 'partners_desc_3',type: 'text',limit: 255,order: 5}, 
{title: 'Фото', field: 'partners_photo',type: 'img',limit: 500,order: 6}, 
{title: 'Загрузить фото', field: 'partners_photo_load',type: 'file',limit: 500,order: 7},  

]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }
            if ($request->page_name == 'Spr_participants_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/sprparticipants/update';
                $buttons[0]['form_definition'] = "[
{title: 'ФИО', field: 'participants_name',type: 'text',limit: 255,order: 1}, 
{title: 'Статус', field: 'participants_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'Описание 1', field: 'participants_desc_1',type: 'text',limit: 255,order: 3}, 
{title: 'Описание 2', field: 'participants_desc_2',type: 'text',limit: 255,order: 4}, 
{title: 'Описание 3', field: 'participants_desc_3',type: 'text',limit: 255,order: 5}, 
{title: 'Фото', field: 'participants_photo',type: 'img',limit: 500,order: 6}, 
{title: 'Загрузить Фото', field: 'participants_photo_load',type: 'file',limit: 500,order: 7},  

]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'participants_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/sprparticipants/add';
                $buttons[1]['form_definition'] = "[
  {title: 'ФИО', field: 'participants_name',type: 'text',limit: 255,order: 1}, 
  {title: 'Статус', field: 'participants_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 2},
{title: 'Описание 1', field: 'participants_desc_1',type: 'text',limit: 255,order: 3}, 
{title: 'Описание 2', field: 'participants_desc_2',type: 'text',limit: 255,order: 4}, 
{title: 'Описание 3', field: 'participants_desc_3',type: 'text',limit: 255,order: 5}, 
{title: 'Фото', field: 'participants_photo',type: 'img',limit: 500,order: 6},
{title: 'Загрузить фото', field: 'participants_photo_load',type: 'file',limit: 500,order: 7},  

]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }
            if ($request->page_name == 'SprUsers_list') {

                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/users/update';
                // type: 'select', url:'/apps/userss/list',limit: 0,order: 1},
                $buttons[0]['form_definition'] = "[
{title: 'ФИО', field: 'name',type: 'text',limit: 255,order: 1}, 
{title: 'E-mail', field: 'email',type: 'text',limit: 255,order: 2},
{title: 'Тип пользователя', field: 'spt_users_type', type: 'select', url:'/apps/spr_utype/list',limit: 0,order: 3},
{title: 'Телефон', field: 'spt_user_mobile', type: 'text',limit: 100,order: 4},
{title: 'Статус', field: 'spt_users_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 5},
{title: 'Комментарий', field: 'spt_user_comment',type: 'text',limit: 1000,order: 6},
{title: 'Дата подтверждения почты', field: 'email_verified_at',type: 'date',limit: 100,order: 7},
]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'spt_user_id';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';


                $buttons[1]['name'] = 'Добавить';
                $buttons[1]['icon'] = 'ic:sharp-plus';
                $buttons[1]['url'] = '/apps/users/adduser2';
                $buttons[1]['form_definition'] = "[
  {title: 'ФИО', field: 'name',type: 'text',limit: 255,order: 1}, 
{title: 'E-mail', field: 'email',type: 'text',limit: 255,order: 2},
{title: 'Пароль', field: 'password',type: 'text',limit: 255,order: 3},
{title: 'Тип пользователя', field: 'spt_users_type', type: 'select', url:'/apps/spr_utype/list',limit: 0,order: 4},
{title: 'Телефон', field: 'spt_user_mobile', type: 'text',limit: 100,order: 5},
{title: 'Статус', field: 'spt_users_status', type: 'select', url:'/apps/spr_status/list',limit: 0,order: 6},
{title: 'Комментарий', field: 'spt_user_comment',type: 'text',limit: 1000,order: 7},
{title: 'Дата подтверждения почты', field: 'email_verified_at',type: 'date',limit: 100,order:8},
]";
                $buttons[1]['method'] = 'POST';
                $buttons[1]['position'] = 'top';
                $buttons[1]['parametrs'] = '';
                $buttons[1]['variant'] = 'flat';
                $buttons[1]['color'] = 'primary';
            }

            if ($request->page_name == 'SprLogs') {
                $buttons = [];
            }
            if ($request->page_name == 'SprLogsMail') {
                $buttons = [];
            }
/*
                $buttons[0]['name'] = 'Редактировать';
                $buttons[0]['icon'] = 'clarity:edit-line';
                $buttons[0]['url'] = '/apps/spr_log/update';
                $buttons[0]['form_definition'] = "[
{title: 'ID', field: 'id_login', type: 'text',limit: 255, order: 1},
{title: 'Название', field: 'user_name', type: 'text',limit: 255, order: 2},
]";
                $buttons[0]['method'] = 'POST';
                $buttons[0]['position'] = 'row';
                $buttons[0]['parametrs'] = 'id_login';
                $buttons[0]['variant'] = 'outlined';
                $buttons[0]['color'] = 'success';
            }
            */
            return json_encode($buttons);
        }
    }




    public function getGuideCols(Request $request)
    {
        //         //название иконка урл метод список параметров
        if (!is_null($request->page_name)) {

            if ($request->page_name == 'UserType') {

                $col[0]['name'] = 'Уровень доступа';
                $col[0]['field'] = 'spt_users_type_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Статус';
                $col[1]['field'] = 'spt_users_type_status_txt';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Комментарий';
                $col[2]['field'] = 'spt_users_type_comment';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'Суперадминистратор';
                $col[3]['field'] = 'spt_users_type_admin';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'Мероприятия (S1)';
                $col[4]['field'] = 'spt_users_type_s1';
                $col[4]['order'] = '5';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'Мой календарь (S2)';
                $col[5]['field'] = 'spt_users_type_s2';
                $col[5]['order'] = '6';
                $col[5]['textclass'] = ' text-base';

                $col[6]['name'] = 'Пользователи (S3)';
                $col[6]['field'] = 'spt_users_type_s3';
                $col[6]['order'] = '7';
                $col[6]['textclass'] = ' text-base';


            }


          

 

            if ($request->page_name == 'SprUsers_list') {
                $col[0]['name'] = 'ID';
                $col[0]['field'] = 'spt_user_id';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Пользователь';
                $col[1]['field'] = 'name';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'email';
                $col[2]['field'] = 'email';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'Тип пользователя';
                $col[3]['field'] = 'spt_users_type_txt';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'Статус';
                $col[4]['field'] = 'spt_users_status_txt';
                $col[4]['order'] = '7';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'Телефон';
                $col[5]['field'] = 'spt_user_mobile';
                $col[5]['order'] = '8';
                $col[5]['textclass'] = ' text-base';

                $col[6]['name'] = 'Дата подтверждения почты';
                $col[6]['field'] = 'email_verified_at';
                $col[6]['order'] = '9';
                $col[6]['textclass'] = ' text-base';


            }
            if ($request->page_name == 'SprLogs') {
                $col[0]['name'] = 'ID';
                $col[0]['field'] = 'id_login';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Пользователь';
                $col[1]['field'] = 'user_name';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Логин';
                $col[2]['field'] = 'login_log';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'IP';
                $col[3]['field'] = 'IP_adr';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'Пароль';
                $col[4]['field'] = 'passwd_log';
                $col[4]['order'] = '5';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'Дата входа';
                $col[5]['field'] = 'time_login';
                $col[5]['order'] = '6';
                $col[5]['textclass'] = ' text-base';

                $col[6]['name'] = 'Блокировка';
                $col[6]['field'] = 'block_log';
                $col[6]['order'] = '7';
                $col[6]['textclass'] = ' text-base';

                $col[7]['name'] = 'USER_ID';
                $col[7]['field'] = 'id_user_log';
                $col[7]['order'] = '8';
                $col[7]['textclass'] = ' text-base';

           }
            if ($request->page_name == 'SprLogsMail') {
                $col[0]['name'] = 'ID';
                $col[0]['field'] = 'id';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Пользователь';
                $col[1]['field'] = 'user_name';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Логин';
                $col[2]['field'] = 'user_email';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'IP';
                $col[3]['field'] = 'IP_adr';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'id_user';
                $col[4]['field'] = 'id_user';
                $col[4]['order'] = '5';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'Дата входа';
                $col[5]['field'] = 'created_at';
                $col[5]['order'] = '6';
                $col[5]['textclass'] = ' text-base';

                $col[6]['name'] = 'Результат';
                $col[6]['field'] = 'rez';
                $col[6]['order'] = '7';
                $col[6]['textclass'] = ' text-base';

                $col[7]['name'] = 'USER_ID_initiator';
                $col[7]['field'] = 'id_user_initiator';
                $col[7]['order'] = '8';
                $col[7]['textclass'] = ' text-base';

                $col[8]['name'] = 'Тема';
                $col[8]['field'] = 'theme';
                $col[8]['order'] = '9';
                $col[8]['textclass'] = ' text-base';

            }

            if ($request->page_name == 'Spr_action_types_list') {

                $col[0]['name'] = 'Тип мероприятия';
                $col[0]['field'] = 'spr_action_types_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Цвет';
                $col[1]['field'] = 'spr_action_types_color';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';


                $col[2]['name'] = 'Статус';
                $col[2]['field'] = 'spr_action_types_status_txt';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

            }
            if ($request->page_name == 'Spr_action_formats_list') {

                $col[0]['name'] = 'Форма мероприятия';
                $col[0]['field'] = 'spr_action_formats_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Статус';
                $col[1]['field'] = 'spr_action_formats_status_txt';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Иконка';
                $col[2]['field'] = 'spr_action_formats_icon';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

            }
            if ($request->page_name == 'Spr_ages_list') {

                $col[0]['name'] = 'Возрастной промежуток';
                $col[0]['field'] = 'spr_ages_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Иконка';
                $col[1]['field'] = 'spr_ages_icon';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Статус';
                $col[2]['field'] = 'spr_ages_status_txt';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

            }
            if ($request->page_name == 'Spr_event_status_list') {

                $col[0]['name'] = 'Название статуса';
                $col[0]['field'] = 'spr_event_status_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Статус';
                $col[1]['field'] = 'spr_event_status_txt';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Иконка';
                $col[2]['field'] = 'spr_event_status_icon';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

            }
            if ($request->page_name == 'Spr_participants_list') {

                $col[0]['name'] = 'ФИО';
                $col[0]['field'] = 'participants_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Статус';
                $col[1]['field'] = 'participants_status_txt';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Описание 1';
                $col[2]['field'] = 'participants_desc_1';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'Описание 2';
                $col[3]['field'] = 'participants_desc_2';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'Описание 3';
                $col[4]['field'] = 'participants_desc_3';
                $col[4]['order'] = '5';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'ФОТО';
                $col[5]['field'] = 'participants_photo';
                $col[5]['order'] = '6';
                $col[5]['textclass'] = ' text-base';
            }
            if ($request->page_name == 'Spr_partners_list') {

                $col[0]['name'] = 'ФИО';
                $col[0]['field'] = 'partners_name';
                $col[0]['order'] = '1';
                $col[0]['textclass'] = ' text-base';

                $col[1]['name'] = 'Статус';
                $col[1]['field'] = 'partners_status_txt';
                $col[1]['order'] = '2';
                $col[1]['textclass'] = ' text-base';

                $col[2]['name'] = 'Описание 1';
                $col[2]['field'] = 'partners_desc_1';
                $col[2]['order'] = '3';
                $col[2]['textclass'] = ' text-base';

                $col[3]['name'] = 'Описание 2';
                $col[3]['field'] = 'partners_desc_2';
                $col[3]['order'] = '4';
                $col[3]['textclass'] = ' text-base';

                $col[4]['name'] = 'Описание 3';
                $col[4]['field'] = 'partners_desc_3';
                $col[4]['order'] = '5';
                $col[4]['textclass'] = ' text-base';

                $col[5]['name'] = 'ФОТО';
                $col[5]['field'] = 'partners_photo';
                $col[5]['order'] = '6';
                $col[5]['textclass'] = ' text-base';
            }
            return json_encode($col);
        }
    }
}
