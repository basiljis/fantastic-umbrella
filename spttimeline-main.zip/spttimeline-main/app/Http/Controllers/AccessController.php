<?php

namespace App\Http\Controllers;

use App\Models\spt_access;

use App\Models\User;

use App\Models\spt_login;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;


class AccessController extends Controller
{

    public function generateCode($length=6) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHI JKLMNOPRQSTUVWXYZ0123456789";
        $code = "";
        $clen = strlen($chars) - 1;
        while (strlen($code) < $length) {
            $code .= $chars[mt_rand(0,$clen)];
        }
        return $code;
    }
    public function generate_password($number)
    {
        $arr = array('a','b','c','d','e','f',
            'g','h','i','j','k','l',
            'm','n','o','p','r','s',
            't','u','v','x','y','z',
            'A','B','C','D','E','F',
            'G','H','I','J','K','L',
            'M','N','O','P','R','S',
            'T','U','V','X','Y','Z',
            '1','2','3','4','5','6',
            '7','8','9','0','.',',',
            '(',')','[',']','!','?',
            '&','^','%','@','*','$',
            '<','>','/','|','+','-',
            '{','}','`','~');
        // Генерируем пароль
        $pass = "";
        for($i = 0; $i < $number; $i++)
        {
            // Вычисляем случайный индекс массива
            $index = rand(0, count($arr) - 1);
            $pass .= $arr[$index];
        }
        return $pass;
    }
  
  

    public function getLoginLog(Request $request)
    {
       $currentPage = $request->get('currentPage');
        $perPage = $request->get('perPage');
        $q = $request->get('q');

            $data = spt_login::orderby('id_login','desc');
            if (!is_null($q)) $data = $data->where('login_log', 'ILIKE', "%{$q}%");
            // if ($ooFilter) $data = $data->where('F5spt_klass_oo_bd_id', $ooFilter);
            //if ($okrugFilter) $data = $data->where('F4', $okrugFilter);
            $data = $data->paginate($perPage, ['*'], null, $currentPage);

        return json_encode($data);
    }
}
