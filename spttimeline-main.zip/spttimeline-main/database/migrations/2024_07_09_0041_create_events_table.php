<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventsTable extends Migration
{
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {

            $table->id('events_id');
            $table->string('events_name',1000)->nullable();
            $table->integer('events_format')->default('1')->nullable();
            $table->integer('events_type')->default('1')->nullable();
            $table->integer('events_age')->default('1')->nullable();
            $table->integer('events_price')->default('1')->nullable();
            $table->string('events_desc',4000)->nullable();
            $table->string('events_anons_short',1000)->nullable();
            $table->string('events_anons_long',4000)->nullable();
            $table->string('events_adress',4000)->nullable();
            $table->string('events_local_name',2000)->nullable();
            $table->string('events_local_www',2000)->nullable();
            $table->string('events_tickets_www',2000)->nullable();
            $table->string('events_video_www',2000)->nullable();
            $table->json('events_participants')->nullable();
            $table->json('events_partners')->nullable();
            $table->json('events_tags')->nullable();
            $table->json('events_files')->nullable();
            $table->datetime('events_dt_start')->nullable();
            $table->datetime('events_dt_end')->nullable();
            $table->string('events_start_date',100)->nullable();
            $table->string('events_start_time',100)->nullable();
            $table->string('events_end_date',100)->nullable();
            $table->string('events_end_time',100)->nullable();
            $table->integer('events_users')->nullable();
            $table->string('events_carusel')->nullable();
		    $table->tinyInteger('events_status')->default('1')->nullable();
		    $table->timestamps();
            $table->softDeletes();


        });
    }

    public function down()
    {
        Schema::dropIfExists('events');
    }
}
