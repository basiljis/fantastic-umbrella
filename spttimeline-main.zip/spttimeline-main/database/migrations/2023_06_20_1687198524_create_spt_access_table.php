<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptAccessTable extends Migration
{
    public function up()
    {
        Schema::create('spt_access', function (Blueprint $table) {

		$table->id('spt_access_id');
		$table->string('spt_access_name',100)->nullable();
		$table->integer('spt_access_post')->nullable()->default('0');
		$table->datetime('spt_access_date')->nullable();
		$table->string('spt_access_phone',100)->nullable();
		$table->integer('spt_access_oo_id')->nullable()->default('0');
		$table->integer('spt_access_user_id')->nullable();
		$table->string('spt_access_oo_not',150)->nullable();
		$table->string('spt_access_email',60)->nullable();
		$table->string('spt_access_agreement',20)->nullable();
		$table->string('spt_access_comment',500)->nullable();
		$table->string('spt_access_file_name',200)->nullable();
		$table->string('spt_access_ip',200)->nullable();
		$table->tinyInteger('spt_access_file')->nullable();
		$table->integer('spt_access_status')->nullable()->default('1');
		$table->string('spt_access_unic',50)->nullable();
		$table->string('spt_access_confirm',10)->nullable()->default('0');
		$table->tinyInteger('spt_access_rez')->nullable()->default('0');
            $table->timestamps();
            $table->softDeletes();

        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_access');
    }
}
