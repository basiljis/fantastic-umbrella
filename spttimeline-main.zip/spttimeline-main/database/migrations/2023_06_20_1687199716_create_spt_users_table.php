<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptUsersTable extends Migration
{
    public function up()
    {
        Schema::create('spt_users', function (Blueprint $table) {


            $table->string('spt_user_login',100)->nullable();
            $table->string('spt_user_passwd',100)->nullable();
            $table->string('spt_user_salt',25)->nullable();
            $table->datetime('spt_user_reg_date')->nullable();
            $table->datetime('spt_user_last_login')->nullable();
            $table->string('spt_user_login_num',100)->nullable();
            $table->string('spt_user_email',100)->nullable();
            $table->tinyInteger('spt_user_email_confirm')->nullable()->default('0');
            $table->date('spt_user_dr')->nullable();
            $table->string('spt_user_mobile',100)->nullable();
            $table->string('spt_user_doljnost',100)->nullable();
            $table->string('spt_user_name',100)->nullable();
            $table->string('spt_user_ip_reg',20)->nullable();
            $table->string('spt_user_hash',100)->nullable();
            $table->integer('spt_oo_id')->nullable()->default('0');
            $table->string('spt_user_comment',1000)->nullable();
            $table->tinyInteger('spt_user_block')->default('0');
            $table->integer('spt_users_type')->default('1');
            $table->integer('spt_users_status')->nullable()->default('1');
            $table->string('spt_skype_name',100)->nullable();
            $table->tinyInteger('spt_users_rass')->nullable()->default('1');
            $table->tinyInteger('spt_user_ts')->nullable()->default('1');

            $table->string('remember_token',100)->nullable();
            $table->string('email',255);
            $table->string('name',255);
            $table->string('password',255);
            $table->string('password_regen',100)->nullable()->default('0');
            $table->datetime('email_verified_at')->nullable();

        $table->timestamps();
        $table->softDeletes();

		$table->id('spt_user_id');

        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_users');
    }
}
