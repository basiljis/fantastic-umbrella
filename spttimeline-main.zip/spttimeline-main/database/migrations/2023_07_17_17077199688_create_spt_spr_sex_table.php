<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptsprsexTable extends Migration
{
    public function up()
    {
        Schema::create('spt_spr_sex', function (Blueprint $table) {

        $table->id('spt_spr_sex_id');
		$table->string('spt_spr_sex_name',150);
		$table->integer('spt_spr_sex_status')->default('1');
		$table->string('spt_spr_sex_short',100)->nullable()->default('NULL');
            $table->timestamps();
            $table->softDeletes();


        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_spr_sex');
    }
}
