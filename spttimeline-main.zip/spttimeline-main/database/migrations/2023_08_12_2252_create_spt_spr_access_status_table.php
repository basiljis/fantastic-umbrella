<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptspraccessstatusTable extends Migration
{
    public function up()
    {
        Schema::create('spt_spr_access_status', function (Blueprint $table) {

        $table->id('spt_spr_access_status_id');
		$table->string('spt_spr_access_status_name',150);
		$table->integer('spt_spr_access_status_status')->default('1');
            $table->timestamps();
            $table->softDeletes();

        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_spr_access_status');
    }
}
