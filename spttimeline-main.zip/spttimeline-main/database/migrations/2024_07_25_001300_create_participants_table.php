<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('participants', function (Blueprint $table) {
            $table->id('participants_id');
            $table->string('participants_name',255)->nullable();
            $table->string('participants_desc_1',400)->nullable();
            $table->string('participants_desc_2',400)->nullable();
            $table->string('participants_desc_3',400)->nullable();
            $table->integer('participants_status')->nullable()->default('1');
            $table->string('participants_photo',500)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('participants');
    }
};
