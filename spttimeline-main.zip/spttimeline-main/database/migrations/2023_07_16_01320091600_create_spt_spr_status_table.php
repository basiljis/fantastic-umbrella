<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptsprstatusTable extends Migration
{
    public function up()
    {
        Schema::create('spt_spr_status', function (Blueprint $table) {

		$table->id('spt_spr_status_id');
		$table->string('spt_spr_status_name',100);
		$table->string('spt_spr_status_comment',100)->nullable()->default('NULL');
		$table->integer('spt_spr_status_status')->default('1');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_spr_status');
    }
}
