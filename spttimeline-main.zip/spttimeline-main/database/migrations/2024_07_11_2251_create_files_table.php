<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFilesTable extends Migration
{
    public function up()
    {
        Schema::create('files', function (Blueprint $table) {

            $table->id('files_id');
            $table->integer('files_name')->default('0');
            $table->integer('files_event_id')->default('0');
            $table->string('files_adr',500)->nullable();
            $table->integer('files_status')->default('1');
            $table->integer('files_creator')->default('0');
            $table->integer('files_editor')->default('0');



            $table->timestamps();
            $table->softDeletes();

        });
    }

    public function down()
    {
        Schema::dropIfExists('files');
    }
}
