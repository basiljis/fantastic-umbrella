<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('spt_users_type', function (Blueprint $table) {
            $table->smallInteger('spt_users_type_s8')->nullable()->default('0');
            $table->smallInteger('spt_users_type_s9')->nullable()->default('0');
            $table->smallInteger('spt_users_type_s10')->nullable()->default('0');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('spt_users_type', function (Blueprint $table) {
            $table->dropColumn('spt_users_type_s8');
            $table->dropColumn('spt_users_type_s9');
            $table->dropColumn('spt_users_type_s10');
        });
    }
};
