<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptuserstypeTable extends Migration
{
    public function up()
    {
        Schema::create('spt_users_type', function (Blueprint $table) {

        $table->id('spt_users_type_id');
        $table->string('spt_users_type_name',100);
		$table->tinyInteger('spt_users_type_status')->default('1');
		$table->string('spt_users_type_comment',100)->nullable();
        $table->string('spt_users_type_posts',100)->nullable();
		$table->tinyInteger('spt_users_type_admin')->nullable()->default('0');
		$table->tinyInteger('spt_users_type_s1')->nullable()->default('0');
		$table->tinyInteger('spt_users_type_s2')->nullable()->default('0');
		$table->tinyInteger('spt_users_type_s3')->nullable()->default('0');
		$table->tinyInteger('spt_users_type_s4')->nullable()->default('0');
		$table->tinyInteger('spt_users_type_s5')->nullable()->default('0');
        $table->tinyInteger('spt_users_type_s6')->nullable()->default('0');
        $table->tinyInteger('spt_users_type_s7')->nullable()->default('0');
            $table->timestamps();
            $table->softDeletes();


        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_users_type');
    }
}
