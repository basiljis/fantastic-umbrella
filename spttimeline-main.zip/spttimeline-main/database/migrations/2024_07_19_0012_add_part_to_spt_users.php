<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('spt_users', function (Blueprint $table) {
            $table->integer('spt_users_partner',)->nullable()->default('2');
            $table->integer('spt_users_participant',)->nullable()->default('2');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('spt_users', function (Blueprint $table) {
            $table->dropColumn('spt_users_participant');
            $table->dropColumn('spt_users_partner');

        });
    }
};
