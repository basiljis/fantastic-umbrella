<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpreventstatusTable extends Migration
{
    public function up()
    {
        Schema::create('spr_event_status', function (Blueprint $table) {

        $table->id('spr_event_status_id');
		$table->string('spr_event_status_name',150);
		$table->integer('spr_event_status_status')->default('1');
            $table->timestamps();
            $table->softDeletes();

        });
    }

    public function down()
    {
        Schema::dropIfExists('spr_event_status');
    }
}
