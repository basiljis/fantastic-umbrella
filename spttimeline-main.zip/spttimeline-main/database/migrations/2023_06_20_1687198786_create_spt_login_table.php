<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptLoginTable extends Migration
{
    public function up()
    {
        Schema::create('spt_login', function (Blueprint $table) {


		$table->integer('id_user_log')->nullable();
		$table->datetime('time_login')->nullable();
		$table->string('user_name',100)->nullable();
		$table->string('session')->nullable();
		$table->text('IP_adr')->nullable();
		$table->string('login_log',100)->nullable();
		$table->string('passwd_log',50)->nullable();
		$table->string('block_log',50)->nullable();
            $table->timestamps();
            $table->softDeletes();
		$table->id('id_login');

        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_login');
    }
}
