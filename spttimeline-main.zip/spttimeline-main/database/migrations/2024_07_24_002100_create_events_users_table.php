<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events_users', function (Blueprint $table) {
            $table->id('events_users_id');
            $table->integer('events_users_event_id')->nullable();
            $table->integer('events_users_user_id')->nullable();
            $table->integer('events_users_status')->nullable()->default('1');
            $table->integer('events_users_mark')->nullable();
            $table->string('events_users_comment')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events_users');
    }
};
