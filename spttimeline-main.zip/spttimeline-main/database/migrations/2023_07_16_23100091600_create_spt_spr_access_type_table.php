<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSptspraccesstypeTable extends Migration
{
    public function up()
    {
        Schema::create('spt_spr_access_type', function (Blueprint $table) {

		$table->id('spt_spr_access_type_id');
		$table->string('spt_spr_access_type_name',100);
		$table->string('spt_spr_access_type_comment',100)->nullable()->default('NULL');
		$table->integer('spt_spr_access_type_status')->default('1');
            $table->timestamps();
            $table->softDeletes();

        });
    }

    public function down()
    {
        Schema::dropIfExists('spt_spr_access_type');
    }
}
