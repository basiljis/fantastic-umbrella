<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('spt_users', function (Blueprint $table) {
            $table->string('spt_users_icon',500)->nullable();
            $table->string('spt_users_photo',500)->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('spt_users', function (Blueprint $table) {
            $table->dropColumn('spt_users_icon');
            $table->dropColumn('spt_users_photo');

        });
    }
};
