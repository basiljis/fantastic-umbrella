<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('partners', function (Blueprint $table) {
            $table->id('partners_id');
            $table->string('partners_name',255)->nullable();
            $table->string('partners_desc_1',400)->nullable();
            $table->string('partners_desc_2',400)->nullable();
            $table->string('partners_desc_3',400)->nullable();
            $table->integer('partners_status')->nullable()->default('1');
            $table->string('partners_photo',500)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('partners');
    }
};
